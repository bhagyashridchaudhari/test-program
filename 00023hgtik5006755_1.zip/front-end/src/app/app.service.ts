import { ProjectStatus, ProjectType, Division, Platform, ProductFamily, Unit, ProductLine, Role, SegementHierarchy, Phase, Milestone, Process, SubProcess } from './container/projects/projects.model';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { UserService } from './common/user.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Injectable } from '@angular/core';

import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/observable/fromEvent';
import 'rxjs/add/observable/merge';
import 'rxjs/add/operator/map';
import { LoginHistory } from './simulate-user-log/login-history';
import { RiskCategory, RiskStatus, RiskImpact, ResponseStratergy, RiskProbability, RiskCategoryImpact, RiskScoreLevel, MitigationStatus, RiskCategoryData, RiskDatasource } from './container/projects/risk/risk.model';

@Injectable()
export class AppService {

  private _roles = { 0: 'No Access', 1: 'Program Manager', 2: 'Full Control', 3: 'Contribute', 4: 'Read Only' };

  private _loaded = new BehaviorSubject<boolean>(false);

  private _commonData: CommonData;

  private _userNotFound = false;

  readonly isLoaded: Observable<boolean> = this._loaded.asObservable();

  readonly userMap = new Map<string, string>();

  readonly fetchUserMap = new Map<string, Observable<Resp<string>>>();

  collist: PreferenceArr[];

  get userNotFound(): boolean { return this._userNotFound; }

  get pSegement(): SegementHierarchy[] { return this._commonData.psh; }

  get pStatus(): ProjectStatus[] { return this._commonData.pst; }

  get pTypes(): ProjectType[] { return this._commonData.ptp; }

  get pDivisn(): Division[] { return this._commonData.pdv; }

  get pPltfrms(): Platform[] { return this._commonData.plf; }

  get pPrdtLns(): ProductLine[] { return this._commonData.pln; }

  get pPrdtFmls(): ProductFamily[] { return this._commonData.pfm; }

  get pUnits(): Unit[] { return this._commonData.put; }

  get pRoles(): Role[] { return this._commonData.prl; }

  get pProcess(): Process[] { return this._commonData.prs; }

  get pPhase(): Phase[] { return this._commonData.pps; }

  get pMilestone(): Milestone[] { return this._commonData.pms; }

  get pCurrencies(): string[] { return this._commonData.pcu; }

  get env(): String { return this._commonData.env; }

  get today(): Date { return this._commonData.tdy; }

  get ercActiveProgTypes(): number[] { return this._commonData.eapt; }

  get maxDate(): Date { return new Date(2100, 11, 31); }

  get rCategory(): RiskCategory[] { return this._commonData.rCtgry; }

  get rImpact(): RiskImpact[] { return this._commonData.rImp; }

  get rStatus(): RiskStatus[] { return this._commonData.rSts; }

  get rProbability(): RiskProbability[] { return this._commonData.rPblty; }

  get responseStratergy(): ResponseStratergy[] { return this._commonData.rspStrgy; }

  get rCtgryImpact(): RiskCategoryImpact[] { return this._commonData.rCI; }

  get rScoreLevel(): RiskScoreLevel[] { return this._commonData.rsl; }

  get mStatus(): MitigationStatus[] { return this._commonData.mSts; }

  get sbProcess(): SubProcess[] { return this._commonData.subp; }

  get allColmns(): string[][] { return this._commonData.preferenceCols; }

//  get psubprcsrltn(): ProcessSubProcess[] { return this._commonData.psubprltn; }

  constructor(private userService: UserService, private http: HttpClient) {
    this.http.get<CommonData>('/api/common-data').subscribe(data => {
      this._commonData = data;
      this._loaded.next(true);
    }, err => this._userNotFound = true);
  }

  reloadData = () => {
    this._loaded.next(false);
    this.http.get<CommonData>('/api/common-data?reload=true').subscribe(data => {
      this._commonData = data;
      this._loaded.next(true);
    });
  }

  findUsers = (query: string) => query ? this.http.get<UserView[]>(`/api/users/search?value=${query}`) : new BehaviorSubject<UserView[]>([]).asObservable();

  getDays = (start: Date, end: Date) => start && end ? (Math.floor(Math.abs((end.getTime() - start.getTime()) / (24 * 60 * 60 * 1000))) + 1) : 0;

  isValidUser = (id: string) => this.http.get<Resp<boolean>>(`/api/users/valid/${id}`);

  getUserName = (id: string) => this.http.get<Resp<string>>(`/api/users/name/${id}`);

  getUsers = (ids: string[]) => this.http.get<UserView[]>(`/api/users?ids=${ids.join(',')}`);

  loadUser = () => this.getLoggedInUser().subscribe(user => this.userService.loadUser(user), err => this._userNotFound = true);

  simulate = (id: string) => this.http.post<Resp<string>>('/api/simulate', id);

  logout = () => this.http.get<Resp<string>>('/api/logout');

  getLoggedInUser = () => this.http.get<User>('/api/logged-user');

  getPlatfrmByDiv = (id: number) => {
    const ids = Array.from(new Set(this.pSegement.filter(s => s.id.divId === Number(id)).map(s => s.id.pltfmId)));
    return ids.length !== 0 ? this.pPltfrms.filter(p => ids.indexOf(p.pltfmId) !== -1) : [];
  }

  getPrdtLineByPlatfrm = (id: number) => {
    const ids = Array.from(new Set(this.pSegement.filter(s => s.id.pltfmId === Number(id)).map(s => s.id.prdlnId)));
    return ids.length !== 0 ? this.pPrdtLns.filter(p => ids.indexOf(p.prdlnId) !== -1) : [];
  }

  getPrdtFmlyByPrdtLine = (id: number) => {
    const ids = Array.from(new Set(this.pSegement.filter(s => s.id.prdlnId === Number(id)).map(s => s.id.prdfmlyId)));
    return ids.length !== 0 ? this.pPrdtFmls.filter(p => ids.indexOf(p.prdfmyId) !== -1) : [];
  }

  getUnitByPrdtFmly = (id: number) => {
    const ids = Array.from(new Set(this.pSegement.filter(s => s.id.prdfmlyId === Number(id)).map(s => s.id.unitId)));
    return ids.length !== 0 ? this.pUnits.filter(p => ids.indexOf(p.unitId) !== -1) : [];
  }

  getDivision = (id: number): string => {
    const div = this.pDivisn.find(p => p.divId === id);
    return div ? div.divNm : null;
  }

  getPlatfrm = (id: number): string => {
    const pltfm = this.pPltfrms.find(p => p.pltfmId === id);
    return pltfm ? pltfm.pltfmNm : null;
  }

  getPrdtLine = (id: number): string => {
    const prdln = this.pPrdtLns.find(p => p.prdlnId === id);
    return prdln ? prdln.prdlnNm : null;
  }

  getPrdtFmly = (id: number): string => {
    const prdfmy = this.pPrdtFmls.find(p => p.prdfmyId === id);
    return prdfmy ? prdfmy.prdfmyNm : null;
  }

  getUnit = (id: number): string => {
    const unit = this.pUnits.find(p => p.unitId === id);
    return unit ? `${unit.unitNm} (${unit.unitCd})` : null;
  }

  getStatus = (id: number): string => {
    const status = this.pStatus.find(p => p.statusId === id);
    return status ? status.statusNm : null;
  }

  getType = (id: number): string => {
    const type = this.pTypes.find(p => p.typeId === id);
    return type ? type.typeName : null;
  }

  getRole = (user: User, prjId: number): number => {
    const role: number = user.progAccessMap[prjId];
    return role ? role : 0;
  }

  getRoleName = (role: number): string => this._roles[role];

  getLoginHistory = () => this.http.get<LoginHistory[]>(`/api/user/login-history`);

  getRiskCategoryImpact = (cid: number) => {
    const temp = this.rCtgryImpact.filter(r => r.id.ctgryId === cid).map(r => r);
    temp.filter(t => t.id.impactId);
    return temp;
  }

  getRiskCategory = (id: number): string => {
    const category = this.rCategory.find(r => r.catgryId === id);
    return category ? category.catgryName : null;
  }

  getRiskImpact = (id: number): number => {
    const impact = this.rImpact.find(r => r.impactId === id);
    return impact ? impact.impactId : 0;
  }

  getRiskStatus = (id: number): string => {
    const status = this.rStatus.find(r => r.statusId === id);
    return status ? status.statusName : null;
  }

  getRiskProbabiity = (id: number) => {
    const probability = this.rProbability.find(r => r.prbltyId === id);
    return probability ? probability.prbltyName : null;
  }

  getRespStratergy = (id: number) => {
    const respStratergy = this.responseStratergy.find(r => r.stratergyId === id);
    return respStratergy ? respStratergy.stratergyName : null;
  }

  getRiskScore = (impctid: number, pid: number) => {
    const rscore = this.rScoreLevel.find(r => r.id.impactId === impctid && r.id.prbltyId === pid);
    return rscore ? rscore.score : 0;
  }

  getRiskLevel = (impctid: number, pid: number) => {
    const rlevel = this.rScoreLevel.find(r => r.id.impactId === impctid && r.id.prbltyId === pid);
    return rlevel ? rlevel.level : 0;
  }

  getMtgtnProbability = (id: number) => {
    const probability = this.rProbability.find(r => r.prbltyId === id);
    return probability ? probability.prbltyName : null;
  }

  getMtgtnStatus = (id: number) => {
    const status = this.mStatus.find(r => r.id === id);
    return status ? status.name : null;
  }

  getSubprocess = (id: number) => {
    const sbProcess = this.sbProcess.find(r => r.id === id);
    return sbProcess ? sbProcess.acronym : null;
  }

  getColumns = () => {
   this.collist = new Array;
   this.allColmns.filter( column => {
      let a = new PreferenceArr;
      a.col = column[0];
      a.colName = column[1];
      this.collist.push(a);
    });
    return this.collist;
  }

  getProgramCatgryName = (prjRiskCatgry: RiskCategoryData[], id: number) => {
    const pcategory = prjRiskCatgry.find(r => r.catgryId === id);
    return pcategory ? pcategory.catgryAcronym : null;
  }

  getTypeAcronym = (id: number): string => {
    const type = this.pTypes.find(p => p.typeId === id);
    return type ? type.typeAcronym : null;
  }


 /* getProgSubPrcs = (progId: number, prjTypeId: number) => {

 //   const sunprcs = this.psubprcsrltn.find(p => p.id.process === prjTypeId).id.subProcess;

  const sunprcs =   this.sbProcess.filter(sb => this.psubprcsrltn.find(p => p.id.process === prjTypeId)).map(sb => sb);

    console.log('sunprcs => ', sunprcs);
  }
*/
}

export type Status = 'SUCCESS' | 'ERROR' | 'IN_PROGRESS';

export class Resp<T> extends Object {

  readonly status: Status;

  body: T;

  readonly messages: RespMessage[];
}

export type Type = 'SUCCESS' | 'DANGER' | 'WARNING' | 'INFO' | 'ALERT';

export class RespMessage {

  type: Type;

  data: string;
}

export class UserList {

  value: UserView[] = [];
}

export class UserView {

  userId: string;

  fullName: string;

  userTitle: string;
}

export class User {

  userId: string;

  name: string;

  userType: string;

  jobTitle: string;

  email: string;

  admin: boolean;

  itSupport: boolean;

  appAccess: boolean;

  createAccess: boolean;

  simulated: boolean;

  progAccessMap: Map<number, number>;
}

class CommonData {

  psh: SegementHierarchy[];

  ptp: ProjectType[];

  pst: ProjectStatus[];

  pdv: Division[];

  plf: Platform[];

  pln: ProductLine[];

  pfm: ProductFamily[];

  put: Unit[];

  prl: Role[];

  prs: Process[];

  pps: Phase[];

  pms: Milestone[];

  pcu: string[];

  eapt: number[];

  env: string;

  tdy: Date;

  rCtgry: RiskCategory[];

  rSts: RiskStatus[];

  rImp: RiskImpact[];

  rPblty: RiskProbability[];

  rspStrgy: ResponseStratergy[];

  rCI: RiskCategoryImpact[];

  rsl: RiskScoreLevel[];

  mSts: MitigationStatus[];

  subp: SubProcess[];

  preferenceCols: string[][];

  psubprltn: ProcessSubProcess[];

}

export class PreferenceArr {
  col: string;
  colName: string;

//  constructor(col: string, colName: string) {  }
  constructor() {}

}

export class ProcessSubProcess {
  id: ProcessSubProcessId;


}

export class ProcessSubProcessId {
  id: number;

  process: number;

  subProcess: number;
}


