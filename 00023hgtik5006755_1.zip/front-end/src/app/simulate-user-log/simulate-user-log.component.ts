
import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { TableData } from '@app/common';
import { AppService } from '../app.service';
import { SetNamePipe } from '../common/set-name.directive';
import { MessageService, Message } from '../common/message.service';
import { LoginHistory } from './login-history';

@Component({
  selector: 'app-simulate-user-log',
  templateUrl: './simulate-user-log.component.html'
})
export class SimulateUserLogComponent implements OnInit {

  datasource: TableData<LoginHistory>;

  constructor(private messageService: MessageService,
    private appService: AppService,
    private setNamePipe: SetNamePipe,
    private datePipe: DatePipe) { }

    ngOnInit() {
      this.messageService.change(new Message(`Loading logs for simulated users...`, 'info'));
       this.appService.getLoginHistory().subscribe(data => {
        setTimeout(() => this.datasource = new TableData(data.map(d => {
            d.loginBy = this.setNamePipe.transform(d.loginBy);
            d.loginAS = this.setNamePipe.transform(d.loginAS);
            d.lastUpdatedTS = this.datePipe.transform(d.lastUpdatedTS, 'dd-MMM-yyyy').concat(' ').concat(this.datePipe.transform(d.lastUpdatedTS, 'mediumTime'));
            return d;
            })));
            this.messageService.change(null);
        });
    }
}
