
export class LoginHistory {

    loginAS: string;

    loginBy: string;

    lastUpdatedTS: string;
}
