import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SimulateUserLogComponent } from './simulate-user-log.component';

describe('SimulateUserLogComponent', () => {
  let component: SimulateUserLogComponent;
  let fixture: ComponentFixture<SimulateUserLogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SimulateUserLogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SimulateUserLogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
