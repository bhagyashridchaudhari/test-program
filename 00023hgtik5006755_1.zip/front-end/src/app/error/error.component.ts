import { UserService } from '../common/user.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  templateUrl: './error.component.html'
})
export class ErrorComponent implements OnInit {

  routeParams;

  constructor( private activatedRoute: ActivatedRoute, private location: Location, private userService: UserService) { }

  ngOnInit() {
    this.routeParams = this.activatedRoute.snapshot.queryParams;
    setTimeout(() => this.location.go(this.location.path().split('?')[0]));
  }

  get user() {
    return this.userService.getUser();
  }
}
