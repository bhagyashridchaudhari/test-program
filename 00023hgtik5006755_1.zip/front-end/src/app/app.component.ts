import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { DashboardService } from './container/dashboard/dashboard.service';
import { MessageService } from './common/message.service';
import { UserService } from './common/user.service';
import { AppService, User } from './app.service';
import { ProjectSearchService } from './container/projects/project-search/project-search.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent implements OnInit {

  isLoding = true;
  paddingTop = '150px';
  user: User = null;

  constructor(private dashboardService: DashboardService,
    private messageService: MessageService,
    private projectSearchService: ProjectSearchService,
    private userService: UserService,
    public app: AppService) { }

  ngOnInit() {
    this.userService.currentUser.subscribe(user => {
      this.user = user;
      if (user) {
        if (user.appAccess) {
          this.dashboardService.init();
          this.projectSearchService.reset();
        } else {
          this.messageService.change(null);
        }
      }
    });

  this.messageService.currentMessage.subscribe(message => {
    setTimeout(() => this.isLoding = (message && message.length > 0 && message[0].messageType === 'info'), 0);
    this.paddingTop = (message && message.length > 0) ? (155 + (message.length * 36)) + 'px' : '150px';
  });
  this.app.loadUser();
  }

  onChangeRoutes = () =>  this.messageService.change(null);

  get userNotFound() { return this.app.userNotFound; }

}
