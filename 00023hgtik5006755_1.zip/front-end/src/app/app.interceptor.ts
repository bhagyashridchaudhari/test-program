
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpResponse } from '@angular/common/http';
import { MessageService, Message } from './common/message.service';
import { UserService } from './common/user.service';
import { Observable } from 'rxjs/observable';
import { Injectable } from '@angular/core';
import * as moment from 'moment';

import 'rxjs/add/operator/do';

@Injectable()
export class AppInterceptor implements HttpInterceptor {

  isoPattern = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/;

  isoParser = 'YYYY-MM-DD[T]HH:mm:ss.SSS[Z]';

  constructor(private messageService: MessageService, private userService: UserService) { }

  private formatDate(o: any) {
    if (Array.isArray(o)) {
      o.forEach((v, i) => {
        if (v instanceof Date) {
          o[i] = moment(v).format(this.isoParser);
        } else {
          this.formatDate(v);
        }
      });
    } else if (typeof o === 'object') {
      Object.keys(o).forEach(k => {
        if (o[k]) {
          if (o[k] instanceof Date) {
            o[k] = moment(o[k]).format(this.isoParser);
          } else if (o[k] instanceof Object) {
            this.formatDate(o[k]);
          }
        }
      });
    }
  }
  private parseDate(o: any) {
    if (Array.isArray(o)) {
      o.forEach((v, i) => {
        if (this.isoPattern.test(v)) {
          o[i] = moment(v, this.isoParser).toDate();
        } else if (v) {
          this.parseDate(v);
        }
      });
    } else if (typeof o === 'object') {
      Object.keys(o).forEach(k => {
        if (o[k]) {
          if (typeof o[k] === 'string' && this.isoPattern.test(o[k])) {
            o[k] = moment(o[k], this.isoParser).toDate();
          } else if (o[k] instanceof Object) {
            this.parseDate(o[k]);
          }
        }
      });
    }
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const user = this.userService && this.userService.getUser() ? this.userService.getUser().userId : '';
    const authReq = req.clone({
      headers: req.headers.set('logged-user', user),
      params: req.params.set('_', Math.floor(1000 + Math.random() * 9000).toString())
    });
    if ((req.method === 'POST' || req.method === 'PUT') && req.body) {
      this.formatDate(req.body);
    }
    return next.handle(authReq).do(event => {
      if (event instanceof HttpResponse) {
        const response = <HttpResponse<any>>event;
        if (response.status === 200) {
          this.parseDate(response.body);
        }
      }
    },
      err => {
        if (err.error instanceof Error) {
          this.messageService.change(new Message(err.error.message, 'danger'));
        } if (err.status === 0 || err.status === 403 || err.url.includes('/SignInServlet') || (err.headers && err.headers.has('X-Okta-Request-Id')) || err.status === 200) {
          let i = 5;
          const m = new Message(`This page will refresh in ${i} seconds`, 'info');
          this.messageService.changes([m, new Message(err.status !== 403 ? 'Server not reachable.' : err.error, 'danger')]);
          const ref = setInterval(() => {
            m.message = `This page will refresh in ${--i} second${i > 1 ? 's' : ''}`;
            if (i === 0) {
              clearInterval(ref);
              if (window.history) {
                window.history.pushState('', 'Program Risk Management', '/web/dashboard');
              }
              window.location.reload();
            }
          }, 1000);
        } else if (err.status === 422) {
          this.messageService.changes(err.error.map(error => new Message(error, 'danger')));
        } else {
          this.messageService.change(new Message(`${err.error}`, 'danger'));
        }
      });
  }
}
