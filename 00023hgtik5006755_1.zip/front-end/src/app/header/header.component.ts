import { Component, OnInit, HostListener, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { MessageService, Message } from '../common/message.service';
import { UserService } from '../common/user.service';
import { AppService, UserList, User } from '../app.service';
import { ProjectSearchService } from '../container/projects/project-search/project-search.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  user: User;

  srinkNav: boolean;

  message: Message[] = [];

  userId: string;

  users = new UserList;

  modalOpen = false;

  comfModalOpen = false;

  timeouts: Map<string, any> = new Map;

  constructor( @Inject(DOCUMENT) private document: Document,
    private messageService: MessageService,
    private userService: UserService,
    private app: AppService,
    private searchService: ProjectSearchService,
    private router: Router) { }

  ngOnInit() {
    this.messageService.currentMessage.subscribe(message => {
      this.timeouts.forEach((v, k) => clearTimeout(v));
      this.timeouts = new Map;
      this.message = message ? message : [];
      const msg = this.message.filter(m => m.messageType !== 'info');
      msg.forEach(m => this.timeouts.set(m.message, setTimeout(() => this.removeMsg(m.message), 15000)));
    });
    this.userService.currentUser.subscribe(user => this.user = user);

    // this.chartService.data.subscribe(data => this.isChartLoaded = data != null);
  }

  get env() { return this.app.env; }

  @HostListener('window:scroll', [])
  onWindowScroll() {
    const offset: number = window.pageYOffset || this.document.documentElement.scrollTop || this.document.body.scrollTop || 0;
    this.srinkNav = offset > 40 ? true : false;
  }

  removeMsg = (msg) => {
    if (this.timeouts.get(msg)) {
      clearTimeout(this.timeouts.get(msg));
      this.timeouts.delete(msg);
    }
    this.messageService.changes(this.message.length > 1 ? this.message.filter(m => m.message !== msg) : null);
  }

  refreshCache = () =>  this.app.reloadData();

  simulate = () => {
    this.modalOpen = false;
    this.app.simulate(this.userId).subscribe(resp => {
      if (resp.status === 'SUCCESS') {
      this.searchService.reset();
        this.messageService.change(new Message('Logging in as simulated user...', 'info'));
        this.app.getLoggedInUser().subscribe(user => {
          this.userService.loadUser(user);
          this.router.navigateByUrl('web/dashboard');
        });
      } else {
        this.messageService.change(new Message(`You are not authorized for this action.`, 'danger'));
      }
    });
  }

  logout = () => {
    this.app.logout().subscribe(resp => {
     this.searchService.reset();
      this.messageService.change(new Message('Logging out from simulated user...', 'info'));
      this.app.getLoggedInUser().subscribe(user => {
        this.userService.loadUser(user);
        this.router.navigateByUrl('web/dashboard');
      });
    });
  }
}
