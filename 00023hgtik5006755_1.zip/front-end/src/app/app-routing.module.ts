import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';

import { DashboardComponent } from './container/dashboard/dashboard.component';
import { ProjectSearchComponent } from './container/projects/project-search/project-search.component';
import { ProjectCreateUpdateComponent } from './container/projects/project-create-update/project-create-update.component';
import { ProjectTeamComponent } from './container/projects/project-team/project-team.component';
import { ProjectTransferComponent } from './container/projects/project-transfer/project-transfer.component';
import { ProjectDeleteComponent } from './container/projects/project-delete/project-delete.component';
import { ProjectUpdateStatusComponent } from './container/projects/project-update-status/project-update-status.component';
import { ProjectDetailsComponent } from './container/projects/project-details/project-details.component';
import { ProgramReportComponent } from './container/reports/program-report/program-report.component';
import { ProgramPreferenceComponent } from './container/projects/program-preference/program-preference.component';
import { CategoryImpactDetailComponent } from './container/risk-category/category-impact-detail/category-impact-detail.component';
import { ErrorComponent } from './error/error.component';
import { ErrorNotFoundComponent } from './error-not-found/error-not-found.component';
import { ViewImpactDescComponent } from './container/risk-category/view-impact-desc/view-impact-desc.component';

const appRoutes: Routes = [
  { path: '', redirectTo: '/web/dashboard', pathMatch: 'full' },
  { path: 'web/dashboard', component: DashboardComponent },

  { path: 'web/programs/create', component: ProjectCreateUpdateComponent },
  { path: 'web/programs/search', component: ProjectSearchComponent },
  { path: 'web/programs/detail/:id', component: ProjectDetailsComponent },
  { path: 'web/programs/update/:id', component: ProjectCreateUpdateComponent },
  { path: 'web/programs/team/:id', component: ProjectTeamComponent },
  { path: 'web/programs/delete', component: ProjectDeleteComponent },
  { path: 'web/programs/transfer', component: ProjectTransferComponent },
  { path: 'web/programs/update-status', component: ProjectUpdateStatusComponent },
  { path: 'web/reports/program/:id', component: ProgramReportComponent },
  { path: 'web/category/impact/:id', component: CategoryImpactDetailComponent },
  { path: 'web/category/impact/view/:id', component: ViewImpactDescComponent },
  { path: 'web/programs/preference', component: ProgramPreferenceComponent },

  { path: 'web/error-access', component: ErrorComponent },
  { path: 'web/error', component: ErrorComponent },
  { path: '**', component: ErrorNotFoundComponent }

];

@NgModule({
  imports: [
    RouterModule.forRoot(appRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule { }

