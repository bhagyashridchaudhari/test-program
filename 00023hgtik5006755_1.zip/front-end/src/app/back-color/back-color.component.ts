import { Component, OnInit, ViewChild, ElementRef, Input } from '@angular/core';

@Component({
  selector: 'app-back-color',
  templateUrl: './back-color.component.html',
  styleUrls: ['./back-color.component.css']
})
export class BackColorComponent implements OnInit {

  @ViewChild('ele') private ele: ElementRef;

  @Input() width = '100px';

  @Input() cls = '';

  constructor() { }

  ngOnInit() {
  }


  in() {
    const wrapper: HTMLElement = this.ele.nativeElement;
    const body = this.closestByClass(wrapper, 'body');
    if (body) {
      const w = wrapper.getBoundingClientRect();
      const b = body.getBoundingClientRect();
      if (w.top > b.top + w.height && w.bottom > b.bottom) {
        wrapper.style.top = '';
        wrapper.style.bottom = '0';
        wrapper.style.borderBottom = 'none';
        wrapper.style.borderTop = '1px solid #ddd';
      } else if (w.bottom > b.bottom) {
        wrapper.style.height = (b.bottom - w.top) + 'px';
        wrapper.style.overflowY = 'scroll';
      } else if (this.closestByTag(wrapper, 'td').offsetHeight > w.height) {
        wrapper.style.borderBottom = 'none';
      }
    }
  }

  closestByClass = (el: HTMLElement, clazz: string) => {
    while (el.className !== clazz) {
      el = el.parentElement;
      if (!el) { return null; }
    }
    return el;
  }


  closestByTag = (el: HTMLElement, tagName: string) => {
    while (el.tagName.toLowerCase() !== tagName.toLowerCase()) {
      el = el.parentElement;
      if (!el) { return null; }
    }
    return el;
  }

}
