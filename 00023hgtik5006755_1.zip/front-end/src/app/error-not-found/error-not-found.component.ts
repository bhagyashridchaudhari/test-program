import { Component } from '@angular/core';

@Component({
  templateUrl: './error-not-found.component.html'
})
export class ErrorNotFoundComponent {}
