import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WrapTextComponent } from './wrap-text.component';

describe('WrapTextComponent', () => {
  let component: WrapTextComponent;
  let fixture: ComponentFixture<WrapTextComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WrapTextComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WrapTextComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
