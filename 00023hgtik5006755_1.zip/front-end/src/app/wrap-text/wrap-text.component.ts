import { Component, Input, ElementRef, ViewChild } from '@angular/core';

@Component({
  selector: 'app-wrap-text',
  // template: '<div #wrapper [style.maxWidth]="width" [ngClass]="cls" (mouseover)="in()" (mouseout)="out()"><ng-content></ng-content></div>',
  template: '<div #wrapper [style.maxWidth]="width" [style.top]="0" [ngClass]="cls" (mouseover)="in()" (mouseout)="out()"><ng-content></ng-content></div>',
  styleUrls: ['./wrap-text.component.css']
})
export class WrapTextComponent {

  @ViewChild('wrapper') private wrapper: ElementRef;

  @Input() width = '200px';

  @Input() cls = '';

  in() {
    const wrapper: HTMLElement = this.wrapper.nativeElement;
    const body = this.closestByClass(wrapper, 'body');
    if (body) {
      const w = wrapper.getBoundingClientRect();
      const b = body.getBoundingClientRect();
      if (w.top > b.top + w.height && w.bottom > b.bottom) {
        wrapper.style.top = '';
        wrapper.style.bottom = '0';
        wrapper.style.borderBottom = 'none';
        wrapper.style.borderTop = '1px solid #ddd';
      } else if (w.bottom > b.bottom) {
        wrapper.style.height = (b.bottom - w.top) + 'px';
        wrapper.style.overflowY = 'scroll';
      } else if (this.closestByTag(wrapper, 'td').offsetHeight > w.height) {
        wrapper.style.borderBottom = 'none';
      }
    }
  }
  out() {
    const wrapper: HTMLElement = this.wrapper.nativeElement;
 //   wrapper.style.top = '0';
    wrapper.style.bottom = '';
    wrapper.style.borderBottom = '';
    wrapper.style.borderTop = '';
    wrapper.style.overflowY = '';
    wrapper.style.height = '';
  }

  closestByClass = (el: HTMLElement, clazz: string) => {
    while (el.className !== clazz) {
      el = el.parentElement;
      if (!el) { return null; }
    }
    return el;
  }

  closestByTag = (el: HTMLElement, tagName: string) => {
    while (el.tagName.toLowerCase() !== tagName.toLowerCase()) {
      el = el.parentElement;
      if (!el) { return null; }
    }
    return el;
  }
}
