import { ErrorHandler, Injectable, Injector } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';

@Injectable()
export class AppErrorHandler implements ErrorHandler {

  constructor(private injector: Injector) { }

  handleError(error: Error | HttpErrorResponse) {
    if (error instanceof HttpErrorResponse) {
      // Server or connection error happened
      if (!navigator.onLine) {
        // Handle offline error
        return console.error('No Internet Connection');
      } else {
        // Handle Http Error (error.status === 403, 404...)
        return console.error(`${error.status} - ${error.message}`);
      }
    } else {
      console.error(error);
      const router = this.injector.get(Router);
      router.navigate(['/web/error'], { queryParams: { url: router.url, path: window.location.href, error: error } });
    }
  }
}
