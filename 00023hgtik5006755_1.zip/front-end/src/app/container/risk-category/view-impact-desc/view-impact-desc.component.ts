import { Component, OnInit } from '@angular/core';
import { RiskService } from '../../projects/risk/risk.service';
import { ActivatedRoute, Router } from '@angular/router';
import { MessageService, Message } from '../../../common/message.service';
import { ProjectSearchService } from '../../projects/project-search/project-search.service';
import { ProjectService } from '../../projects/projects.service';
import { DashboardService } from '../../dashboard/dashboard.service';
import { UserService } from '../../../common/user.service';
import { AppService } from '../../../app.service';
import { RiskCategoryData } from '../../projects/risk/risk.model';
import { TableData } from '@app/common';

@Component({
  selector: 'app-view-impact-desc',
  templateUrl: './view-impact-desc.component.html',
  styleUrls: ['./view-impact-desc.component.css']
})
export class ViewImpactDescComponent implements OnInit {

  progId: number;

  checkedIds: number[] = [];

  riskCategoryData: RiskCategoryData[];

  datasource: TableData<RiskCategoryData>;

  programCategory: RiskCategoryData[];

  ctgInfoModal: boolean;

  constructor(private riskService: RiskService,
    private route: ActivatedRoute,
    private messageService: MessageService) {}

  ngOnInit() {
    this.progId = Number(this.route.snapshot.paramMap.get('id'));
    this.messageService.change(new Message(`Loading risk category impact description...`, 'info'));
    this.getRiskCategoryImpactData();
  }

  getRiskCategoryImpactData() {
    this.checkedIds = [];
    this.riskService.getRiskCategoryImpactDesc(this.progId).subscribe(data => {
      this.riskCategoryData = data;
      this.programCategory = data.filter(m => m.catgryType === 'Program');
      this.checkedIds = this.riskCategoryData.filter(p => p.catgryId && p.active === 'Y').map(m => m.catgryId);
      this.riskCategoryData.sort((a, b) => {
        if (a.catgryId && a.active === 'Y') {
          return -1;
        }
        if (b.catgryId && b.active === 'N') {
          return 1;
        }
        return 0;
      });
      this.riskCategoryData = this.riskCategoryData.filter(r => r.active === 'Y');
    });
    this.messageService.change(null);
  }


}
