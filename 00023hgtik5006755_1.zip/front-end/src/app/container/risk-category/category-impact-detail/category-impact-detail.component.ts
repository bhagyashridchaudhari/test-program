import { Component, OnInit, Input, HostListener } from '@angular/core';
import { TableData } from '@app/common';
import { ActivatedRoute, Router } from '@angular/router';
import { RiskService } from '../../projects/risk/risk.service';
import { MessageService, Message } from '../../../common/message.service';
import { RiskCategoryData, RiskCategory } from '../../projects/risk/risk.model';
import { ProjectSearchService } from '../../projects/project-search/project-search.service';
import { ProjectDetail, Project } from '../../projects/projects.model';
import { Subscription } from 'rxjs';
import { ProjectService } from '../../projects/projects.service';
import { DashboardService } from '../../dashboard/dashboard.service';
import { TempImpactDesc } from '../../projects/project-details/project-details.component';
import { UserService } from '../../../common/user.service';
import { AppService } from '../../../app.service';
import { DatePipe } from '@angular/common';


@Component({
  selector: 'app-category-impact-detail',
  templateUrl: './category-impact-detail.component.html',
  styleUrls: ['./category-impact-detail.component.css']
})

export class CategoryImpactDetailComponent implements OnInit {

  progId: number;

  riskCategoryData: RiskCategoryData[];

  datasource: TableData<RiskCategoryData>;

  categoryMode: number;

  categoryModal: boolean;

  riskCategoryObj: RiskCategoryData;

  programCategory:RiskCategoryData[];

  message: Message[]=[];

  checkedIds: number[] = [];

  cloneCtgModal:boolean;

  isNumeric = false;

  projectDetails: ProjectDetail[];

  project: Project;

  subscription: Subscription;
  
  searchPrjdataSrc:  TableData<ProjectDetail>;

  cloneCtg:RiskCategoryData[]=[];

  tempPrgId: number;
 
  isSaveDisable: boolean = false;

  projectDtlsFiltrd: ProjectDetail[];
  
  ctgInfoModal: boolean;

  projectDetail: ProjectDetail;

  isUpdateEnable: boolean = false;

  role: number;

  finishHide = false;
  
  canEdit = false;

   projStatus = false;    

  constructor(private riskService: RiskService,
    private route: ActivatedRoute,
    private messageService: MessageService, private projectSearchService: ProjectSearchService, private router: Router,
     private projectService: ProjectService,private dashboardService: DashboardService, private userService: UserService, 
      private app: AppService, private datePipe: DatePipe) {}

  ngOnInit() {
    this.progId = Number(this.route.snapshot.paramMap.get('id'));
    this.messageService.change(new Message(`Loading risk category details...`, 'info'));
    this.role = this.app.getRole(this.userService.getUser(), this.progId);
    this.canEdit =  this.user.admin || this.role <= 2;
    this.projectService.getProject(this.progId).subscribe(p => {
      this.projectDetail = this.dashboardService.convert(p);
      if (this.projectDetail) {
        if (this.projectDetail.prjStatusId) {
          this.projStatus = this.projectDetail.prjStatusId === 4 || this.projectDetail.prjStatusId === 6;
        }
        if (this.projectDetail.createdTsTemp && this.projectDetail.lastUpdtTsTemp) {
          const createdTs = this.datePipe.transform(this.projectDetail.createdTsTemp, 'yyyy-MM-dd HH:mm:ss');
          const lastUpdtTs = this.datePipe.transform(this.projectDetail.lastUpdtTsTemp, 'yyyy-MM-dd HH:mm:ss');
          if (createdTs && lastUpdtTs) {
            if (createdTs === lastUpdtTs) {
              this.finishHide = true;
            }
          }
        }
      }
    });
    this.getRiskCategoryImpactData();
  /*  for cloning
    this.init();
   this.subscription = this.projectSearchService.projectDetails.subscribe(projectDetails => {
      this.projectDetails = projectDetails;
      if (this.projectDetails) {
        this.projectDtlsFiltrd = this.projectDetails.filter(p => p.prjId !== this.progId);
      }
      this.searchPrjdataSrc = new TableData(this.projectDtlsFiltrd ? this.projectDtlsFiltrd : []);
    });
    if (this.projectSearchService.getSearchProject() != null) {
      this.project = this.projectSearchService.getSearchProject();
    }
*/
  }

  get user() { return this.userService.getUser(); }

  getRiskCategoryImpactData() {
    this.checkedIds = [];
    this.messageService.change(new Message(`Loading risk category details...`, 'info'));
    this.riskService.getRiskCategoryImpactDesc(this.progId).subscribe(data => {
      this.riskCategoryData = data;
      this.programCategory = data.filter(m => m.catgryType === 'Program');
      this.checkedIds = this.riskCategoryData.filter(p => p.catgryId && p.active === 'Y').map(m => m.catgryId);
      this.riskCategoryData.sort((a, b) => {
        if (a.catgryId && a.active === 'Y') {
          return -1;
        }
        if (b.catgryId && b.active === 'N') {
          return 1;
        }
        return 0;
      });
      this.datasource = new TableData(this.riskCategoryData);
      this.messageService.change(null);
    });
  }

  initCategory() {
    this.riskCategoryObj = new RiskCategoryData;
    this.riskCategoryObj.progId = this.progId;
    this.riskCategoryObj.catgryType = 'Program';
    this.isUpdateEnable = false;
    this.categoryModal = true;
    
  }

  getCategoryData(catObj: RiskCategoryData) {
    this.isUpdateEnable = true;
    this.riskCategoryObj = this.riskCategoryData.find(m => m.catgryId === catObj.catgryId && m.catgryType === catObj.catgryType);
    this.riskCategoryObj.progId = this.progId;
    this.categoryModal = true;
  }

  checked = (catId: number) => this.checkedIds.length > 0 && this.checkedIds.findIndex(id => id === catId) !== -1;

  check = (checked: boolean, catId: number) => {
    if (checked) {
      this.checkedIds.push(catId);
    } else {
      const index = this.checkedIds.findIndex(cId => cId === catId);
      if (index !== -1) {
        this.checkedIds.splice(index, 1);
      }
    }
  }

  updateCategory() {
    this.messageService.change(new Message(`Please wait......`, 'info'));
    this.riskCategoryData = this.riskCategoryData.map(o => {
    o.active = this.checkedIds.indexOf(o.catgryId) === -1 ? 'N' : 'Y';
      return o;
    });
    this.riskService.updateCategory(this.riskCategoryData).subscribe(resp => {
      if (resp && resp.status === 'SUCCESS') {
        this.getRiskCategoryImpactData();
        this.messageService.change(new Message(`Successfully updated  Category(s).`, 'success'));
      }
    }, error => {
      this.messageService.change(new Message('Error! Not able to update Category(s).', 'danger'));
    });
   }

  openCloneCategoryModal() {
    this.cloneCtgModal = true;
  }

  private init = () => {
    this.project = new Project;
  }

  setNameOrId = (ref) => {
    this.project.prjName = this.project.prjId = null;
    this.isNumeric = false;
    if (ref.value && isNaN(ref.value)) {
      this.project.prjName = ref.value;
    } else if (ref.value) {
      this.isNumeric = true;
      this.project.prjId = Number(this.project.afeNo);
      this.project.afeNo = ref.value = this.project.prjId.toString();
    }
  }
  searchProject() {
    this.projectSearchService.searchProject(this.project);
    this.isSaveDisable = false;
  }


  radioCheck = (checked: boolean, prjId: number) => {
    if (checked) {
      this.tempPrgId = prjId;
      this.isSaveDisable = true;
    } else {
      this.tempPrgId = null;
      this.isSaveDisable = false;
    }
  }

  @HostListener('document:keypress', ['$event']) handleKeyboardEvent(event: KeyboardEvent) {
    this.isSaveDisable = false;
  }

  @HostListener('document:keydown.backspace', ['$event']) onKeydownHandlerBackspace(event: KeyboardEvent) {
    this.isSaveDisable = false;
  }

  @HostListener('document:keydown.delete', ['$event']) onKeydownHandlerDelete(event: KeyboardEvent) {
    this.isSaveDisable = false;
  }

 
  // saveClonedCtg() {
  //   this.riskService.getRiskCategoryImpactDesc(this.tempPrgId).subscribe(data => {
  //     this.messageService.change(new Message(`Please wait......`, 'info'));
  //     this.cloneCtg = data;
  //     this.cloneCtg.map(m => m.progId = this.progId)
  //     this.riskService.cloneRiskCategory(this.cloneCtg).subscribe(resp => {
  //       if (resp.messages) {
  //         this.cloneMsg = [];
  //         this.getRiskCategoryImpactData();
  //         resp.messages.forEach(m => this.cloneMsg.push(new Message(m.data, 'success')));
  //         this.messageService.change(new Message('Successfully cloned  Category(s).', 'success'));
  //       }
  //     }, error => {
  //       this.messageService.change(new Message('Error! Not able to cloned Category(s).', 'danger'));
  //     });

  //   });
  //   this.messageService.change(null);
  //   this.cloneCtgModal = false;
  // }

  resetProjSearch = () => {
    this.init();
    this.projectSearchService.reset();
  }


  updateProjLastModDate() {
    this.projectService.updateProjLastModDate(this.progId).subscribe(resp => {
      this.messageService.change(new Message(`Please wait......`, 'info'));
      if (resp && resp.status === 'SUCCESS') {
        this.projectService.getProject(this.progId).subscribe(p => {
          if (p) {
            this.subscription = this.dashboardService.projectDetails.subscribe(data => {
              if (data != null) {
                this.projectDetail = data.find(p => p.prjId === this.progId);
                if (this.projectDetail) {
                  if (this.projectDetail.lastUpdtTsTemp) {
                    this.projectDetail.lastUpdtTsTemp = p.lastUpdtTs;
                  }
                }
              }
            });
          }
        });
      }
    }, error => {
      this.messageService.change(new Message(`Error! Not able to redirect  Program #${this.progId} details`, 'danger'));
    });
    this.router.navigateByUrl(`/web/programs/detail/${this.progId}`);
    this.messageService.changes(null);
  }


  saveCategory() {
    this.messageService.change(new Message(`Please wait......`, 'info'));
    const temp = this.riskCategoryData.filter(c => c.catgryType === 'Program');
    if (!this.riskCategoryObj.catgryId && temp.length >= 5) {
      this.messageService.change(new Message('Limit exceeded, Max Limit is 5 for additional Category.', 'danger'));
    } else {
      this.riskService.saveCategory(this.riskCategoryObj).subscribe(resp => {
        if (resp && resp.status === 'SUCCESS') {
          this.getRiskCategoryImpactData();
          this.isUpdateEnable ? this.messageService.change(new Message(`Category successfully updated.`, 'success')) : this.messageService.change(new Message(`Category successfully added.`, 'success'));
        }
      }, error => {
          this.isUpdateEnable ? this.messageService.change(new Message(`Error! Not able to update Category.`, 'danger')) : this.messageService.change(new Message(`Error! Not able to add Category..`, 'danger'));
        }
      );
    }
    this.categoryModal = false;
  }


  ngOnDestroy () {
  //  this.subscription.unsubscribe();
  //  this.resetProjSearch();
  }


}
