import { Component, OnInit, OnDestroy } from '@angular/core';

import { TableData } from '@app/common';
import { AppService } from '../../app.service';
import { DashboardService } from './dashboard.service';
import { MessageService, Message } from '../../common/message.service';
import { Subscription } from 'rxjs/Subscription';
import { ProjectDetail, SubDesignTeam} from '../projects/projects.model';
import { ReportService } from '../reports/report.service';
import { RiskService } from '../projects/risk/risk.service';
import { RiskDatasource, RiskCategoryData } from '../projects/risk/risk.model';
import { UserService } from '../../common/user.service';
import { ProjectService } from '../projects/projects.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html'
})
export class DashboardComponent implements OnInit, OnDestroy {

  subscription: Subscription;
  datasource: TableData<ProjectDetail>;
  riskDetails: RiskDatasource[];
  riskCategoryData: RiskCategoryData[];
  subDesignTeam: SubDesignTeam[];
  subTeamlist: SubDesignTeam[];
  designTeamlist: SubDesignTeam[];

  constructor(public messageService: MessageService,
    public dashboardService: DashboardService,
    public app: AppService,
    private projectService: ProjectService,
    private riskService: RiskService,
    private userService: UserService,
    public reportService: ReportService) { }

    ngOnInit() {
      this.messageService.change(new Message(`Loading dashboard details...`, 'info'));
      this.subscription = this.dashboardService.projectDetails.subscribe(data => {
        if (data != null) {
          setTimeout(() => {
            this.datasource = new TableData(data, (pd, s) => pd.filter(p => 
              ['#' + p.prjId, p.prjName, p.prjOwner, p.roleName, p.prjStatus, p.prjType, p.unit]
              .filter(f => f).findIndex(f => f.toString().toLowerCase().includes(s.toLowerCase())) !== -1));
          });
          this.messageService.change(null);
        }
      });
    }

  get user() { return this.userService.getUser(); }

  downloadImportTemplate(row: ProjectDetail) {
  this.messageService.change(new Message(`Preparing to download program risk details. Please wait...`, 'info'));
    this.riskService.getPrgRiskCatDetails(row.prjId).subscribe(rdata => {
      this.subTeamlist = rdata.subTeamlist;
      this.designTeamlist = rdata.designTeamlist;
      this.riskCategoryData = rdata.riskCategoryData;
      this.riskDetails = rdata.riskMtgtn.map(data => this.riskService.convertRiskDatasource(data, this.riskCategoryData , this.subTeamlist, this.designTeamlist));
      if (this.riskDetails.length > 0) {
        this.reportService.generateRiskDetailsSheet( this.riskDetails, row);
      } else {
        this.messageService.change(new Message(`No data available for program #` + row.prjId , 'warning'));
      }
      }, error => {
      this.messageService.change(new Message('Not able to download program risk details. Please contact support team.', 'danger'));
    });
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
