
import { ProjectDetail, Project, ProjectMapDetail, ProjectTeamDetail } from '../projects/projects.model';
import { ProjectService } from '../projects/projects.service';
import { CapitalizePipe } from '../../common/capitalize.pipe';
import { UserService } from '../../common/user.service';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Injectable } from '@angular/core';
import { AppService } from '../../app.service';
import { DatePipe } from '@angular/common';

@Injectable()
export class DashboardService {
  private projectSource = new BehaviorSubject<Project[]>(null);
  projects = this.projectSource.asObservable();
  private projectDetailSource = new BehaviorSubject<ProjectDetail[]>(null);
  projectDetails = this.projectDetailSource.asObservable();

  roleOnly = false;
  loaded = false;

  constructor(
    private projectService: ProjectService,
    private capitalizePipe: CapitalizePipe,
    private userService: UserService,
    private datePipe: DatePipe,
    private app: AppService) { }

  init = () => {
    if (!this.roleOnly) {
      this.projectSource.next(null);
      this.projectDetailSource.next(null);
      this.projectService.getAllProjects().subscribe(data => {
        if (!this.loaded) {
          const uids = new Set();
          data.forEach(d => uids.add(d.prjOwner).add(d.prjManager).add(d.prjDirector).add(d.prjMrktDirctor).add(d.prjEngrDirctor).add(d.createdBy));
          const ids = Array.from(uids).filter(id => !this.app.userMap.get(id));
          if (ids.length > 0) {
            this.app.getUsers(Array.from(ids)).subscribe(users => {
              ids.forEach(userId => {
                const user = users.find(u => u.userId === userId);
                this.app.userMap.set(userId, user ? user.fullName : 'User Removed');
              });
              this.loaded = true;
              this.setData(data);
            });
          } else {
            this.loaded = true;
            this.setData(data);
          }
        } else {
          this.setData(data);
        }

      }, error => console.error(error));
    } else {
      const access = this.userService.getUser().progAccessMap;
      this.projectSource.next(this.projectSource.getValue().filter(p => access[p.prjId]));
      this.projectDetailSource.next(this.projectDetailSource.getValue().filter(p => access[p.prjId]).map(p => {
        p.role = access[p.prjId];
        return p;
      }));
      this.roleOnly = false;
    }
  }

  private setData = (data: Project[]) => {
    this.app.isLoaded.subscribe(isLoaded => {
      if (isLoaded) {
        this.projectSource.next(data); this.projectDetailSource.next(data.map(p => this.convert(p)));
      }
    });
  }

  getProject = (id: number) => {
    if (this.projectSource.getValue()) {
      return this.projectSource.getValue().find(p => p.prjId === id);
    }
  }

  reload = (roleOnly: boolean) => {
    this.roleOnly = roleOnly;
    this.app.loadUser();
  }


  getRoleName = (role: number) => this.app.getRoleName(role);

  convertSort = (p: Project) => {
    const pd = new ProjectDetail;
    pd.prjId = p.prjId;
    pd.prjName = p.prjName;
    pd.prjTypeId = p.prjTypeId;
    pd.prjStatusId = p.prjStatusId;
    pd.divId = p.divId;
    pd.pltfmId = p.pltfmId;
    pd.prdlnId = p.prdlnId;
    pd.prdfmlyId = p.prdfmlyId;
    pd.unitId = p.unitId;
    pd.prjType = this.app.getType(p.prjTypeId);
    pd.prjTypeAcrnym = this.app.getTypeAcronym(p.prjTypeId);
    pd.prjStatus = this.app.getStatus(p.prjStatusId);
    pd.div = this.app.getDivision(p.divId);
    pd.pltfm = this.app.getPlatfrm(p.pltfmId);
    pd.prdln = this.app.getPrdtLine(p.prdlnId);
    pd.prdfmly = this.app.getPrdtFmly(p.prdfmlyId);
    pd.unit = this.app.getUnit(p.unitId);
    pd.role = this.app.getRole(this.userService.getUser(), p.prjId);
    pd.roleName = this.app.getRoleName(pd.role);
    pd.prjOwnerId = p.prjOwner;
    this.setName(pd, 'prjOwner', p.prjOwner);
    return pd;
  }

  convert = (p: Project) => {
    const pd = new ProjectDetail;
    pd.prjId = p.prjId;
    pd.prjName = p.prjName;
    pd.prjTypeId = p.prjTypeId;
    pd.prjStatusId = p.prjStatusId;
    pd.divId = p.divId;
    pd.pltfmId = p.pltfmId;
    pd.prdlnId = p.prdlnId;
    pd.prdfmlyId = p.prdfmlyId;
    pd.unitId = p.unitId;
    pd.prjType = this.app.getType(p.prjTypeId);
    pd.prjTypeAcrnym = this.app.getTypeAcronym(p.prjTypeId);
    pd.prjStatus = this.app.getStatus(p.prjStatusId);
    pd.div = this.app.getDivision(p.divId);
    pd.pltfm = this.app.getPlatfrm(p.pltfmId);
    pd.prdln = this.app.getPrdtLine(p.prdlnId);
    pd.prdfmly = this.app.getPrdtFmly(p.prdfmlyId);
    pd.unit = this.app.getUnit(p.unitId);
    pd.prjOwnerId = p.prjOwner;
    pd.prjManagerId = p.prjManager;
    pd.prjDirectorId = p.prjDirector;
    pd.prjMrktDirctorId = p.prjMrktDirctor;
    pd.prjEngrDirctorId = p.prjEngrDirctor;
    pd.createdById = p.createdBy;
    this.setName(pd, 'prjOwner', p.prjOwner);
    this.setName(pd, 'prjManager', p.prjManager);
    this.setName(pd, 'prjDirector', p.prjDirector);
    this.setName(pd, 'prjMrktDirctor', p.prjMrktDirctor);
    this.setName(pd, 'prjEngrDirctor', p.prjEngrDirctor);
    this.setName(pd, 'createdBy', p.createdBy);
    pd.currency = p.currency;
    pd.prjStartDate = this.datePipe.transform(p.prjStartDate);
    pd.prjLastAprvl = this.datePipe.transform(p.prjLastAprvlDt);
    pd.prjCmpltDt = this.datePipe.transform(p.prjCmpltDt);
    pd.prjEndDt = this.datePipe.transform(p.prjEndDt);
    pd.dstRlsDt = this.datePipe.transform(p.dstRlsDt);
    pd.createdTs = this.datePipe.transform(p.createdTs);
    pd.afeNo = p.afeNo;
    pd.totalPartCount = p.totalPartCount;
    pd.newPartCount = p.newPartCount;
    pd.role = this.app.getRole(this.userService.getUser(), p.prjId);
    pd.roleName = this.app.getRoleName(pd.role);
    pd.lastUpdtTs = this.datePipe.transform(p.lastUpdtTs);
    pd.lastUpdtTsTemp = p.lastUpdtTs;
    pd.createdTsTemp = p.createdTs;
    return pd;
  }

  setName = (pd: ProjectDetail, field: string, id: string) => {
    const name = this.getName(id);
    if (typeof name === 'string') {
      pd[field] = name;
    } else {
      name.subscribe(response => {
        pd[field] = `${id} (${this.capitalizePipe.transform(response.body, true)})`;
        this.app.userMap.set(id, response.body);
        this.app.fetchUserMap.delete(id);
      }, err => {
        pd[field] = `${id} (User Removed)`;
        this.app.fetchUserMap.delete(id);
      });
    }
  }

  setTeamName = (pd: ProjectTeamDetail) => {
    const name = pd.memberType === 'I' ? this.capitalizePipe.transform(this.app.userMap.get(pd.memberId), true) : `AD Group`;
    pd.memberIdName = `${pd.memberId} (${name})`;
    pd.memberNameId = pd.memberType === 'I' ? `${name} (${pd.memberId})` : pd.memberIdName;
  }

  setGroup = (pd: ProjectTeamDetail, field: string, id: string) => pd[field] = `${id} (AD Group)`;

  getName = (id: string) => {
    if (id && /^[A-Z0-9]{6,7}$/i.test(id)) {
      const name = this.app.userMap.get(id);
      if (name) {
        return `${id} (${this.capitalizePipe.transform(name, true)})`;
      } else {
        let fetchUser = this.app.fetchUserMap.get(id);
        if (!fetchUser) {
          fetchUser = this.app.getUserName(id);
          this.app.fetchUserMap.set(id, fetchUser);
        }
        return fetchUser;
      }
    } else {
      return `${id} (AD Group)`;
    }
  }
}

