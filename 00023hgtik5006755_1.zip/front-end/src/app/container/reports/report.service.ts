import { Http, Headers, RequestOptions, ResponseContentType } from '@angular/http';

import { Injectable } from '@angular/core';
import { MtgtnEmail } from '../projects/risk/risk.service';
import { Resp, AppService } from '../../app.service';
import { MessageService, Message } from '../../common/message.service';
import { UserService } from '../../common/user.service';
import { DatePipe } from '@angular/common';
import { Constant } from '../projects/Constant';
import { RiskDatasource } from '../projects/risk/risk.model';
import { ProjectDetail } from '../projects/projects.model';
import { Row, Cell, Sheet, ExcelData, ExportService, ColWidth } from '../../common/export-service';


@Injectable()
export class ReportService {

  private options = new RequestOptions({ headers: new Headers({ 'Content-Type': 'application/json' }), responseType: ResponseContentType.Blob });

  header: string;

  widths: ColWidth[];

  constructor(private messageService: MessageService,
    private userService: UserService,
    private appService: AppService,
    private datePipe: DatePipe,
    private exportService: ExportService,
    private http: Http) { }


  generateRiskDetailsSheet(riskDetails: RiskDatasource[], program: ProjectDetail) {
    const date = this.datePipe.transform(new Date, Constant.DATE_FORMAT);
    let rows = [];

    rows.push(new Row(['Program #' + program.prjId + '  ' + program.prjName].map(sn => new Cell(sn, null , 4)), { bold: true, color: 'GREY_80_PERCENT', bgcolor: 'GREY_25_PERCENT' }));
    rows.push(new Row([]));
    const heder = ['Risk Title', 'Level', 'Mitigated Level', 'Risk Originator',  'Cause IF', 'Effect THEN', 'Date Created', 'Mitigation Owner', 'Category',
                 'Target Closure', 'Next Review', 'Mitigation Status', 'Owner Subprocess', 'Response Strategy', 'Sub Team', 'Design Team'];
    rows = rows.concat([new Row(heder.map(sn => new Cell(sn)), { bold: true, color: 'GREY_80_PERCENT', bgcolor: 'GREY_25_PERCENT' })]);

    let cells: Cell[];
    riskDetails.forEach(risk => {
        cells = [risk.title, risk.temprskLevel, risk.tempmtgtnLevel, risk.rskCreator].map(sn => new Cell(sn, {wrap: true, align: 'LEFT' }));
        cells = cells.concat([risk.dscCause, risk.dscEffect].map(sn => new Cell(sn, {wrap: true, align: 'LEFT'})));
        cells = cells.concat([this.datePipe.transform(risk.createdTs), risk.mtgtnOwnerName, risk.rskCtgryName, this.datePipe.transform(risk.trgtClosure), this.datePipe.transform(risk.nxtReview),
           risk.mtgtnStatus, risk.subprocess, risk.rsStrtrgyName].map(sn => new Cell(sn, {align: 'LEFT'})));
        cells = cells.concat([risk.mtgtnSubTeamNm, risk.mtgtnDesignTeamNm].map(sn => new Cell(sn, {align: 'LEFT'})));
        rows = rows.concat(new Row(cells));

        this.widths = [0, 4, 5, 14, 15].map(i => new ColWidth(i, 10000))
        .concat([ 1 ].map(i => new ColWidth(i, 3000)));
    });

    const excelData = new ExcelData(`PRM Program#` + program.prjId + '  ' + date,
    [new Sheet('Risk Details', rows, { border: true}, { row: 3, col: 0 }, this.widths)]);

    this.exportService.exportExcel(excelData);
  }


}



