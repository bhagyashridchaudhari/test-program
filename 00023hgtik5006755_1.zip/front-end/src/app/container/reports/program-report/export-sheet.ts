
export class Sheet {
    constructor(public name: String, public rows: Row[], public lock?: Lock, public widths?: ColWidth[],
        public tabColor?: 'r' | 'w', public prctd?: boolean, public validations?: Validation[]) { }
}
export class Row {
    constructor(public cells: Cell[], public height?: number) { }
}

export class Cell {
    constructor(public data: string | number | Date, public style?: 'h' | 'b' | 'n' | 'd' | 'l' | 'r' | 'dt' | 'th'| 'u',
        public colSpan?: number, public comment?: string) { }
}

export class Lock {
    row?: number;
    col?: number;
}

export class ColWidth {
    constructor(public col: number, public width: number) { }
}
export class Validation {
    constructor(public startRow: number, public endRow: number, public startCol: number, public endCol: number,
        public options?: string[], public length?: Range) { }
}

export class Range {
    from?: number;
    to: number;
}
