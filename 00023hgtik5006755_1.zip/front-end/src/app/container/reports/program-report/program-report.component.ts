import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { MessageService, Message } from '../../../common/message.service';
import { DashboardService } from '../../dashboard/dashboard.service';
import { ProjectService } from '../../projects/projects.service';
import { UserService } from '../../../common/user.service';
import { AppService, UserList } from '../../../app.service';
import { RiskService } from '../../projects/risk/risk.service';
import { RiskCategory, RiskStatus, RiskImpact, ResponseStratergy, RiskProbability, RiskDatasource, RiskScoreLevel, RiskMitigation, MitigationPlanOwner, ReportCriteria, RiskCategoryData } from '../../projects/risk/risk.model';
import { SubProcess, SubDesignTeam, ProjectDetail } from '../../projects/projects.model';
import { ChartOption } from '../../../common/chart-options';
import { Color } from 'ng2-charts';
import { TableData } from '@app/common';

@Component({
  selector: 'app-program-report',
  templateUrl: './program-report.component.html',
  styleUrls: ['./program-report.component.css']
})
export class ProgramReportComponent implements OnInit {
  subscription: Subscription;

  programId: number;

  riskCategoryList: RiskCategory[];

  riskStatusList: RiskStatus[];

  riskImpactList: RiskImpact[];

  stratergyList: ResponseStratergy[];

  probabilityList: RiskProbability[];

  riskDetails: RiskDatasource[];

  rskCountArr: RiskScoreLevel[];

  subprocess: SubProcess[];

  mtOwner = new UserList;

  mtgtnOwner: string;

  countSummary= [];

  rskMtgtnObj: RiskDatasource;

  riskCategoryData: RiskCategoryData[];
  riskObj: RiskMitigation[];
  fields = {};

  subTeamlist: SubDesignTeam[];

  designTeamlist: SubDesignTeam[];

  mgtPlanOwnerList: MitigationPlanOwner[];

  selCriteria: ReportCriteria;

  selectedIds: string;

  programReport = { subProcessIds: [0], mtgtnOwnerIds: [0], subTeamIds: [0], designTeamIds: [0] };

  catArr= [];

  rskTitleArr = [];

  chkType: string;  chktypename: string;

  disabledFlag: boolean;

  subPrcssChartData;  mOwnerChartData;  subTmChartData;  designTmChartData; statusChartData;

  subPrcssChartLabels: string[];  mOwnerChartLabels: string[];  subTmChartLabels: string[];  designTmChartLabels: string[];  statusChartLabels: string[];

  chartTypeBar = 'bar';

  chartBarOptions = ChartOption.chartBarOptions;

  private colors = [ '#327F24', '#FFEC1F', '#C21020', '#D3D3D3'];

  chartColors = [{ backgroundColor: this.colors.concat(this.colors) }];

  private scolors = [ '#333333', '#327F24', '#FFEC1F', '#D3D3D3'];

  statusChartColors = [{ backgroundColor: this.scolors.concat(this.scolors) }];

  projectDetail: ProjectDetail;

  spDatasource: TableData<RiskDatasource>;

  moDatasource: TableData<RiskDatasource>;

  stDatasource: TableData<RiskDatasource>;

  dtDatasource: TableData<RiskDatasource>;

  showConfirmEmailModal: boolean;

  message: string;

  prgRiskCategory: RiskCategoryData[];

  riskArr: RiskDatasource[];

  highRskCount: number;

  mediumRskCount: number;

  role: number;

  public barChartColors: Color[] = [{ backgroundColor: '#367C2B' }, { backgroundColor: '#FFDE00' }, { backgroundColor: '#C21020' }, { backgroundColor: '#D3D3D3' }];

  typeList = [{typeName: 'Sub Process', value : 'sprocess'}, {typeName: 'Mitigation Owner', value : 'mowner'}, {typeName: 'Sub Team', value : 'steam'}, {typeName: 'Design Team', value : 'dteam'}];

  constructor(private messageService: MessageService,
    private dashboardService: DashboardService,
    private projectService: ProjectService,
    private userService: UserService,
    private route: ActivatedRoute,
    private app: AppService,
    private riskService: RiskService) { }

  ngOnInit() {
    this.programId = Number(this.route.snapshot.paramMap.get('id'));
    this.selCriteria = new ReportCriteria;
    this.messageService.change(new Message(`Loading program details...`, 'info'));
    this.role = this.app.getRole(this.userService.getUser(), this.programId);
    this.getDistinctMgtOwners();
    this.initRportTemplate();
  }

  get user() { return this.userService.getUser(); }

  initRportTemplate() {
    this.riskCategoryList = this.app.rCategory;
    this.subprocess = this.app.sbProcess;
    this.riskStatusList = this.app.rStatus;
    this.riskImpactList = this.app.rImpact;
    this.stratergyList = this.app.responseStratergy;
    this.probabilityList = this.app.rProbability;
    this.rskCountArr = this.app.rScoreLevel;

    this.subscription =  this.riskService.getPrgRiskCatDetails(this.programId).subscribe(r => {
      this.subTeamlist = r.subTeamlist;
      this.designTeamlist = r.designTeamlist;
      this.riskCategoryData = r.riskCategoryData.filter(p => p.active === 'Y');
      this.riskDetails = r.riskMtgtn.map(data => this.riskService.convertRiskDatasource(data, this.riskCategoryData , this.subTeamlist, this.designTeamlist));
      // to be complete skip risk if risk category is inactive.
      this.riskDetails = this.riskDetails.filter(risk => this.riskCategoryData.filter(c => c.catgryId === risk.rskCtgryId));

      this.generateHeatMap();
      this.generateGraphByStatus();
      this.generateRskTitleCategorySummaryGraph();
      this.messageService.change(null);
    });

  }

  getDistinctMgtOwners() {
    this.riskService.getDistinctOwner(this.programId).subscribe(r => {
      this.mgtPlanOwnerList = r.map(data => this.riskService.convertMgtPlanDatasource(data));
    });
  }

  generateHeatMap() {
    const heatmapData = this.riskDetails.filter( r => r.rsStrtrgyId === 1 && r.mtgtnStatusId !== 4).map(r => r);
    this.rskCountArr = this.rskCountArr.map( element => {
      element.rskCount = heatmapData.filter(r => r.rskScore === Number(element.score)).length;
      element.mtgtnCount = heatmapData.filter(r => r.mtgtnScore === Number(element.score)).length;
     return element;
    });
   this.countSummary = [ heatmapData.filter(r => r.rskLevel === 1).length, heatmapData.filter(r => r.rskLevel === 2).length, heatmapData.filter(r => r.rskLevel === 3).length,
    heatmapData.filter(r => r.mtgtnLevel === 1).length, heatmapData.filter(r => r.mtgtnLevel === 2).length, heatmapData.filter(r => r.mtgtnLevel === 3).length ];
  }

  generateGraphByStatus() {
  //  let statusData = this.riskDetails.filter( r => r.rsStrtrgyId === 1 ).map(r => r);
    // if status is null consider as not started
    const statusData = this.riskDetails.filter( r => r.rsStrtrgyId === 1 ).map( s => {
      s.mtgtnStatusId = s.mtgtnStatusId === 4 ? s.mtgtnStatusId : s.mtgtnStatusId === 3 ? s.mtgtnStatusId : s.mtgtnStatusId === 2 ? s.mtgtnStatusId : 1;
      return s;
    });
// if data not available for all 4 Status array sequence changed so static array taken.
    this.statusChartLabels = ['Not Started', 'In Process', 'Delinquent', 'Complete' ];
    const sresult = this.groupBy(statusData, (p: RiskDatasource) => p.mtgtnStatusId);
    this.statusChartData =  [1, 2, 3, 4].map(i => {
    if (sresult[i]) {
     return sresult[i].length;
    }else {
      return 0;
    }
    });
  }

  generateRskTitleCategorySummaryGraph() {
    const rskCatGraphData = this.riskDetails.filter( r => r.rskCtgryId &&  r.rsStrtrgyId === 1 && (r.mtgtnStatusId === 1 || r.mtgtnStatusId === 2 || r.mtgtnStatusId === 3) && (r.mtgtnLevel === 2 || r.mtgtnLevel === 3)).map(r => r);
    this.riskArr = rskCatGraphData;
    this.highRskCount = rskCatGraphData.filter(r => r.mtgtnLevel === 3).length;
    this.mediumRskCount = rskCatGraphData.filter(r => r.mtgtnLevel === 2).length;
    this.catArr = Array.from(new Set(rskCatGraphData.map((a: RiskDatasource) => a.rskCtgryName)));
    this.rskTitleArr = rskCatGraphData.filter(a => a.mtgtnLevel > 1).map((a: RiskDatasource) => a.title);
  }

  criteriaChanged(selected, chk) {
    this.subPrcssChartData = this.mOwnerChartData = this.subTmChartData = this.designTmChartData = null;
    this.spDatasource = this.moDatasource = this.stDatasource = this.dtDatasource = null;
    if (chk){
       this.chkType = selected.value;
      this.disabledFlag = false;
        if (selected.value === 'mowner' ) {
          this.selCriteria.subProcessIds = null; this.selCriteria.subTeamIds = null; this.selCriteria.designTeamIds = null;
        }
        if (selected.value === 'sprocess') {
          this.selCriteria.mtgtnOwnerIds = null; this.selCriteria.subTeamIds = null; this.selCriteria.designTeamIds = null;
        }
        if (selected.value === 'steam' ) {
          this.selCriteria.subProcessIds = null; this.selCriteria.mtgtnOwnerIds = null; this.selCriteria.designTeamIds = null;
        }
        if (selected.value === 'dteam' ) {
          this.selCriteria.subProcessIds = null; this.selCriteria.subTeamIds = null; this.selCriteria.mtgtnOwnerIds = null;
        }
      }else {
      this.disabledFlag = true;    this.chkType = null;
      this.selCriteria.subProcessIds = null; this.selCriteria.subTeamIds = null; this.selCriteria.designTeamIds = null;  this.selCriteria.mtgtnOwnerIds = null;
    }
  }

  checkAll = (f: string) => {
    const l = f === 'subProcessIds' ? this.subprocess.length :
      f === 'mtgtnOwnerIds' ? this.mgtPlanOwnerList.length :
        f === 'subTeamIds' ? this.subTeamlist.length :
          f === 'designTeamIds' ? this.designTeamlist.length : 0;
  }

  generateChart() {
    if (this.chkType === 'sprocess') {
      this.generateGraphBySubprocess();
    }
    if (this.chkType === 'mowner' ) {
      this.generateGraphByMtgtnOwner();
    }
    if (this.chkType === 'steam' ) {
      this.generateGraphBySubTeam();
    }
    if (this.chkType === 'dteam' ) {
     this.generateGraphByDesignTeam();
    }
  }

  generateGraphBySubprocess() {
    this.subPrcssChartLabels = this.subprocess.map(s => s.acronym);
    const ps = this.riskDetails.filter( r => r.rsStrtrgyId === 1 && (r.mtgtnStatusId && r.mtgtnStatus) && r.mtgtnLevel > 0).filter((p: RiskDatasource) =>
      (this.selCriteria.subProcessIds.length > 0 ? this.selCriteria.subProcessIds.findIndex(id => Number(id) === p.mtgtnSubFunction) !== -1 : true));

    this.spDatasource = new TableData(ps);
    this.subPrcssChartData =  [
      { data: this.countbySubProcessWithLevel( 1, ps), label: 'Low Risk'},
      { data: this.countbySubProcessWithLevel( 2, ps), label: 'Medium Risk' },
      { data: this.countbySubProcessWithLevel( 3, ps), label: 'High Risk' },
      { data: this.countbyClosedSubProcess(ps), label: 'Closed' }
    ];
  }

  private countbySubProcessWithLevel = (type: number, data) => {
    return this.subprocess.map(y => data.filter(f =>  f.mtgtnStatusId < 4 && f.mtgtnLevel === type && f.mtgtnSubFunction === y.id ).length);
  }

  private countbyClosedSubProcess = (data) => {
    return this.subprocess.map(y => data.filter(f => f.mtgtnStatusId === 4 && f.mtgtnLevel > 0 && f.mtgtnSubFunction === y.id ).length);
  }

  generateGraphByMtgtnOwner() {
   let ps = this.riskDetails.filter(r => r.rsStrtrgyId === 1 && r.mtgtnLevel > 0 && (r.mtgtnStatusId && r.mtgtnStatus) && this.selCriteria.mtgtnOwnerIds === r.mtgtnOwner);
   ps = ps.map(p => {
     p.mtgtnLevel = p.mtgtnStatusId === 4 ? 4 : p.mtgtnLevel;
     return p;
   });

   this.moDatasource = new TableData(ps);
   this.mOwnerChartLabels = ['Low Risk', 'Medium Risk', 'High Risk', 'Closed'];
    const result2 = this.groupBy(ps, (p: RiskDatasource) => p.mtgtnLevel);
    const keys2 = Object.keys(result2); // if data not available for all 4 levels array sequence changed so static array taken.
    this.mOwnerChartData =  [1, 2, 3, 4].map(i => {
      if (result2[i]) {
       return result2[i].length;
      }else {
        return 0;
      }
    });
   }

  generateGraphBySubTeam() {
   this.subTmChartLabels = this.subTeamlist.map(s => s.name);
   const steam = this.riskDetails.filter( r => r.rsStrtrgyId === 1 && (r.mtgtnStatusId && r.mtgtnStatus) && r.mtgtnLevel > 0).filter((p: RiskDatasource) =>
      (this.selCriteria.subTeamIds.length > 0 ? this.selCriteria.subTeamIds.findIndex(id =>  Number(id) === Number(p.mtgtnSubTeamId)) !== -1 : true));

     this.stDatasource = new TableData(steam);
     this.subTmChartData =  [
        { data: this.countbysubTmWithLevel( 1, steam), label: 'Low Risk' },
        { data: this.countbysubTmWithLevel( 2, steam), label: 'Medium Risk' },
        { data: this.countbysubTmWithLevel( 3, steam), label: 'High Risk' },
        { data:  this.countbyClosedsubTm(steam), label: 'Closed' }
       ];
  }

  private countbysubTmWithLevel = (type: number, data: RiskDatasource[]) => {
    return this.subTeamlist.map(y => data.filter(f => f.mtgtnStatusId < 4 && f.mtgtnLevel === type && Number(f.mtgtnSubTeamId) === y.id ).length);
  }

  private countbyClosedsubTm = (data: RiskDatasource[]) => {
    return this.subTeamlist.map(y => data.filter(f => f.mtgtnStatusId === 4 && f.mtgtnLevel > 0 && Number(f.mtgtnSubTeamId) === y.id ).length);
  }

  generateGraphByDesignTeam() {
    this.designTmChartLabels = this.designTeamlist.map(s => s.name);
    const dteam = this.riskDetails.filter( r => r.rsStrtrgyId === 1 && (r.mtgtnStatusId && r.mtgtnStatus) && r.mtgtnLevel > 0).filter((p: RiskDatasource) =>
       (this.selCriteria.designTeamIds.length > 0 ? this.selCriteria.designTeamIds.findIndex(id =>  Number(id) === Number(p.mtgtnDesignTeamId)) !== -1 : true));
       this.dtDatasource = new TableData(dteam);
       this.designTmChartData =  [
         { data: this.countbydesignTmWithLevel( 1, dteam), label: 'Low Risk' },
         { data: this.countbydesignTmWithLevel( 2, dteam), label: 'Medium Risk' },
         { data: this.countbydesignTmWithLevel( 3, dteam), label: 'High Risk' },
         { data:  this.countbyCloseddesignTm(dteam)  ,  label: 'Closed' }
        ];
  }

  private countbydesignTmWithLevel = (type: number, data: RiskDatasource[]) => {
    return this.designTeamlist.map(y => data.filter(f =>  f.mtgtnStatusId < 4 && f.mtgtnLevel === type && Number(f.mtgtnDesignTeamId) === y.id ).length);
  }

  private countbyCloseddesignTm = (data: RiskDatasource[]) => {
    return this.designTeamlist.map(y => data.filter(f => f.mtgtnStatusId === 4 && f.mtgtnLevel > 0 && Number(f.mtgtnDesignTeamId) === y.id ).length);
  }

  private groupBy = (ps: RiskDatasource[], f: Function) => {
    const groups = {};
    ps.forEach(function (o) {
      const group = f(o);
      groups[group] = groups[group] || [];
      groups[group].push(o);
    });
    return groups;
  }

  isGenerateDisabled(reportFilterForm) {
    return reportFilterForm.form.pristine || reportFilterForm.form.invalid;
  }

  showMailModal(row: RiskDatasource) {
    this.showConfirmEmailModal = true;  this.rskMtgtnObj = row;
  }

  sendEmail() {
    this.showConfirmEmailModal = false;
    this.dashboardService.projectDetails.subscribe(data => {
      if (data != null) {
        this.projectDetail = data.find(p => p.prjId === this.programId);
    }});

    const list = [];
    const a = this.riskService.setMailBody(this.projectDetail, this.rskMtgtnObj, this.message);
    list.push(a);
    this.messageService.change(new Message(`Sending Mail...`, 'info'));
    this.riskService.sendEmail(list).subscribe(resp => {
      if (resp.status === 'SUCCESS') {
        this.messageService.change(new Message('Mail sent successfully.', 'success') );
      }
    }, error => {
       this.messageService.change(new Message('Not able to sent mail.', 'danger'));
    });
  }

  getColor(r , c) {
     return r.mtgtnLevel === 2 && c === r.rskCtgryName ? 'rsk-cat-graph-moderate' : r.mtgtnLevel === 3 && c === r.rskCtgryName ? 'rsk-cat-graph-high' : 'rsk-cat-graph-not-applicable' ;
  }

  getCategoryCount(c) {
    return this.riskArr.filter( d => d.rskCtgryName === c).length;
  }

  getRiskCategoryImpactDesc() {
    this.riskService.getRiskCategoryImpactDesc(this.programId).subscribe(data => {
    this.riskCategoryData = data.filter(p => p.active === 'Y');
   });
  }


}

export class TempRiskCat {
  riskTitle: string[];
  catId: number[];
  catName: string[];
  catType: string[];
  catTypeId: number;
  mtgtnLevel: number;
  mlevelName: string;
}
