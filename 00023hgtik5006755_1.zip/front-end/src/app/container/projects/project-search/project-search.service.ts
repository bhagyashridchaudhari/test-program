import { MessageService, Message } from '../../../common/message.service';
import { DashboardService } from '../../dashboard/dashboard.service';
import { ProjectDetail, Project } from '../projects.model';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { ProjectService } from '../projects.service';
import { AppService } from '../../../app.service';
import { Injectable } from '@angular/core';

@Injectable()
export class ProjectSearchService {

  private project: Project = null;

  private source = new BehaviorSubject<ProjectDetail[]>(null);

  projectDetails = this.source.asObservable();

  constructor(private messageService: MessageService, private projectService: ProjectService, private dashboardService: DashboardService, private app: AppService) { }

  getSearchProject = () => this.project;

  reset = () => { this.project = null; this.source.next(null); };

  searchProject = (project: Project) => {
    this.messageService.change(new Message(`Searching for programs...`, 'info'));
    const query = ['divId', 'pltfmId', 'prdlnId', 'prdfmlyId', 'unitId', 'prjStatusId', 'prjTypeId', 'prjName', 'prjId', 'prjOwner']
      .filter(s => project[s] != null).map(s => s + '=' + project[s]).join('&');

    this.projectService.searchProject(query).subscribe(projects => {
      this.project = project;
      const ids = Array.from(new Set(projects.filter(p => !this.app.userMap.get(p.prjOwner)).map(p => p.prjOwner)));
      if (ids.length > 0) {
        this.app.getUsers(ids).subscribe(users => {
          ids.forEach(userId => {
            const user = users.find(u => u.userId === userId);
            this.app.userMap.set(userId, user ? user.fullName : 'User Removed');
          });
          this.source.next(projects.map(p => this.dashboardService.convertSort(p)));
          this.messageService.change(null);
        });
      } else {
        this.source.next(projects.map(p => this.dashboardService.convertSort(p)));
        this.messageService.change(null);
      }
    });
  }
}
