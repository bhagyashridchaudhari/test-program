import { ProjectStatus, Division, Platform, ProductLine, ProductFamily, Unit, Project, ProjectType } from '../projects.model';
import { ProjectSearchService } from './project-search.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { AppService, UserList } from '../../../app.service';
import { UserService } from '../../../common/user.service';
import { ProjectDetail } from './../projects.model';
import { Subscription } from 'rxjs/Subscription';
import { TableData } from '@app/common';

@Component({
  selector: 'app-project-search',
  templateUrl: './project-search.component.html'
})
export class ProjectSearchComponent implements OnInit {

  subscription: Subscription;

  datasource: TableData<ProjectDetail>;

  projectStatus: ProjectStatus[];

  divisions: Division[];

  platforms: Platform[];

  productLines: ProductLine[];

  productFamilies: ProductFamily[];

  units: Unit[];

  projectDetails: ProjectDetail[];

  project: Project;

  owners = new UserList;

  isNumeric = false;

  projectTypes: ProjectType[];

  constructor(private projectSearchService: ProjectSearchService,
    private userService: UserService,
    private app: AppService) { }

  ngOnInit() {
    this.init();
    this.projectStatus = this.app.pStatus;
    this.projectTypes = this.app.pTypes.filter(pt => pt.isActive === 'Y');
    this.divisions = this.app.pDivisn;
    this.subscription = this.projectSearchService.projectDetails.subscribe(projectDetails => {
      this.projectDetails = projectDetails;
      this.datasource = new TableData(projectDetails ? projectDetails : []);
    });
    if (this.projectSearchService.getSearchProject() != null) {
      this.project = this.projectSearchService.getSearchProject();
      this.platforms = this.app.getPlatfrmByDiv(this.project.divId);
      this.productLines = this.app.getPrdtLineByPlatfrm(this.project.pltfmId);
      this.productFamilies = this.app.getPrdtFmlyByPrdtLine(this.project.prdlnId);
      this.units = this.app.getUnitByPrdtFmly(this.project.prdfmlyId);
    }
  }

  private init  = () => {
    this.project = new Project;
    this.platforms = [];
    this.productLines = [];
    this.productFamilies = [];
    this.units = this.app.pUnits;
  }

  private setUnits = () => {
    const unitIds = this.app.pSegement.filter(s =>
      (this.project.divId == null || s.id.divId === this.project.divId) &&
      (this.project.pltfmId == null || s.id.pltfmId === this.project.pltfmId) &&
      (this.project.prdlnId == null || s.id.prdlnId === this.project.prdlnId) &&
      (this.project.pltfmId == null || s.id.pltfmId === this.project.pltfmId)).map(s => s.id.unitId);
    this.units = this.app.pUnits.filter(u => unitIds.indexOf(u.unitId) !== -1);
    if (this.project.unitId && this.units.findIndex(u => u.unitId === this.project.unitId) === -1) {
      this.reset(['unitId']);
    }
  }

  setNameOrId = (ref) => {
    this.project.prjName = this.project.prjId = null;
    this.isNumeric = false;
    if (ref.value && isNaN(ref.value)) {
      this.project.prjName = ref.value;
    } else if (ref.value) {
      this.isNumeric = true;
      this.project.prjId = Number(this.project.afeNo);
      this.project.afeNo = ref.value = this.project.prjId.toString();
    }
  }

  canView = (p: ProjectDetail) => p.role !== 0 || this.userService.getUser().admin;

  resetProjSearch = () => {
    this.init();
    this.projectSearchService.reset();
  }

  private reset = (filds: string[]) => filds.forEach(f => this.project[f] = null);

  setPlatform = () => {
    this.platforms = this.app.getPlatfrmByDiv(this.project.divId);
    this.reset(['pltfmId', 'prdlnId', 'prdfmlyId']);
    this.productLines = this.productFamilies = [];
    this.setUnits();
  }

  setProductLine = () => {
    this.productLines = this.app.getPrdtLineByPlatfrm(this.project.pltfmId);
    this.reset(['prdlnId', 'prdfmlyId']);
    this.productFamilies = [];
    this.setUnits();
  }

  setProductFamily = () => {
    this.productFamilies = this.app.getPrdtFmlyByPrdtLine(this.project.prdlnId);
    this.reset(['prdfmlyId']);
    this.setUnits();
  }

  setUnit = () => {
    this.units = this.app.getUnitByPrdtFmly(this.project.prdfmlyId);
    this.reset(['unitId']);
  }

  searchProject = () => this.projectSearchService.searchProject(this.project);

  // tslint:disable-next-line:use-life-cycle-interface
  ngOnDestroy() {
    this.subscription.unsubscribe();
    this.resetProjSearch();
  }

}
