export class Project {

  prjId: number;

  prjName: string;

  prjTypeId: number;

  prjStatusId: number;

  divId: number;

  pltfmId: number;

  prdlnId: number;

  prdfmlyId: number;

  unitId: number;

  prjOwner: string;

  prjManager: string;

  prjDirector: string;

  prjMrktDirctor: string;

  prjEngrDirctor: string;

  currency: string;

  prjStartDate: Date;

  prjLastAprvlDt: Date;

  prjCmpltDt: Date;

  prjEndDt: Date;

  dstRlsDt: Date;

  afeNo: string;

  totalPartCount: number;

  newPartCount: number;

  createdBy: string;

  createdTs: Date;

  pushVTMilestonDates: boolean;

  pushERCMilestonDates: boolean;

  pushTCMilestonDates: boolean;

  lastUpdtTs: Date;

}


type ActiveType = 'Y' | 'N';


type MemberType = 'I' | 'G';


export class ProjectTeam {

  id: ProjectTeamId;

  memberType: MemberType;

  roleId: number;
}

export class ProjectTeamId {

  projId: number;

  memberId: string;
}

export class ProjectStatus {

  statusId: number;

  statusNm: string;

  isActive: ActiveType;

  mappedIds: number[];
}

export class ProjectType {

  typeId: number;

  typeName: string;

  processId: number;

  isActive: ActiveType;

  typeAcronym: string;
}

export class Division {

  divId: number;

  divNm: string;
}

export class Platform {

  pltfmId: number;

  pltfmNm: string;
}

export class ProductLine {

  prdlnId: number;

  prdlnNm: string;
}

export class ProductFamily {

  prdfmyId: number;

  prdfmyNm: string;
}

export class Unit {

  unitId: number;

  unitNm: string;

  unitCd: string;
}

export class Role {

  roleId: string;

  roleNm: string;

  roleDsc: string;
}


export class ProjectDetail {

  prjId: number;

  prjName: string;

  prjTypeId: number;

  prjStatusId: number;

  newStatusId: number;

  divId: number;

  pltfmId: number;

  prdlnId: number;

  prdfmlyId: number;

  unitId: number;

  prjType: string;

  prjStatus: string;

  div: string;

  pltfm: string;

  prdln: string;

  prdfmly: string;

  unit: string;

  prjOwner: string;

  newOwner: string;

  prjManager: string;

  prjDirector: string;

  prjMrktDirctor: string;

  prjEngrDirctor: string;

  prjOwnerId: string;

  prjManagerId: string;

  prjDirectorId: string;

  prjMrktDirctorId: string;

  prjEngrDirctorId: string;

  currency: string;

  prjStartDate: string;

  prjLastAprvl: string;

  prjCmpltDt: string;

  prjEndDt: string;

  dstRlsDt: string;

  afeNo: string;

  totalPartCount: number;

  newPartCount: number;

  createdById: string;

  createdBy: string;

  createdTs: string;

  role: number;

  roleName: string;

  projectMap: ProjectMapDetail[];

  projectTeams: ProjectTeamDetail[];

  lastUpdtTs: string;

  lastUpdtTsTemp: Date;

  createdTsTemp: Date;

  prjTypeAcrnym: string;
}

export class ProjectMapDetail {
  constructor(public appId: number, public mappedId: number, public name: string) { }
}

export class ProjectTeamDetail {

  memberId: string;

  memberIdName: string;

  memberNameId: string;

  memberType: MemberType;

  roleId: number;

  nestedADGroupCnt: number;

  nestedADGroups: string;
}

export class SegementHierarchyId {

  divId: number;

  pltfmId: number;

  prdlnId: number;

  prdfmlyId: number;

  unitId: number;
}

export class SegementHierarchy {

  id: SegementHierarchyId;

  isActive: ActiveType;
}

export class Process {

  processId: number;

  processNm: string;

  processAcronym: string;

  isActive: boolean;
}
export class Phase {

  phaseId: number;

  phaseNo: number;

  phaseNm: string;

  phaseDesc: string;

  processId: number;
}
export class Milestone {

  mlstnId: number;

  mlstnNo: number;

  mlstnNm: string;

  mlstnDesc: string;

  phaseId: number;
}
export class SubProcess {
  id: number;

  name: string;

  description: string;

  status: string;

  acronym: string;

}

export class SubDesignTeam {
  
  id: number;

  name: string;

  prgmId: number;

  type: string;

  isDisplayEdit: boolean = false;

}

