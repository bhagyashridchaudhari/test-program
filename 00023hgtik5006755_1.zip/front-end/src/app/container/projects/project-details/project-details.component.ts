import { ProjectDetail, SubProcess, SubDesignTeam} from '../projects.model';
import { MessageService, Message } from '../../../common/message.service';
import { DashboardService } from '../../dashboard/dashboard.service';
import { Component, OnInit, OnDestroy, Input, ViewChild, ElementRef, HostListener} from '@angular/core';
import { UserService } from '../../../common/user.service';
import { ProjectService } from '../projects.service';
import { AppService, UserList } from '../../../app.service';
import { Subscription } from 'rxjs/Subscription';
import { ActivatedRoute } from '@angular/router';
import { TableData } from '@app/common';
import { RiskStatus, RiskImpact, ResponseStratergy, RiskProbability, RiskCategoryImpact, MitigationPlan, MitigationStatus, RiskMitigation,
  RiskDatasource, RiskCategoryData, RiskScoreLevel, MitigationPlanOwner, RiskImageData} from '../risk/risk.model';
import { RiskService} from '../risk/risk.service';
import { NgForm } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { Preferences, PreferenceService } from '../program-preference/program-preference.service';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { ReportService } from '../../reports/report.service';
import { ExportService } from '../../../common/export-service';

@Component({
  selector: 'app-project-details',
  templateUrl: './project-details.component.html',
  styleUrls: ['./project-details.component.css']
})
export class ProjectDetailsComponent implements OnInit, OnDestroy {

  rskCountArr = [];

  mtgtnCountArr = [];

  subscription: Subscription;

  projectDetail: ProjectDetail;

  projectId: number;

  rmObj: RiskMitigation;  tmpFormData: RiskMitigation;

  expand = false;

  maxHeight = 550;

  defination: string;

  prefModal: boolean;

  stdView = false;

  riskStatusList: RiskStatus[];

  riskImpactList: RiskImpact[];

  stratergyList: ResponseStratergy[];

  probabilityList: RiskProbability[];

  rCagryImpTemp: RiskCategoryImpact[];

  mStatusList: MitigationStatus[];

  subProcessess: SubProcess[];

  mtOwner = new UserList;

  mtOwner1 = new UserList;

  temp: RiskMitigation[];

  datasource: TableData<RiskDatasource>;

  riskDetails: RiskDatasource[];

  temptbl: TempImpactDesc[];

  rskMtgtnObj: RiskDatasource;

  probabilityHelpModal: boolean;

  impactHelpModal: boolean;

  addRiskModal: boolean;

  isUpdateEnable: boolean;

  changeVal: boolean;

  comfModalOpen: boolean;

  showConfirmEmailModal: boolean;

  summaryViewModal: boolean;

  rskLevelTemp: string;

  mLevelTemp: string;

  message: Message[]= [];

  levels: RiskScoreLevel[];

  preference: Preferences;

  heatMapData: { labels: string[], datasets: any[] };

  riskCategoryObject: RiskCategoryData ;

  riskCategorydatasource: TableData<RiskCategoryData>;

  riskCategory: RiskCategoryData;

  category: number;

  prefActionOpen = false;

  ctgryActionOpen = false;

  comfModalOpenCategory:boolean;

  categoryModal= false;

  categoryMode: number;

  riskCategoryData: RiskCategoryData[];

  riskCategoryDataTemp: RiskCategoryData[];

  massupdateModal: boolean;

  mgtPlanOwner: MitigationPlanOwner[];

   timeouts: Map<string, any> = new Map;

   ownerMsg: Message[]= [];

   subDesignTeam: SubDesignTeam[];

  subTeamlist: SubDesignTeam[];

  designTeamlist: SubDesignTeam[];

  ownerObj: MitigationPlanOwner;

  selectedFile1: File;

  selectedFile2: File;

  imageFile1: File;

  imageFile2: File;

  images1: RiskImageData;

  images2: RiskImageData;

  rskCtgFiltered: RiskCategoryData[];

  showProgView: boolean;

  dprefTemp: string;

  pprefTemp: string;

  imgconfmModalOpen: boolean  = false;

  imageId: number;

  mailMessage: string;

  messageType: string;

  @Input('projectDetailInput') projectDetailInput: ProjectDetail;

  @ViewChild('riskForm') private riskForm;

  @ViewChild('headerDef') private headerDef: ElementRef;

  fileselect = false;

  confModalPrjSetup= false;

  imageErrMsg: string;

  imageErrMsg2: string;

  imageUploadWarning: boolean;

  imgURL1: any;

  imgURL2: any;

  constructor(private messageService: MessageService,
    private dashboardService: DashboardService,
    private projectService: ProjectService,
    private userService: UserService,
    private route: ActivatedRoute,
    private app: AppService,
    private datePipe: DatePipe,
    private riskService: RiskService,
    private prefSevice: PreferenceService,
    public reportService: ReportService,
    private exportService: ExportService,
    public _DomSanitizer: DomSanitizer) { }

  ngOnInit () {
    this.messageService.currentMessage.subscribe(m => this.message = m);
    this.projectId = this.projectDetailInput ? this.projectDetailInput.prjId :  Number(this.route.snapshot.paramMap.get('id'));
    this.messageService.change(new Message(`Loading program details...`, 'info'));
    this.subscription = this.dashboardService.projectDetails.subscribe(data => {
      if (data != null) {
        this.projectDetail = data.find(p => p.prjId === this.projectId);
        if (this.projectDetail) {
          this.initRiskDetails();
        } else {
          if (this.userService.getUser().admin) {
            this.projectService.getProject(this.projectId).subscribe(p => {
              this.projectDetail = this.dashboardService.convert(p);
              this.initRiskDetails();
            });
          } else {
            this.messageService.change(new Message(`You are not authorized to access this program`, 'danger'));
          }
        }
      }
    });
  }

get user() { return this.userService.getUser(); }

  initRiskDetails() {
    this.isUpdateEnable = false;
    this.getUserPreference();

    this.riskService.getPrgRiskCatDetails(this.projectId).subscribe(r => {
        this.temp = r.riskMtgtn;
        this.subTeamlist = r.subTeamlist;
        this.designTeamlist = r.designTeamlist;
        this.riskCategoryData =  r.riskCategoryData.filter(p => p.active === 'Y');
        this.riskDetails = r.riskMtgtn.map(data => this.riskService.convertRiskDatasource(data, this.riskCategoryData , this.subTeamlist, this.designTeamlist));

        this.datasource = new TableData(this.riskDetails);
        //  below  if   will open  pop up for preview category risk
      if (this.projectDetail.createdTsTemp && this.projectDetail.lastUpdtTsTemp) {
        const createdTs = this.datePipe.transform(this.projectDetail.createdTsTemp, 'yyyy-MM-dd HH:mm:ss');
        const lastUpdtTs = this.datePipe.transform(this.projectDetail.lastUpdtTsTemp, 'yyyy-MM-dd HH:mm:ss');
        if (createdTs && lastUpdtTs) {
          if (createdTs === lastUpdtTs) {
            if (this.projectDetail.role <= 2 || this.user.admin) {
              this.comfModalOpenCategory = true;
            } else
              if (this.projectDetail.role === 3 || this.projectDetail.role === 4) {
                this.confModalPrjSetup = true;
              }
          }
        }
      }
      this.setStaticDetails();
      this.messageService.change(null);
    });
  }

  getUserPreference() {
    this.messageService.change(new Message(`Loading program details...`, 'info'));
    this.prefSevice.getPreferences(this.projectId).subscribe(r => {
        this.preference = r.body;
        if (this.preference) {
        this.dprefTemp = this.preference && this.preference.defaultPref === 'N' ? this.preference.selectedColumns : null;
        this.pprefTemp = this.preference && this.preference.defaultPref === 'Y' ? this.preference.selectedColumns : null;
        this.stdView = this.preference.defaultPref === 'Y' ? true : false;
        this.showProgView = this.preference && this.preference.defaultPref === 'N' ? true : false;
      }else {
        this.stdView = true;
      }
    });
  }

  savePreference1(obj: Preferences) {
    this.messageService.change(new Message(`Preference save in progress...`, 'info'));
    this.prefSevice.savePreferences(obj).subscribe(resp => {
      if (resp.status === 'SUCCESS') {
        this.preference = resp.body;
        this.dprefTemp = this.preference && this.preference.defaultPref === 'N' ? this.preference.selectedColumns : null;
        this.stdView = this.preference.defaultPref === 'Y' ? true : false;
        this.showProgView = this.preference && this.preference.defaultPref === 'N' ? true : false;
        this.messageService.change(new Message('Preference save successfully.', 'success'));
      }
    }, error => {
      this.messageService.change(new Message('Not able to save preference.', 'danger'));
    });
  }

  displayCol = (f: string) => {
    if (this.preference && this.preference.selectedColumns ) {
      return this.preference.selectedColumns.split(',').map(p => p.trim()).findIndex(p => p === f) !== -1;
    }
    return true;
  }

  setCustomizeView() {
    this.prefModal = true;
    if (this.preference) {
      this.preference.selectedColumns = this.dprefTemp;
    }
  }

  closePrefModal = () => {
    this.prefModal = false;
    this.preference = new Preferences;
    this.preference.selectedColumns = this.pprefTemp ? this.pprefTemp : this.dprefTemp;
  }

  viewAllColmns() {
    if (this.stdView) {
      this.preference.selectedColumns = this.dprefTemp;
      this.stdView = false;
    }else {
      this.preference.selectedColumns = null;
      this.stdView = true;
    }
  }

  resetView = () => {
    this.datasource = new TableData(this.datasource.data);
    this.headerDef.nativeElement.style.top = 0;
    this.headerDef.nativeElement.style.left = 0;
    this.maxHeight = this.expand ? window.innerHeight - 375 : 550;
  }

  createRisk() {
    this.addRiskModal = true;
    this.rmObj = new RiskMitigation();
  }

  setStaticDetails() {
    this.riskStatusList = this.app.rStatus;
    this.riskImpactList = this.app.rImpact;
    this.stratergyList = this.app.responseStratergy;
    this.probabilityList = this.app.rProbability;
    this.mStatusList = this.app.mStatus;
    this.subProcessess = this.app.sbProcess.sort();
    this.levels = this.app.rScoreLevel;
  }

  onRiskFormSubmit(riskMtgtnForm: NgForm) {
    let msg: Message[];
    let tmp;
    let split;
    this.rmObj.prgmId = this.projectId;

    if (this.rmObj && this.rmObj.rskCtgryId) {
      this.riskCategoryDataTemp = this.riskCategoryData.filter(r => r.catgryId === this.rmObj.rskCtgryId).map(r => r);
      if (this.riskCategoryDataTemp.length > 0) {
      tmp = this.riskCategoryDataTemp[0].catgryType;
      split = tmp.split('_');
      if (split[0] === this.riskCategoryDataTemp[0].catgryId && split[1] === 'Edit') {
        this.rmObj.categorySource = 3;
      } else if (split[0] === this.riskCategoryDataTemp[0].catgryId && split[1] === 'Program') {
        this.rmObj.categorySource = 2;
      } else if (split[0] === this.riskCategoryDataTemp[0].catgryId && split[1] === 'default') {
        this.rmObj.categorySource = 1;
      }
      }
    }

    this.addRiskModal = false;
    this.messageService.change(new Message(`Program risk save in progress...`, 'info'));

      this.riskService.saveRisk(this.rmObj).subscribe(resp => {
      if (resp.status === 'SUCCESS') {
        this.rmObj = resp.body;
        if (this.isUpdateEnable) {
        const formdata = new FormData();
        formdata.append('file1', this.selectedFile1 ? this.selectedFile1 : new Blob);
        formdata.append('file2', this.selectedFile2 ? this.selectedFile2 : new Blob);
        formdata.append('progId', this.projectId.toString());
        formdata.append('riskId',  this.rmObj.riskId.toString());
        this.riskService.uploadImage(formdata).subscribe( iResp => {
          if (iResp.status === 'SUCCESS') {
            this.messageService.change(new Message(`Program risk successfully updated.`, 'success'));
            this.resetTableAfterSubmit();
            }
          });
        }else {
          this.messageService.change(new Message(`Program risk successfully created.`, 'success'));
          this.resetTableAfterSubmit();
        }
      }
    }, error => {
      this.messageService.change(new Message(error, 'danger'));
    });
  }

  resetTableAfterSubmit() {
    this.initRiskDetails();
    this.imgURL1 = this.imgURL2 = null;
    this.isUpdateEnable = false;
  }

  selectFile1(event) {
    if (event.target.files && event.target.files[0]) {
      this.selectedFile1 = event.target.files[0];
      const imageSize = (this.selectedFile1.size / (1024 * 1024)).toFixed(2);
      if (Number(imageSize) > 5) {
        this.imageErrMsg = 'Image should be less than 5MB.';
        this.selectedFile1 = this.imageFile1 = this.imgURL1 = null;
        this.imageUploadWarning = true;
        return;
      }
      const reader = new FileReader();
      const imagePath = event.target.files;
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (_event) => {
        this.imgURL1 = reader.result;
      };
    }
  }

  selectFile2(event) {
    if (event.target.files && event.target.files[0]) {
      this.selectedFile2 = event.target.files[0];
      const imageSize = (this.selectedFile2.size / (1024 * 1024)).toFixed(2);
      if (Number(imageSize) > 5) {
        this.imageErrMsg = 'Image should be less than 5MB.';
        this.selectedFile2 = this.imageFile2 = this.imgURL2 = null;
        this.imageUploadWarning = true;
        return;
      }
      const reader = new FileReader();
      const imagePath = event.target.files;
      reader.readAsDataURL(event.target.files[0]);
      reader.onload = (_event) => {
        this.imgURL2 = reader.result;
      };
    }
  }

  isSaveDisabled(riskForm) {
    return riskForm.form.pristine || (!this.user.admin && this.projectDetail.prjStatusId === 4) || riskForm.form.invalid;
  }

  setImpactDescription(obj: RiskMitigation) {
    this.rCagryImpTemp = this.app.getRiskCategoryImpact(obj.rskCtgryId); //old one
      // AS22820  setting the impact desc for category
      if (obj.rskCtgryId != null || obj.rskCtgryId != undefined) {
        this.riskCategoryDataTemp = this.riskCategoryData.filter(r => r.catgryId === obj.rskCtgryId).map(r => r);
        if (this.riskCategoryDataTemp.length > 0) {
          this.riskCategoryDataTemp.filter(t => t.catgryId);
          const t = this.riskCategoryDataTemp[0].impactDesc.map((val, idx) => {
            const a = val.split(':');
            return { id: idx + 1, desc: a };
          });
          this.temptbl = t;
        }
      }
    this.setScoreLevel(obj);
    if (obj.mitigation && obj.mitigation.mtgtnImpactId && obj.mitigation.mtgtnPrbltyId) {
      this.setMtgtnScoreLevel(obj);
    }
  }

  setScoreLevel(obj: RiskMitigation) {
    obj.rskScore = this.app.getRiskScore(obj.impactId, obj.prbltyId);
    obj.rskLevel = this.app.getRiskLevel(obj.impactId, obj.prbltyId);
    this.rskLevelTemp = obj.rskLevel === 1 ? 'L' : obj.rskLevel === 2 ? 'M' : 'H';
  }

  setMtgtnScoreLevel(risk: RiskMitigation) {
      risk.mitigation.mtgtnScore = this.app.getRiskScore(risk.mitigation.mtgtnImpactId, risk.mitigation.mtgtnPrbltyId);
      risk.mitigation.mtgtnLevel = this.app.getRiskLevel(risk.mitigation.mtgtnImpactId, risk.mitigation.mtgtnPrbltyId);
      this.mLevelTemp = risk.mitigation.mtgtnLevel === 1 ? 'L' : risk.mitigation.mtgtnLevel === 2 ? 'M' : 'H';
  }

  getRisk = (risk) => {
    this.messageService.change(new Message(`Loading program risk details...`, 'info'));
    this.isUpdateEnable = true; this.selectedFile1 = this.imageFile1 = null; this.selectedFile2 = this.imageFile2 = null; this.fileselect = false;

    const id = risk.riskId;
    this.riskService.getRisk(id).subscribe(r => {
    this.rmObj = r;
    this.tmpFormData = Object.assign({}, r);
      this.addRiskModal = true; this.setImpactDescription(this.rmObj);
      this.riskService.getImage2(risk.prgmId, risk.riskId).subscribe(resp => {
          this.images1 = resp.body.find( k => k.imgId === 1);
          this.images2 = resp.body.find( k => k.imgId === 2);
          this.messageService.changes(null);
        }, error => {
          this.images1 =  null; this.images2 = null;
          this.messageService.change(new Message('Image is not available for risk.', 'info'));
        });
    });
  }

  private resetForm = () => {
    if (this.riskForm) {
      Object.keys(this.riskForm.form.controls).forEach(control => this.riskForm.form.controls[control].markAsPristine());
    }
    this.changeVal = false;
  }

  private setRisk = () => {
    this.isUpdateEnable ? this.getExistingRisk() : this.initRiskDtls();
  }

  private initRiskDtls = () => {
    this.resetForm();
    this.rmObj = new RiskMitigation;
  }

  private getExistingRisk = () => {
    const tempReset = this.datasource.data.filter(p => p.riskId === this.rmObj.riskId);
    if (tempReset) {
      this.resetForm();
      this.rmObj = this.riskService.convertToRiskObject(tempReset, this.rmObj);
      this.rskLevelTemp = this.rmObj.rskLevel === 1 ? 'L' : this.rmObj.rskLevel === 2 ? 'M' : 'H';
      this.mLevelTemp = this.rmObj.mitigation.mtgtnLevel === 1 ? 'L' : this.rmObj.mitigation.mtgtnLevel === 2 ? 'M' : 'H';
      if ( this.images1 === undefined ) {
        this.selectedFile1 = this.imageFile1 = null;
        this.imgURL1 = null;
      }
      if (this.images2 === undefined) {
        this.selectedFile2 = this.imageFile2 = null;
        this.imgURL2 = null;
      }
    }
  }

  confrmDelete(row: RiskDatasource) {
    this.comfModalOpen = true;
    this.rskMtgtnObj = row;
  }

  displayRiskDetails(row: RiskDatasource) {
    this.messageService.change(new Message(`Loading program risk details...`, 'info'));
    this.rskMtgtnObj = row;
    this.riskService.getImage2(row.prgmId, row.riskId).subscribe(resp => {
      this.images1 = resp.body.find(k => k.imgId === 1);
      this.images2 = resp.body.find(k => k.imgId === 2);
      this.summaryViewModal = true;
      this.messageService.changes(null);
    }, error => {
      this.images1 =  null; this.images2 = null;
      this.messageService.changes(null);
    });
  }

  deleteRisk() {
    this.comfModalOpen = false;
    this.messageService.change(new Message(`Deleting the risk. Please wait...`, 'info'));
    this.riskService.deleteRisk(this.rskMtgtnObj.riskId).subscribe(resp => {
      let msg = [new Message(`Risk successfully deleted.`, 'success')];
      if (resp.messages) {
        msg = msg.concat(resp.messages.map(m => new Message(m.data, 'warning')));
      }
      this.messageService.changes(msg);
    });
    this.removeDeletedRisk(this.rskMtgtnObj);
  }

  removeDeletedRisk = (obj: RiskDatasource): void => {
    this.riskDetails = this.riskDetails.filter(order => order.riskId !== obj.riskId);
    this.datasource = new TableData(this.riskDetails);
  }

  respStrategyChange(obj: RiskMitigation) {
    obj.mitigation = (obj.rsStrtrgyId === 1 && this.isUpdateEnable) ? new MitigationPlan : this.isUpdateEnable ? obj.mitigation :  new MitigationPlan;
  }

  showMailModal(row: RiskDatasource) {
    this.showConfirmEmailModal = true; this.rskMtgtnObj = row;
  }

  sendEmail() {
    this.showConfirmEmailModal = false;
    const list = [];
    const a = this.riskService.setMailBody(this.projectDetail, this.rskMtgtnObj, this.mailMessage);
    list.push(a);
    this.messageService.change(new Message(`Sending Mail...`, 'info'));
    this.riskService.sendEmail(list).subscribe(resp => {
      if (resp.status === 'SUCCESS') {
        this.mailMessage = '';
        this.messageService.change(new Message('Mail sent successfully.', 'success') );
      }
    }, error => {
      this.messageService.change(new Message('Not able to sent mail.', 'danger'));
    });
  }

  openCategoryModel(mode: number) {
    this.categoryMode =  mode ;
    this.categoryModal = true;
  }

  closeModal = () => {
    this.categoryModal = false;
  }

  @HostListener('document:click', ['$event']) clickedOutside($event) {
    if (this.prefActionOpen) {
      this.prefActionOpen = false;
    }
  }

  @HostListener('document:click', ['$event']) clickedCatOutside($event) {
    if (this.ctgryActionOpen) {
      this.ctgryActionOpen = false;
    }
  }

  getDistinctMgtOwners() {
    this.riskService.getDistinctOwner(this.projectId).subscribe(r => {
      this.mgtPlanOwner = r.map(data => this.riskService.convertMgtPlanDatasource(data));
    });
  }

  openMassUpdateModal() {
    this.massupdateModal = true;
    this.ownerObj = new MitigationPlanOwner();
    this.getDistinctMgtOwners();
  }

  updateOwners() {
    let msg: Message[];
    this.massupdateModal = false;
    this.messageService.change(new Message(`Update owner in progress...`, 'info'));
    this.ownerObj.progId = this.projectId;
    if (this.ownerObj.mtgtnOwner === this.ownerObj.futureOwner) {
      this.messageService.change(new Message('Current Owner and Future Owner should not be same.', 'danger'));
    } else {
      this.riskService.updateOwners(this.ownerObj).subscribe(resp => {
        if (resp && resp.status === 'SUCCESS') {
          this.mgtPlanOwner = [];
          msg = [new Message(`Owner successfully updated.`, 'success')];
          this.initRiskDetails();
        }
      }, error => {
        msg = [new Message('Not able to update owner.', 'danger')];
      });
      this.messageService.changes(msg);
    }
  }

  downloadFile(imgId: number) {
    this.exportService.downloadImage(this.projectId, this.rmObj.riskId , imgId);
  //  this.addRiskModal = false;
  }

  saveFile = (blob: Blob, name: string, ext: string) => {
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveOrOpenBlob(blob, name + ext);
    } else {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = name + ext;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
  }

  downloadImportTemplate() {
    if (this.riskDetails.length > 0) {
      this.reportService.generateRiskDetailsSheet( this.riskDetails, this.projectDetail);
    } else {
      this.messageService.change(new Message(`No data available for program #` + this.projectDetail.prjId , 'warning'));
    }
  }

  openImgconfmModal(imgId) {
    this.imgconfmModalOpen = true;
  //  this.addRiskModal = false;
    this.imageId = imgId;
  }

  deleteImage() {
    this.imgconfmModalOpen = false;
    this.messageType = 'info';
    this.riskService.deleteImage(this.projectId, this.rmObj.riskId, this.imageId).subscribe(resp => {
      if (resp.messages) {
        this.imageId === 1 ? this.images1 = null : this.images2 = null;
        this.messageType = 'success';
      }
    }, error => {
      this.messageType = 'danger';
    });
    setTimeout(() => this.messageType = null, 15000); // hide the alert after 2.5s
  }

  get headerMessage() {
    if (this.projectDetail && (this.projectDetail.prjStatusId === 4 || this.projectDetail.prjStatusId === 6)) {
      return 'In ' + (this.projectDetail.prjStatusId === 4 ? 'Completed' : 'Cancelled') + ' state, updating program is not ' + (this.userService.getUser().admin ? 'recommended.' : 'allowed.');
    }
  }

  removeMsg = (msg) => {
    this.messageType = msg = null;
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}

export class TempImpactDesc {
  id: number;
  desc: string[];
}

