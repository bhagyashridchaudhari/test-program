import { MessageService, Message } from '../../../common/message.service';
import { DashboardService } from '../../dashboard/dashboard.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { UserList, AppService } from '../../../app.service';
import { ProjectDetail, Project } from '../projects.model';
import { UserService } from '../../../common/user.service';
import { ProjectService } from '../projects.service';
import { Subscription } from 'rxjs/Subscription';
import { TableData } from '@app/common';

@Component({
  templateUrl: './project-update-status.component.html',
  styles: ['.tooltip-right:after{margin-bottom: -30px;}']
})
export class ProjectUpdateStatusComponent implements OnInit, OnDestroy {

  subscription: Subscription;

  projectDetails: ProjectDetail[];

  datasource: TableData<ProjectDetail>;

  owner: string;

  newOwner: string;

  searchedOwner: string;

  owners = new UserList;

  checkedIds: number[] = [];

  loaded = false;

  progStatusModalOpen  = false;

  constructor(private messageService: MessageService,
    private dashboardService: DashboardService,
    private projectService: ProjectService,
    public userService: UserService,
    private app: AppService) { }

  ngOnInit() {
    this.messageService.change(new Message('Loading program detail...', 'info'));
    this.searchedOwner = this.owner = this.userService.getUser().userId;
    this.subscription = this.dashboardService.projectDetails.subscribe(data => {
      if (data != null && this.owner === this.userService.getUser().userId) {
        this.projectDetails = data.filter(p => p.role === 1 || p.role === 2);
        this.datasource = new TableData(this.projectDetails);
        if (!this.loaded) {
          this.messageService.change(null);
          this.loaded = true;
        }
      }
    }, e => { });
  }

  canNotUpdateStatus = (projectDetail: ProjectDetail) => !this.userService.getUser().admin && (projectDetail.prjStatusId === 4 || projectDetail.prjStatusId === 6);

  searchProject = () => {
    if (this.userService.getUser().admin && this.searchedOwner !== this.owner) {
      this.messageService.change(new Message(`Searching for programs...`, 'info'));
      this.datasource = null;
      this.projectService.searchProject(`prjOwner=${this.owner}`).subscribe(projects => {
        this.projectDetails = projects.map(p => this.dashboardService.convertSort(p));
        this.datasource = new TableData(this.projectDetails);
        this.searchedOwner = this.owner;
        this.messageService.change(null);
      });
    }
  }

  mappedStatus = (statusId: number) => {
    const mappedIds = this.app.pStatus.find(s => s.statusId === statusId).mappedIds;
    return this.app.pStatus.filter(s => mappedIds && mappedIds.findIndex(sId => sId === s.statusId) !== -1);
  }

  checked = (prjId: number) => this.checkedIds.length > 0 && this.checkedIds.findIndex(id => id === prjId) !== -1;

  check = (checked: boolean, prjId: number) => {
    if (checked) {
      this.checkedIds.push(prjId);
    } else {
      const index = this.checkedIds.findIndex(cId => cId === prjId);
      if (index !== -1) {
        this.checkedIds.splice(index, 1);
      }
    }
  }

  updateStatus = () => {
    const projects = this.datasource.data.filter(d => this.checkedIds.findIndex(id => id === d.prjId) !== -1);
    this.messageService.change(new Message(`Updating program status. Please wait...`, 'info'));
    this.projectService.updateProjectStatus(projects.map(p => {
      const project = new Project;
      project.prjId = p.prjId;
      project.prjStatusId = p.newStatusId;
      return project;
    })).subscribe(resp => {
      if (resp.status === 'SUCCESS') {
        projects.forEach(p => {
          const project = this.dashboardService.getProject(p.prjId);
          if (project) {
            project.prjStatusId = p.newStatusId;
          }
          p.prjStatusId = p.newStatusId;
          p.prjStatus = this.app.getStatus(p.newStatusId);
          p.newStatusId = null;
        });
        this.checkedIds = [];
        this.datasource = new TableData(this.datasource.data);
        const msg = [new Message(`Program status successfully updated for program: ${projects.map(p => '#' + p.prjId).join(', ')}.`, 'success')];
        if (resp.messages) {
          resp.messages.forEach(m => msg.push(new Message(m.data, 'warning')));
        }
        this.messageService.changes(msg);
      }
    });
  }

  isValid = () => this.checkedIds.length !== 0 && this.datasource && this.datasource.data.filter(d => this.checkedIds.findIndex(id => id === d.prjId) !== -1).every(d => d.newStatusId != null);

  get projectStatus() { return this.app.pStatus.filter(s => s.isActive === 'Y'); }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
