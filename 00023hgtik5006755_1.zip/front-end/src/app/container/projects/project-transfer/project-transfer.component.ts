import { MessageService, Message } from '../../../common/message.service';
import { DashboardService } from '../../dashboard/dashboard.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { UserList, AppService } from '../../../app.service';
import { ProjectDetail, Project } from '../projects.model';
import { UserService } from '../../../common/user.service';
import { ProjectService } from '../projects.service';
import { Subscription } from 'rxjs/Subscription';
import { TableData } from '@app/common';

@Component({
  templateUrl: './project-transfer.component.html'
})
export class ProjectTransferComponent implements OnInit, OnDestroy {

  subscription: Subscription;

  projectDetail: ProjectDetail;

  projectDetails: ProjectDetail[];

  datasource: TableData<ProjectDetail>;

  owner: string;

  newOwner: string;

  searchedOwner: string;

  owners = new UserList;

  newOwners = new UserList;

  checkedIds: number[] = [];

  invalidIds: number[] = [];

  messages: Message[] = [];

  comfModalOpen = false;

  loaded = false;

  constructor(private messageService: MessageService,
    private dashboardService: DashboardService,
    private projectService: ProjectService,
    public userService: UserService,
    private app: AppService) { }

  ngOnInit() {
    this.messageService.change(new Message('Loading program detail...', 'info'));
    this.searchedOwner = this.owner = this.userService.getUser().userId;
    this.subscription = this.dashboardService.projectDetails.subscribe(data => {
      if (data != null) {
        if (this.owner === this.userService.getUser().userId) {
          this.projectDetails = data.filter(p => p.role === 1 || p.role === 2);
          this.datasource = new TableData(this.projectDetails);
        }
        if (this.messages.length > 0) {
          this.messageService.changes(this.messages);
          this.checkedIds = [];
          this.invalidIds = [];
          this.messages = [];
        } else if (!this.loaded) {
          this.messageService.change(null);
          this.loaded = true;
        }
      }
    }, e => { });
  }

  searchProject = () => {
    if (this.userService.getUser().admin && this.searchedOwner !== this.owner) {
      this.messageService.change(new Message(`Searching for programs...`, 'info'));
      this.datasource = null;
      this.projectService.searchProject(`prjOwner=${this.owner}`).subscribe(projects => {
        this.projectDetails = projects.map(p => this.dashboardService.convertSort(p));
        this.datasource = new TableData(this.projectDetails);
        this.checkedIds = [];
        this.invalidIds = [];
        this.searchedOwner = this.owner;
        this.messageService.change(null);
      });
    }
  }

  checked = (prjId: number) => this.checkedIds.length > 0 && this.checkedIds.findIndex(id => id === prjId) !== -1;

  check = (checked: boolean, prjId: number) => {
    if (checked) {
      this.checkedIds.push(prjId);
    } else {
      const index = this.checkedIds.findIndex(cId => cId === prjId);
      if (index !== -1) {
        this.checkedIds.splice(index, 1);
      }
    }
  }

  transferProjects = () => {
    this.comfModalOpen = false;
    const projects = this.datasource.data.filter(d => this.checkedIds.findIndex(id => id === d.prjId) !== -1);
    const duplicateIds = projects.filter(p => p.prjOwner.includes(p.newOwner)).map(p => '#' + p.prjId);
    if (duplicateIds.length > 0) {
      this.messageService.change(new Message(`New owner must be different from existing owner for programs: ${duplicateIds.join(', ')}.`, 'danger'));
    } else {
      this.messageService.change(new Message(`Updating Program Manager. Please wait...`, 'info'));
      this.projectService.transferProjects(projects.map(p => {
        const project = new Project;
        project.prjId = p.prjId;
        project.prjOwner = p.newOwner;
        project.createdBy = p.createdById;
        if ([p.prjManagerId, p.prjDirectorId, p.prjEngrDirctorId, p.prjMrktDirctorId, p.createdById].findIndex(userId => userId === p.prjOwnerId) !== -1) {
          project.prjManager = p.prjOwnerId;
        }
        return project;
      })).subscribe(resp => {
        if (resp.status === 'SUCCESS') {
          this.messages.push(new Message(`Program manager successfully updated for program(s): ${projects.map(p => '#' + p.prjId).join(', ')}.`, 'success'));
          if (resp.messages) {
            resp.messages.forEach(m => this.messages.push(new Message(m.data, 'warning')));
          }
          this.messageService.change(new Message(`Refreshing programs list. Please wait...`, 'info'));
          if (this.owner !== this.userService.getUser().userId) {
            this.projectService.searchProject(`prjOwner=${this.owner}`).subscribe(prjs => {
              this.projectDetails = prjs.map(p => this.dashboardService.convertSort(p));
              this.datasource = new TableData(this.projectDetails);
              this.dashboardService.reload(false);
            });
          } else {
            this.dashboardService.reload(false);
          }
        }
      }, e => { });
    }
  }

  isValid = () => this.checkedIds.length !== 0 && this.datasource && this.datasource.data.filter(d => this.checkedIds.findIndex(id => id === d.prjId) !== -1).every(d => d.newOwner != null && d.newOwner !== '' && this.validId(d.prjId));

  validId = (prjId: number) => this.invalidIds.findIndex(id => id === prjId) === -1;

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
