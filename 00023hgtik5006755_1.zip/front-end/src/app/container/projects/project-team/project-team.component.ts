import { ProjectDetail, ProjectTeam, Role, ProjectTeamId, ProjectTeamDetail, SubDesignTeam } from '../projects.model';
import { MessageService, Message } from '../../../common/message.service';
import { DashboardService } from '../../dashboard/dashboard.service';
import { AppService, User, UserList } from '../../../app.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { UserService } from '../../../common/user.service';
import { ProjectService } from '../projects.service';
import { ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { TableData } from '@app/common';
import { DatePipe } from '@angular/common';

@Component({
  templateUrl: './project-team.component.html',
  styles: ['.tooltip-right:after{margin-bottom: -30px;}']
})
export class ProjectTeamComponent implements OnInit, OnDestroy {

  subscription: Subscription;

  loggedUser: User;

  projectId: number;

  projectDetail: ProjectDetail = null;

  projectTeam: ProjectTeam;

  roles: Role[];

  users = new UserList;

  teamIds: string[] = [];

  canEdit = false;

  canView = false;

  loaded = false;

  comfModalOpen = false;

  haveNestadeGroup = false;

  msg: Message[];

  datasource: TableData<ProjectTeamDetail>;

  projectTeamDetail: ProjectTeamDetail;

  addMemAcc: boolean = true;

  teamData: SubDesignTeam[];

  arr: SubDesignTeam[];

  sdTeam: SubDesignTeam;

  sdTeamDeleteObj: SubDesignTeam;

  action: string;

  isDisplayEdit: boolean;

  teamDeleteConf: boolean;

  addSubDsgTeam: boolean;

  subdsgInfoModal: boolean;

  sdtAccrdian: boolean = true;
  
  flag = false;

  nextHide = false;

  subDsgTeamdataSrc: TableData<SubDesignTeam>;

  subTeam: SubDesignTeam[];

  designTeam: SubDesignTeam[];

  
  constructor(private dashboardService: DashboardService,
    private messageService: MessageService,
    private projectService: ProjectService,
    private userService: UserService,
    private route: ActivatedRoute,
    private app: AppService, private datePipe: DatePipe) { }

  ngOnInit() {
    this.loggedUser = this.userService.getUser();
    this.projectId = Number(this.route.snapshot.paramMap.get('id'));
    this.messageService.change(new Message(`Loading program details...`, 'info'));
    this.subscription = this.dashboardService.projectDetails.subscribe(data => {
      if (data != null && !this.projectDetail) {
        this.projectDetail = data.find(p => p.prjId === this.projectId);
        if (this.projectDetail) {
          if (this.projectDetail.createdTsTemp && this.projectDetail.lastUpdtTsTemp) {
            const createdTs = this.datePipe.transform(this.projectDetail.createdTsTemp, 'yyyy-MM-dd HH:mm:ss');
            const lastUpdtTs = this.datePipe.transform(this.projectDetail.lastUpdtTsTemp, 'yyyy-MM-dd HH:mm:ss');
            if (createdTs && lastUpdtTs) {
              if (createdTs === lastUpdtTs) {
                this.nextHide = true;
              }
            }
          }
            if (!this.projectDetail.projectTeams) {
            this.messageService.change(new Message(`Loading program team details...`, 'info'));
            this.projectService.getProjectTeam(this.projectId).subscribe(team => {
              this.projectDetail.projectTeams = team;
              this.initTeam();
            });
          } else {
            this.initTeam();
          }
        } else {
          this.projectService.getSortProject(this.projectId).subscribe(res => {
            this.projectDetail = this.dashboardService.convert(res);
            this.messageService.change(new Message(`Loading program team details...`, 'info'));
            this.projectService.getProjectTeam(this.projectId).subscribe(team => {
              this.projectDetail.projectTeams = team;
              this.initTeam();
            });
          });
        }
      }
    });
    this.roles = this.app.pRoles;
    this.initProjectTeam();
    this.getTeamData();
  }

  private setTeam = () => {
    const team = this.projectService.deepCopy(this.projectDetail.projectTeams);
    const ids = Array.from(new Set(team.filter(t => t.memberType === 'I' && !this.app.userMap.get(t.memberId)).map(t => t.memberId)));
      if (ids.length > 0) {
        this.app.getUsers(ids).subscribe(users => {
          ids.forEach(userId => {
            const user = users.find(u => u.userId === userId);
            this.app.userMap.set(userId, user ? user.fullName : 'User Removed');
          });
          team.forEach(t => this.dashboardService.setTeamName(t));
          this.datasource = new TableData(team);
        });
      } else {
        team.forEach(t => this.dashboardService.setTeamName(t));
        this.datasource = new TableData(team);
      }
  }

  getMessage = (userId: string): string => {
    if (userId === this.loggedUser.userId) {
      return 'You are not authorized to modify or delete your own access.';
    }
    const userType = (userId === this.projectDetail.prjManagerId) ? 'Manager of Program Management' :
      (userId === this.projectDetail.prjDirectorId) ? 'Business Director' :
        (userId === this.projectDetail.prjMrktDirctorId) ? 'Marketing Director' :
          (userId === this.projectDetail.prjEngrDirctorId) ? 'Engineering Director' : '';
    return 'You can not delete this member as the member is ' + userType + '.';
  }

  initTeam = () => {
    this.setTeam();
    if (!this.loaded) {
      this.messageService.change(null);
      this.loaded = true;
    }
    this.canEdit = this.projectDetail.role === 1 || this.projectDetail.role === 2 || this.loggedUser.admin;
    this.canView = this.projectDetail.role !== 0 || this.loggedUser.admin;
  }

  initProjectTeam = () => {
    this.projectTeam = new ProjectTeam();
    this.projectTeam.id = new ProjectTeamId();
    this.projectTeam.id.projId = this.projectId;
    this.projectTeam.memberType = 'I';
    this.projectTeam.roleId = 4;
  }

  addTeamMember = (memId, action: string) => {
    this.action = action;
    this.projectTeam.id.memberId = this.projectTeam.id.memberId.trim().toUpperCase();
    if (this.projectTeam.id.memberId === this.userService.getUser().userId) {
      this.messageService.change(new Message('You can not add yourself as a member.', 'danger'));
    } else if (this.projectDetail.prjOwnerId === this.projectTeam.id.memberId) {
      this.messageService.change(new Message('Program Manager has full control permissions which are not modifiable.', 'danger'));
    } else if (this.datasource.data.findIndex(t => t.memberId === this.projectTeam.id.memberId) !== -1) {
      this.messageService.change(new Message('User is already a team member.', 'danger'));
    } else {
      this.messageService.change(new Message(`New team member addition in progress...`, 'info'));
      this.projectService.saveProjectTeam(this.projectTeam).subscribe(resp => {
      if (resp.status !== 'ERROR') {
        this.projectTeamDetail = resp.body;
        this.projectDetail.projectTeams.push(resp.body);
        this.setTeam();
        this.initProjectTeam();
        this.dashboardService.reload(true);
        if (this.projectTeamDetail.memberType === 'G' && this.projectTeamDetail.nestedADGroupCnt > 0) {
          this.messageService.change(null);  this.haveNestadeGroup = true;
        }else {
          this.messageService.change(new Message(`Added member/group ` + this.projectTeamDetail.memberId + '.', 'success'));
        }
      } else {
     this.messageService.changes(resp.messages.map(m => new Message(m.data, m.type === 'SUCCESS' ? 'success' : 'danger')));
  }

 }, e => { });
}
  
}

  canDelete = (id) => this.loggedUser.userId !== id && this.projectDetail.prjManagerId !== id && this.projectDetail.prjDirectorId !== id && this.projectDetail.prjEngrDirctorId !== id && this.projectDetail.prjMrktDirctorId !== id;

  toDelete = (projectTeamDetail: ProjectTeamDetail) => {
    if (this.canDelete(projectTeamDetail.memberId)) {
      this.projectTeamDetail = projectTeamDetail;
      this.comfModalOpen = true;
    }
  }

  deleteTeamMember = (action: string) => {
    this.action = action;
    const projectTeamDetail = this.projectTeamDetail;
    this.comfModalOpen = false;
    if (this.canDelete(projectTeamDetail.memberId)) {
      this.messageService.change(new Message(`Removing team member from program team...`, 'info'));
      this.projectService.deleteProjectTeam(this.projectId, projectTeamDetail.memberId, projectTeamDetail.memberType).subscribe(resp => {
      if (resp.status !== 'ERROR') {
        this.projectDetail.projectTeams = this.projectDetail.projectTeams.filter(t => t.memberId !== projectTeamDetail.memberId);
        this.setTeam();
        this.initProjectTeam();
        this.dashboardService.reload(true);
        this.projectTeamDetail = resp.body;
        if (this.projectTeamDetail.memberType === 'G' && this.projectTeamDetail.nestedADGroupCnt > 0) {
          this.haveNestadeGroup = true;
          this.messageService.change(null);
        }else {
            this.messageService.change(new Message(`Removed member/group ` + this.projectTeamDetail.memberId + '.', 'success'));
        }
      }else {
          this.messageService.changes(resp.messages.map(m => new Message(m.data, m.type === 'SUCCESS' ? 'success' : 'danger')));
      }
     }, e => { });
    } else {
      this.messageService.change(new Message(`You are not authorized to delete this member.`, 'danger'));
   }
  }

  updateTeamMember = (projectTeamDetail: ProjectTeamDetail) => {
    if (this.loggedUser.userId !== projectTeamDetail.memberId) {
      this.messageService.change(new Message(`Updating team member access...`, 'info'));
      this.projectService.updateProjectTeam(this.getProjectTeam([projectTeamDetail])).subscribe(resp => {
        this.projectDetail.projectTeams = this.projectDetail.projectTeams.filter(t => t.memberId !== projectTeamDetail.memberId);
        this.projectDetail.projectTeams.push(projectTeamDetail);
        this.setTeam();
        const msg = [new Message(`Updated ${projectTeamDetail.memberType === 'I' ? 'member ID' : 'AD group Name'} ${projectTeamDetail.memberId}.`, 'success')];
        if (resp.messages) {
          resp.messages.forEach(m => msg.push(new Message(m.data, 'warning')));
        }
        this.messageService.changes(msg);
        this.initProjectTeam();
        this.dashboardService.reload(true);
      }, e => { });
    }
  }

  updateSelectedTeam = () => {
    this.messageService.change(new Message(`Updating team member access...`, 'info'));
    const toUpdate = this.datasource.data.filter(t => this.teamIds.indexOf(t.memberId) !== -1);
    this.projectService.updateProjectTeam(this.getProjectTeam(toUpdate)).subscribe(resp => {
      this.projectDetail.projectTeams = this.projectDetail.projectTeams.filter(t => this.teamIds.indexOf(t.memberId) === -1);
      this.projectDetail.projectTeams = this.projectDetail.projectTeams.concat(toUpdate);
      this.setTeam();
      const msg = [new Message(`Updated members/AD groups are ${this.teamIds.join(', ')}.`, 'success')];
      if (resp.messages) {
        resp.messages.forEach(m => msg.push(new Message(m.data, 'warning')));
      }
      this.messageService.changes(msg);
      this.initProjectTeam();
      this.teamIds = [];
      this.dashboardService.reload(true);
    }, e => { });
  }

  changeRole = (i, val) => this.projectDetail.projectTeams[i].roleId = val;

  getProjectTeam = (projectTeamDetails: ProjectTeamDetail[]) => {
    const projectTeam: ProjectTeam[] = [];
    projectTeamDetails.forEach(ptd => {
      const proTeam = new ProjectTeam();
      proTeam.id = new ProjectTeamId();
      proTeam.id.projId = this.projectId;
      proTeam.id.memberId = ptd.memberId;
      proTeam.memberType = ptd.memberType;
      proTeam.roleId = ptd.roleId;
      projectTeam.push(proTeam);
    });
    return projectTeam;
  }

  addRmvMemId = (e, mbrId) => {
    if (e.target.checked) {
      this.teamIds.push(mbrId);
    } else {
      this.teamIds = this.teamIds.filter(item => item !== mbrId);
    }
  }

  chkMem = (mbrId) => this.teamIds.indexOf(mbrId) !== -1;

  getTeamData() {
    this.projectService.getMtgtnTeam(this.projectId).subscribe(r => {
      this.teamData = r;
      this.subDsgTeamdataSrc = new TableData<SubDesignTeam>(this.teamData);
    });
  }

  saveTeam() {
    this.messageService.change(new Message(`Team save in progress...`, 'info'));
    this.projectService.saveMtgtnTeam(this.sdTeam).subscribe(resp => {
        if (resp.status === 'SUCCESS') {
          this.messageService.change(new Message(`Team successfully added.`, 'success'));
          this.getTeamData();
        }
    }, error => {
      this.messageService.change(new Message('Error! Not able to add Team.', 'danger'));
    });
  }

  updateTeam(row: SubDesignTeam, type: string) {
    this.flag = false;
    this.teamData = [];
    if (row.isDisplayEdit) {
      this.projectService.getMtgtnTeam(this.projectId).subscribe(r => {
        this.teamData = r;
        if (type === 'S' || type === 'D') {
          if (row.name.trim().length === 0) {
            this.messageService.change(type === 'S' ? new Message('Sub Team name can not be empty.', 'danger') : new Message('Design Team name can not be empty.', 'danger'));
            return this.flag = true;
          } else {
            if (this.teamData.findIndex(t => t.name === row.name) !== -1) {
              this.messageService.change(type === 'S' ? new Message('Sub Team name already present.', 'danger') : new Message('Design Team name already present.', 'danger'));
              return this.flag = true;
            } else {
              if (this.flag == false) {
                this.updateSDTeam(row, type);
              }
            }
          }
        }
      }, error => {
        this.messageService.change(new Message('Error! Not able to update Team.', 'danger'));
      });
    }
  }

  updateSDTeam(row, type) {
    const t = new SubDesignTeam;
    t.id = row.id;
    t.name = row.name;
    t.prgmId = row.prgmId;
    t.type = type;
    this.messageService.change(new Message(`Team update in progress...`, 'info'));
    this.projectService.saveMtgtnTeam(t).subscribe(resp => {
      if (resp.status === 'SUCCESS') {
        this.messageService.change(new Message(`Team successfully updated.`, 'success'));
      }
      row.isDisplayEdit = false;
    }, error => {
      this.messageService.change(new Message('Error! Not able to update Team.', 'danger'));
    });
  }

  confDeleteTeam(row: SubDesignTeam, action: string) {
    this.teamDeleteConf = true;
    this.sdTeamDeleteObj = row;
  }

  deleteTeam() {
    this.teamDeleteConf = false;
    this.messageService.change(new Message(`Deleting the team. Please wait...`, 'info'));
    this.projectService.deleteMtgtnTeam(this.sdTeamDeleteObj.id).subscribe(resp => {
      let msg = [new Message(`Team successfully deleted.`, 'success')];
      if (resp.messages) {
        msg = msg.concat(resp.messages.map(m => new Message(m.data, 'warning')));
      }
      this.messageService.changes(msg);
    });
    this.removeDeletedTeam(this.sdTeamDeleteObj);

  }

  removeDeletedTeam = (obj: SubDesignTeam): void => {
    if (obj.type === 'S') {
      this.teamData =  this.subDsgTeamdataSrc.data.filter(s => s.id !== obj.id);
      this.subDsgTeamdataSrc = new TableData(this.teamData);
    } else if (obj.type === 'D') {
      this.teamData = this.subDsgTeamdataSrc.data.filter(d => d.id !== obj.id);
      this.subDsgTeamdataSrc = new TableData(this.teamData);
    }
  }

  isSaveDisabled = (pteamform) =>  (pteamform.form.pristine || pteamform.form.invalid);

  isAddDisabled = (dsform) => (dsform.form.pristine || dsform.form.invalid) ;

  sTeamNameChanged = (row) =>  row.isDisplayEdit = true;

  dTeamNameChanged = (row) =>  row.isDisplayEdit = true;

  createDsgSubTeam() {
    this.addSubDsgTeam = true;
    this.sdTeam = new SubDesignTeam;  this.sdTeam.type = 'S';
  }

  addSubDesgTeam() {
    this.subTeam = [];
    this.designTeam = [];
    this.sdTeam.prgmId = this.projectId;
    if (this.sdTeam.type === 'S' || this.sdTeam.type === 'D') {
      this.subTeam = this.subDsgTeamdataSrc.data.filter(s => s.type === 'S');
      this.designTeam = this.subDsgTeamdataSrc.data.filter(d => d.type === 'D');
      if ((this.sdTeam.type === 'S' && this.subTeam.length >= 15) || (this.sdTeam.type === 'D' && this.designTeam.length >= 15)) {
        this.messageService.change(this.sdTeam.type === 'S' ? new Message('Sub Team limit exceeded, max limit is 15.', 'danger') : new Message('Design Team limit exceeded, max limit is 15.', 'danger'));
        this.addSubDsgTeam = false;
      } else if (this.sdTeam.name.trim().length === 0) {
        this.messageService.change(this.sdTeam.type === 'S' ? new Message('Sub Team name can not be empty.', 'danger') : new Message('Design Team name can not be empty.', 'danger'));
        this.addSubDsgTeam = false;
      } else if (this.teamData.findIndex(t => t.name === this.sdTeam.name) !== -1) {
        this.messageService.change(this.sdTeam.type === 'S' ? new Message('Sub Team name already present.', 'danger') : new Message('Design Team name already present.', 'danger'));
        this.addSubDsgTeam = false;
      } else {
        this.saveTeam();
        this.addSubDsgTeam = false;
      }
    }
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
