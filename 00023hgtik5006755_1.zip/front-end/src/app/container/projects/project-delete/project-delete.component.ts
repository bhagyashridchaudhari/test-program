import { MessageService, Message } from '../../../common/message.service';
import { DashboardService } from '../../dashboard/dashboard.service';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { UserList, AppService } from '../../../app.service';
import { UserService } from '../../../common/user.service';
import { ProjectService } from '../projects.service';
import { ProjectDetail } from '../projects.model';
import { Subscription } from 'rxjs/Subscription';
import { TableData } from '@app/common';

@Component({
  templateUrl: './project-delete.component.html',
  styles: ['.tooltip-right:after{margin-bottom: -30px;}']
})
export class ProjectDeleteComponent implements OnInit, OnDestroy {

  subscription: Subscription;

  projectDetail: ProjectDetail;

  projectDetails: ProjectDetail[];

  datasource: TableData<ProjectDetail>;

  owner: string;

  searchedOwner: string;

  owners = new UserList;

  modalOpen = false;

  comfModalOpen = false;

  loaded = false;

  constructor(private messageService: MessageService,
    private dashboardService: DashboardService,
    private projectService: ProjectService,
    public userService: UserService,
    private app: AppService) { }

  ngOnInit() {
    this.messageService.change(new Message('Loading program detail...', 'info'));
    this.searchedOwner = this.owner = this.userService.getUser().userId;
    this.subscription = this.dashboardService.projectDetails.subscribe(data => {
      if (data != null && this.owner === this.userService.getUser().userId) {
        this.projectDetails = data.filter(p => p.role === 1 || p.role === 2);
        this.datasource = new TableData(this.projectDetails);
        if (!this.loaded) {
          this.messageService.change(null);
          this.loaded = true;
        }
      }
    }, e => { });
  }

  canNotDelete = (projectDetail: ProjectDetail) => !this.userService.getUser().admin && (projectDetail.prjStatusId === 4 || projectDetail.prjStatusId === 6);

  searchProject = () => {
    if (this.userService.getUser().admin && this.searchedOwner !== this.owner) {
      this.messageService.change(new Message(`Searching for programs...`, 'info'));
      this.datasource = null;
      this.projectService.searchProject(`prjOwner=${this.owner}`).subscribe(projects => {
        this.projectDetails = projects.map(p => this.dashboardService.convertSort(p));
        this.datasource = new TableData(this.projectDetails);
        this.searchedOwner = this.owner;
        this.messageService.change(null);
      });
    }
  }

  displayProject = (projectDetail: ProjectDetail) => {
    if (!this.canNotDelete(projectDetail)) {
      this.projectDetail = projectDetail;
      this.modalOpen = true;
    }
  }

  deleteProject = () => {
    this.comfModalOpen = false;
    this.messageService.change(new Message(`Deleting the program. Please wait...`, 'info'));
    this.projectService.deleteProject(this.projectDetail.prjId).subscribe(resp => {
      this.projectDetails = this.projectDetails.filter(p => p.prjId !== this.projectDetail.prjId);
      this.datasource = new TableData(this.projectDetails);
      this.dashboardService.reload(true);
      if (this.owner !== this.userService.getUser().userId) {
        this.searchProject();
      }
      let msg = [new Message(`Program successfully deleted. Deleted program #${this.projectDetail.prjId}`, 'success')];
      if (resp.messages) {
        msg = msg.concat(resp.messages.map(m => new Message(m.data, 'warning')));
      }
      this.messageService.changes(msg);
    });
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
