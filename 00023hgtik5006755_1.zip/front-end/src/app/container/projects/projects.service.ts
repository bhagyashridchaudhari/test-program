import { Project, ProjectTeam, ProjectTeamDetail, SubDesignTeam} from './projects.model';
import { HttpClient } from '@angular/common/http';
import { HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Resp } from '../../app.service';
import { MitigationPlan } from './risk/risk.model';

@Injectable()
export class ProjectService {

  constructor(private http: HttpClient) { }

  deepCopy<T>(o: T): T {
    let newo;
    if (Array.isArray(o)) {
      newo = o.slice();
      newo.forEach((v, i) => {
        newo[i] = this.deepCopy(v);
      });
    } else if (o instanceof Object) {
      newo = Object.assign({}, o);
      Object.keys(newo).forEach(k => {
        if (Array.isArray(newo[k])) {
          newo[k] = this.deepCopy(newo[k]);
        }
      });
    } else {
      newo = o;
    }
    return newo;
  }

  getAllProjects = () => this.http.get<Project[]>('/api/projects');

  saveProject = (project: Project) => this.http.post<Resp<Project>>('/api/projects', this.deepCopy(project));

  deleteProject = (prjId: number) => this.http.delete<Resp<Project>>(`/api/projects/${prjId}`);

  getProject = (prjId: number) => this.http.get<Project>(`/api/projects/${prjId}`);

  projectExist = (prjId: number) => this.http.get<Resp<boolean>>(`/api/projects/exist/${prjId}`);

  searchProject = (query: string) => this.http.get<Project[]>(`/api/projects/search?${query}`);

  getSortProject = (prjId: number) => this.http.get<Project>(`/api/projects/sort-detail/${prjId}`);

  updateProjectStatus = (projects: Project[]) => this.http.put<Resp<any>>(`/api/projects/status`, this.deepCopy(projects));

  transferProjects = (projects: Project[]) => this.http.put<Resp<Project>>('/api/projects/transfer', this.deepCopy(projects));

  getProjectTeam = (prjId: number) => this.http.get<ProjectTeamDetail[]>(`/api/project-team/${prjId}`);

  saveProjectTeam = (projectTeam: ProjectTeam) => this.http.post<Resp<ProjectTeamDetail>>('/api/project-team', this.deepCopy(projectTeam));

  updateProjectTeam = (projectTeam: ProjectTeam[]) => this.http.put<Resp<any>>('/api/project-team', this.deepCopy(projectTeam));

  deleteProjectTeam = (prjId: number, memberId: string, type: string) => this.http.delete<Resp<ProjectTeamDetail>>(`/api/project-team/${prjId}`, { params: new HttpParams().set('memberId', memberId).set('type', type) });

  getMtgtnTeam = (prjId: number) => this.http.get<SubDesignTeam[]>(`/api/team/${prjId}`);

  saveMtgtnTeam = (team: SubDesignTeam) => this.http.post<Resp<ProjectTeamDetail>>('/api/team', this.deepCopy(team));

  updateMtgtnTeam = (team: SubDesignTeam[]) => this.http.put<Resp<any>>('/api/team', this.deepCopy(team));

  deleteMtgtnTeam = (id: number) => this.http.delete<Resp<any>>(`/api/team/${id}`);

  updateProjLastModDate = (prjId: number) => this.http.put<Resp<any>>(`/api/projects/updatedate/${prjId}`, null);

}

