export class Constant {

    static readonly riskCategoryList = ['Cost', 'Capital', 'Reliability', 'Manufacturing', 'Implementaton/Quality', 'Serviceability', 'Function/Appearance/Interface', 'Product support/Marketing'];

    static readonly riskStatus = ['Monitoring' , '20% Complete', '40% Complete ', '60% Complete', ' 80% Complete ', 'Closed' ];

    static readonly DATE_FORMAT = 'dd-MMM-yyyy';

    static readonly riskCategoryData: RiskCategoryDetails[]= [
        {
            'riskTitle': 'riskTitle 1',
            'categoryId': 4,
            'category': 'Supplier or Mfg Implementation / Quality',
            'mitigatedLevel': 2,
            'rskCnt': 1,
        },
        {
            'riskTitle': 'riskTitle 2',
            'categoryId': 2,
            'category': 'Capital',
            'mitigatedLevel': 2,
            'rskCnt': 1,
        },
        {
            'riskTitle': 'riskTitle 3',
            'categoryId': 3,
            'category': 'Reliability',
            'mitigatedLevel': 3,
            'rskCnt': 1,
        },
        {
            'riskTitle': 'riskTitle 4',
            'categoryId': 4,
            'category': 'Supplier or Mfg Implementation / Quality',
            'mitigatedLevel': 2,
            'rskCnt': 1,
        },
        {
            'riskTitle': 'riskTitle 5',
            'categoryId': 5,
            'category': 'Serviceability',
            'mitigatedLevel': 2,
            'rskCnt': 1,
        },
        {
            'riskTitle': 'riskTitle 6',
            'categoryId': 6,
            'category': 'Function/Appearance/Interface',
            'mitigatedLevel': 1,
            'rskCnt': 1,
        },
        {
            'riskTitle': 'riskTitle 7',
            'categoryId': 7,
            'category': 'Product Support/Marketing',
            'mitigatedLevel': 2,
            'rskCnt': 1,
        },
        {
            'riskTitle': 'riskTitle 8',
            'categoryId': 7,
            'category': 'Product Support/Marketing',
            'mitigatedLevel': 3,
            'rskCnt': 1,
        },
        {
            'riskTitle': 'riskTitle 9',
            'categoryId': 1,
            'category': 'Cost',
            'mitigatedLevel': 3,
            'rskCnt': 1,
        },
        {
            'riskTitle': 'riskTitle 10',
            'categoryId': 2,
            'category': 'Capital',
            'mitigatedLevel': 2,
            'rskCnt': 1,
        },
        {
            'riskTitle': 'riskTitle 11',
            'categoryId': 3,
            'category': 'Reliability',
            'mitigatedLevel': 3,
            'rskCnt': 1,
        },
        {
            'riskTitle': 'riskTitle 12',
            'categoryId': 6,
            'category': 'Function/Appearance/Interface',
            'mitigatedLevel': 2,
            'rskCnt': 1,
        },
        {
            'riskTitle': 'riskTitle 13',
            'categoryId': 3,
            'category': 'Reliability',
            'mitigatedLevel': 1,
            'rskCnt': 1,
        },
        
    ];


}

export class RiskCategoryDetails {
    riskTitle: string;

    categoryId: number;

    category: string;

    mitigatedLevel: number;

    rskCnt: number;


}