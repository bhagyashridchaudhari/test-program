import { Project, ProjectTeam, ProjectTeamDetail, ProjectDetail, SubDesignTeam} from '../projects.model';
import { HttpClient, HttpHeaders, HttpEvent } from '@angular/common/http';
import { HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AppService, Resp } from '../../../app.service';
import { Risk, RiskMitigation, RiskDatasource, RiskCategoryData, ProgRiskCategory, MitigationPlan, MitigationPlanOwner, RiskImageData, PrgRiskDetails} from './risk.model';
import { ProjectService } from '../projects.service';
import { DashboardService } from '../../dashboard/dashboard.service';
import { CapitalizePipe } from '../../../common/capitalize.pipe';
import { Observable } from 'rxjs';
import { HttpResponse, HttpRequest } from 'selenium-webdriver/http';

@Injectable()
export class RiskService {

  subDesignTeam: SubDesignTeam[];

  subTeamlist: SubDesignTeam[];

  designTeamlist: SubDesignTeam[];

  constructor(  private projectService: ProjectService,
    private app: AppService,
    private capitalizePipe: CapitalizePipe,
    private dashboardService: DashboardService,
    private http: HttpClient) { }


  convertRiskDatasource = (r: RiskMitigation, prjRskCategory: RiskCategoryData[], subTeamlist: SubDesignTeam[], designTeamlist: SubDesignTeam[]) => {
    const rd = new RiskDatasource;
    rd.riskId  = r.riskId;
    rd.title = r.title;
    rd.dscCause = r.dscCause;
    rd.dscEffect = r.dscEffect;
    rd.prgmId = r.prgmId;
    rd.rskCtgryId = r.rskCtgryId;
    rd.prbltyId = r.prbltyId;
    rd.impactId = r.impactId;
    rd.rsStrtrgyId = r.rsStrtrgyId;

    rd.rskCtgryName = this.app.getProgramCatgryName(prjRskCategory, r.rskCtgryId);
    rd.prbltyName = this.app.getRiskProbabiity(r.prbltyId);
    rd.rsStrtrgyName = this.app.getRespStratergy(r.rsStrtrgyId);
    rd.rskScore = this.app.getRiskScore( r.impactId, r.prbltyId);
    rd.rskLevel = this.app.getRiskLevel(r.impactId, r.prbltyId);
    rd.categorySource = r.categorySource;
    rd.temprskLevel =  rd.rskLevel === 1 ? 'L ' + rd.rskScore : rd.rskLevel === 2 ? 'M ' + rd.rskScore : rd.rskLevel === 3 ? 'H ' + rd.rskScore : '';
    rd.createdBy = r.createdBy;
    rd.createdTs = r.createdTs;
    this.setNameByRackFId(rd, 'rskCreator', r.createdBy);
    rd.comment = r.comment;

    if (r.mitigation && r.mitigation.mtgtnId > 0) {
      rd.mtgtnId = r.mitigation.mtgtnId;
      rd.mtgtnTitle = r.mitigation.mtgtnTitle;
      rd.mtgtnDesc = r.mitigation.mtgtnDesc;
      rd.trgtClosure = r.mitigation.trgtClosure;
      rd.nxtReview = r.mitigation.nxtReview;
      rd.mtgtnOwner = r.mitigation.mtgtnOwner;
      rd.mtgtnSubFunction = r.mitigation.mtgtnSubFunction;
      rd.mtgtnDesignTeamId = r.mitigation.mtgtnDesignTeamId;
      rd.mtgtnSubTeamId = r.mitigation.mtgtnSubTeamId;
      rd.mtgtnSubTeamNm = this.getMtgtnSubTeamName(subTeamlist, Number(r.mitigation.mtgtnSubTeamId));
      rd.mtgtnDesignTeamNm = this.getMtgtnDesignTeamName(designTeamlist, Number(r.mitigation.mtgtnDesignTeamId));
      rd.mtgtnStatusId = r.mitigation.mtgtnStatusId;
      rd.mtgtnPrbltyId = r.mitigation.mtgtnPrbltyId;
      rd.mtgtnImpactId = r.mitigation.mtgtnImpactId;
      rd.mtgtnScore = this.app.getRiskScore( r.mitigation.mtgtnImpactId, r.mitigation.mtgtnPrbltyId);
      rd.mtgtnLevel = this.app.getRiskLevel( r.mitigation.mtgtnImpactId, r.mitigation.mtgtnPrbltyId);
      rd.tempmtgtnLevel = rd.mtgtnLevel === 1 ? 'L ' + rd.mtgtnScore : rd.mtgtnLevel === 2 ? 'M ' + rd.mtgtnScore : rd.mtgtnLevel === 3 ? 'H ' + rd.mtgtnScore : '';
      rd.mtgtnProbability = this.app.getMtgtnProbability(r.mitigation.mtgtnPrbltyId);
      rd.mtgtnStatus = this.app.getMtgtnStatus(r.mitigation.mtgtnStatusId);
      rd.subprocess = this.app.getSubprocess(r.mitigation.mtgtnSubFunction);
      this.setNameByRackFId(rd, 'mtgtnOwnerName', r.mitigation.mtgtnOwner);

    }

    return rd;
  }


  setNameByRackFId = (pd: RiskDatasource, field: string, id: string) => {
    const name = this.getNameByRackFId(id);
    if (typeof name === 'string') {
      pd[field] = name;
    } else {
      name.subscribe(response => {
        pd[field] = `${id} (${this.capitalizePipe.transform(response.body, true)})`;
        this.app.userMap.set(id, response.body);
        this.app.fetchUserMap.delete(id);
      }, err => {
        pd[field] = `${id} (User Removed)`;
        this.app.fetchUserMap.delete(id);
      });
    }
  }

  getNameByRackFId = (id: string) => {
    if (id && /^[A-Z0-9]{6,7}$/i.test(id)) {
      const name = this.app.userMap.get(id);
      if (name) {
        return `${id} (${this.capitalizePipe.transform(name, true)})`;
      } else {
        let fetchUser = this.app.fetchUserMap.get(id);
        if (!fetchUser) {
          fetchUser = this.app.getUserName(id);
          this.app.fetchUserMap.set(id, fetchUser);
        }
        return fetchUser;
      }
    } else {
      return `${id} (AD Group)`;
    }
  }

  convertMgtPlanDatasource = (r: MitigationPlanOwner) => {
    r.mtgtnOwner = r.mtgtnOwner;
    r.futureOwner = r.futureOwner;
    r.progId = r.progId;
    this.setOwnerNameByRackFId(r, 'mtgtnOwnerName', r.mtgtnOwner);
    return r;
  }

  setOwnerNameByRackFId = (pd: MitigationPlanOwner, field: string, id: string) => {
    const name = this.getNameByRackFId(id);
    if (typeof name === 'string') {
      pd[field] = name;
    } else {
      name.subscribe(response => {
        pd[field] = `${id} (${this.capitalizePipe.transform(response.body, true)})`;
        this.app.userMap.set(id, response.body);
        this.app.fetchUserMap.delete(id);
      }, err => {
        pd[field] = `${id} (User Removed)`;
        this.app.fetchUserMap.delete(id);
      });
    }
  }

  setMailBody = (projectDetail: ProjectDetail, rskMtgtnObj: RiskDatasource, message: string) => {
    const mailData = new MtgtnEmail;
      mailData.progId = projectDetail.prjId;
      mailData.progName = projectDetail.prjName;
      mailData.riskTitle = rskMtgtnObj.title;
      mailData.causeIf = rskMtgtnObj.dscCause;
      mailData.effectThen = rskMtgtnObj.dscEffect;
      mailData.mtgtnPlan = rskMtgtnObj.mtgtnTitle;
      mailData.targetClosure = rskMtgtnObj.trgtClosure;
      mailData.comments = rskMtgtnObj.comment ? rskMtgtnObj.comment : '';
      mailData.mtgtnStatus = rskMtgtnObj.mtgtnStatus;
      mailData.mtgtnOwner = rskMtgtnObj.mtgtnOwner;
      mailData.message = message;
      mailData.rskLevel = rskMtgtnObj.rskLevel === 1 ? 'L' : rskMtgtnObj.rskLevel === 2 ? 'M' : rskMtgtnObj.rskLevel === 3 ? 'H' : '';
      mailData.rskScore = rskMtgtnObj.rskScore;
      mailData.mtgtnLevel = rskMtgtnObj.mtgtnLevel === 1 ? 'L' : rskMtgtnObj.mtgtnLevel === 2 ? 'M' : rskMtgtnObj.mtgtnLevel === 3 ? 'H' : '';
      mailData.mtgtnScore = rskMtgtnObj.mtgtnScore;
      mailData.mtgtnOwnerName = rskMtgtnObj.mtgtnOwnerName;
   return mailData;
  }

  convertToRiskObject = (tempReset: RiskDatasource[], rmObj: RiskMitigation) => {
    rmObj.title = tempReset[0].title;
    rmObj.rskScore = tempReset[0].rskScore;
    rmObj.rskLevel = tempReset[0].rskLevel;
    rmObj.dscCause = tempReset[0].dscCause;
    rmObj.dscEffect = tempReset[0].dscEffect;
    rmObj.mitigation.mtgtnScore = tempReset[0].mtgtnScore;
    rmObj.mitigation.mtgtnLevel = tempReset[0].mtgtnLevel;
    rmObj.rskCtgryId = tempReset[0].rskCtgryId ? tempReset[0].rskCtgryId : null;
    rmObj.impactId = tempReset[0].impactId ? tempReset[0].impactId : null;
    rmObj.rsStrtrgyId = tempReset[0].rsStrtrgyId ? tempReset[0].rsStrtrgyId : null;
    rmObj.comment = tempReset[0].comment ? tempReset[0].comment : null;
    rmObj.mitigation.mtgtnTitle = tempReset[0].mtgtnTitle;
    rmObj.prbltyId = tempReset[0].prbltyId ? tempReset[0].prbltyId : null;
    rmObj.mitigation.mtgtnImpactId = tempReset[0].mtgtnImpactId ? tempReset[0].mtgtnImpactId : null;
    rmObj.mitigation.trgtClosure = tempReset[0].trgtClosure;
    rmObj.mitigation.nxtReview = tempReset[0].nxtReview ? tempReset[0].nxtReview : null;
    rmObj.mitigation.mtgtnOwner = tempReset[0].mtgtnOwner;
    rmObj.mitigation.mtgtnSubFunction = tempReset[0].mtgtnSubFunction;
    rmObj.mitigation.mtgtnStatusId = tempReset[0].mtgtnStatusId ? tempReset[0].mtgtnStatusId : null;
    rmObj.mitigation.mtgtnSubTeamId = tempReset[0].mtgtnSubTeamId ? tempReset[0].mtgtnSubTeamId : null;
    rmObj.mitigation.mtgtnDesignTeamId = tempReset[0].mtgtnDesignTeamId ? tempReset[0].mtgtnDesignTeamId : null;
    rmObj.mitigation.mtgtnPrbltyId = tempReset[0].mtgtnPrbltyId ? tempReset[0].mtgtnPrbltyId : null;
    return rmObj;

  }

  getMtgtnSubTeamName = (subTeamlist: SubDesignTeam[], id: number) => {
    const subTeam = subTeamlist.find(s => s.id === id );
    return subTeam ? subTeam.name : null;
  }

  getMtgtnDesignTeamName = (designTeamlist: SubDesignTeam[], id: number) => {
    const designTeam = designTeamlist.find(s => s.id === id );
    return designTeam ? designTeam.name : null;
  }

  getAllRisk = (prjId: number) => this.http.get<RiskMitigation[]>(`/api/risk/prj/${prjId}`);

  saveRisk = (risk: RiskMitigation) => this.http.post<Resp<RiskMitigation>>('/api/risk', this.projectService.deepCopy(risk));

  uploadImage = (data) => this.http.post<Resp<string>>('/api/risk/uploadImage', data);

  getRisk = (rskId: number) => this.http.get<RiskMitigation>(`/api/risk/${rskId}`);

  deleteRisk = (rskId: number) => this.http.delete<Resp<string>>(`/api/risk/${rskId}`);

  getProgCategories= (progId: number) => this.http.get<ProgRiskCategory[]>(`/api/risk/categories/${progId}`);

  saveCategory= (progCategory: RiskCategoryData) => this.http.post<Resp<RiskCategoryData>>(`/api/risk/category`, progCategory);

  getProgCategoryData= (ctgryId: number, progId: number) => this.http.get<RiskCategoryData>(`/api/risk/category/${ctgryId}`, { params: new HttpParams().set('progId',progId ? progId.toString(): "0")});

  getRiskCategoryImpactDesc= (progId: number) => this.http.get<RiskCategoryData[]>(`/api/risk/category/impact/${progId}`);

  getAllRiskCategory= (progId: number) => this.http.get<RiskCategoryData[]>(`/api/risk/category/all/${progId}`);

  sendEmail = (mailData: MtgtnEmail[]) => this.http.post<Resp<any>>(`/api/risk/mtgtnmail`, mailData);

  getDistinctOwner = (prjId: number) => this.http.get<MitigationPlanOwner[]>(`/api/risk/owner/all/${prjId}`);

  updateOwners= (mitigataion: MitigationPlanOwner) => this.http.post<Resp<MitigationPlanOwner[]>>(`/api/risk/owner/update`, mitigataion);

  updateCategory= (riskCategoryData: RiskCategoryData[]) => this.http.post<Resp<RiskCategoryData[]>>(`/api/risk/category/update`, riskCategoryData);

  getImage (progId: number, riskId: number): Observable<any> {
    return this.http.get(`/api/risk/getImages`, {params: new HttpParams().set('progId', progId.toString()).set('riskId', riskId.toString())});
  }

  getImage2 (progId: number, riskId: number): Observable<any> {
    return this.http.get<Resp<RiskImageData[]>>(`/api/risk/getImages2`, {params: new HttpParams().set('progId', progId.toString()).set('riskId', riskId.toString())});
  }

  deleteImage = (projId: number, riskId: number, imgId: number)  => this.http.delete<Resp<string>>(`/api/risk/image/${imgId}` , {params: new HttpParams().set('progId', projId.toString()).set('riskId', riskId.toString())});

  cloneRiskCategory= (riskCategoryData: RiskCategoryData[]) => this.http.post<Resp<RiskCategoryData[]>>(`/api/risk/category/clone`, riskCategoryData);

  getPrgRiskCatDetails = (prjId: number) => this.http.get<PrgRiskDetails>(`/api/risk/prjRskCat/${prjId}`);

}

export class MtgtnEmail {

  progId: number;
  progName: string;
  riskTitle: string;
  causeIf: string;
  effectThen: string;
  mtgtnPlan: string;
  targetClosure: Date;
  comments: string;
  mtgtnStatus: string;
  mtgtnOwner: string;
  mtgtnOwnerName: string;
  message: string;
  rskLevel: string;
  rskScore: number;
  mtgtnLevel: string;
  mtgtnScore: number;

}
