import { SubDesignTeam } from "../projects.model";

export class Risk {

    riskId: number;
    title: string;
    dsc: string;
    prgmId: number;
    rskCtgryId: number;
    prbltyId: number;
    impactId: number;
    rsStrtrgyId: number;

  //  stsId: number;

    mtgtnId: number;
    createdBy: string;
    createdTs: Date;

    // risk detail fields
    rskCtgryName: string;
    prbltyName: string;
   // impactName: string;
    rsStrtrgyName: string;
    rskScore: number;
    rskLevel: number;
    comment: string;
}

export class ResponseStratergy {
    stratergyId: number;
    stratergyName: string;
}

export class RiskCategory {
    catgryId: number;
    catgryName: string;
    catgryAcronym: string;
    catgryDsc: string;
    isActive: boolean;
 //   constructor(catgryId: number,catgryName: string,catgryDsc?: string,isActive?: boolean){}
}

export class ProgRiskCategory {
    catgryId: number;
    catgryName: string;
    progId: number;
}

export class RiskImpact {
    impactId: number;
  //  impactName: string;
}

export class RiskStatus {
    statusId: number;
    statusName: string;
}

export class RiskProbability {
    prbltyId: number;
    prbltyName: string;
    prbltyDsc: string;
    prbltyTyp: number;
}

export class RiskCategoryImpact {
    id: RiskCategoryImpactId;
    impactDsc: string;
//    impactName: string;
}
export class RiskCategoryImpactId {
    ctgryId: number;
    impactId: number;

}

export class RskCtgryImpactTemp {
    ctgryId: number;
    impactId: number;
 //   impactName: string;
    impactDsc: number;
}


export class RiskScoreLevel {
    id: RiskScoreLevelId;
    score: number;
    level: number;
    rskCount: number;
    mtgtnCount: number;
}

export class RiskScoreLevelId {
    prbltyId: number;
    impactId: number;
}

export class MitigationPlan {
    mtgtnId: number;
    mtgtnTitle: string ;
    mtgtnDesc:  string ;
    trgtClosure:  Date ;
    nxtReview:  Date ;
    mtgtnOwner:  string ;
    mtgtnSubFunction:  number ;
 
    mtgtnSubTeamId:  number ;
    mtgtnDesignTeamId:  number ;

    mtgtnStatusId: number;
    mtgtnPrbltyId: number;
    mtgtnImpactId: number;
    riskId: number;
    mtgtnScore: number;
    mtgtnLevel: number;
    futureOwner: string;
  }

  export class MitigationStatus {
    id: number;
    name: string;
}

export class RiskMitigation {
    riskId: number;
    title: string;
    dscCause: string;
    dscEffect: string;
    prgmId: number;
    rskCtgryId: number;
    prbltyId: number;
    impactId: number;
    rsStrtrgyId: number;
    categorySource: number;
    mtgtnId: number;
    createdBy: string;
    createdTs: Date;
    rskScore: number;
    rskLevel: number;
    comment: string;

    rsStrtrgyName: string;

    mitigation: MitigationPlan;
    selectedFile1: FormData;

    selectedFile2: FormData;

  }

export class RiskDatasource {
    riskId: number;
    title: string;
    dscCause: string;
    dscEffect: string;
    prgmId: number;
    rskCtgryId: number;
    prbltyId: number;
    impactId: number;
    rsStrtrgyId: number;
    mtgtnId: number;
    createdBy: string;
    createdTs: Date;

// risk detail fields
    rskCtgryName: string;
    prbltyName: string;
    rsStrtrgyName: string;
    rskScore: number;
    rskLevel: number;
    temprskLevel: string;
    tempmtgtnLevel: string;

    mtgtnTitle: string ;
    mtgtnDesc:  string ;
    trgtClosure:  Date ;
    nxtReview:  Date ;
    mtgtnOwner:  string ;
    mtgtnSubFunction:  number ;

    mtgtnStatusId: number;
    mtgtnPrbltyId: number;
    mtgtnImpactId: number;
    mtgtnScore: number;
    mtgtnLevel: number;

    mtgtnStatus: string;
    mtgtnProbability: string;
    mtgtnImpact: string;
    subprocess: string;

    mtgtnOwnerName: string;
    rskCreator: string;
    comment: string;

    categorySource: number;

    mtgtnSubTeamId:  number ;
    mtgtnDesignTeamId:  number ;
    mtgtnSubTeamNm:  string ;
    mtgtnDesignTeamNm:  string ;
}

export class RiskCategoryData {

    catgryId: number;

    progId: number;

    catgryName: string;

    impactDesc: string[] = [];

    catgryType: string;

    active: string;

    catgryAcronym: string;

}

export class ProgRiskCategoryImpactId {

    ctgryId: number;

    impactId: number;

    progId: number;
}

export class ProgRiskCategoryImpact {

    id: ProgRiskCategoryImpactId;

//    impactName: string;

    impactDsc: string;
}

export class MitigationPlanOwner {

    mtgtnOwner: string;
    futureOwner: string;
    progId: number;
    mtgtnOwnerName: string;
}

export class ReportCriteria {
    subProcessIds: [0];
    mtgtnOwnerIds: string;
    subTeamIds: [0];
    designTeamIds: [0];
}

export class RiskImageData {

    imgId: number;

    data: string;
}

export class PrgRiskDetails {

    riskCategoryData: RiskCategoryData[];

    subTeamlist: SubDesignTeam[];

    designTeamlist: SubDesignTeam[];

    riskMtgtn: RiskMitigation[];

}

export class ImagesData {

    projId: number;

    imgId: number;

    riskId: number;

    images: File[];

}
