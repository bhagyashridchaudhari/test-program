import { Project, ProjectStatus, ProjectType, Division, ProductLine, Platform, ProductFamily, Unit, Phase, Milestone } from '../projects.model';
import { MessageService, Message } from '../../../common/message.service';
import { DashboardService } from '../../dashboard/dashboard.service';
import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { AppService, UserList } from '../../../app.service';
import { UserService } from '../../../common/user.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ProjectService } from '../projects.service';

@Component({
  selector: 'app-project-create-update',
  templateUrl: './project-create-update.component.html'
})
export class ProjectCreateUpdateComponent implements OnInit {

  project: Project;

  managers = new UserList;

  pmManagers = new UserList;

  directors = new UserList;

  mdirectors = new UserList;

  edirectors = new UserList;

  projectStatus: ProjectStatus[];

  projectTypes: ProjectType[];

  divisions: Division[];

  platforms: Platform[];

  productLines: ProductLine[];

  productFamilies: ProductFamily[];

  units: Unit[];

  phase: Phase[];

  milestone: Milestone[];

  currencies: string[];

  lastDate: Date;

  isUpdateEnable = false;

  inprogress = false;

  isPercentage = false;

  buildModal = false;

  comfModalOpen = false;

  comfImportModal = false;

  comfPerModal = false;

  messages: string[] = [];

  dissociateTarget: HTMLInputElement;

  dissociateIndex: number;

  isMappedPrograms = false;

  isTc = false;

  changeVal = false;

  progTypeModalOpen = false;

  progStatusModalOpen = false;

  savedStstusId = 0;

  pushVTMilestonDates = true;

  pushERCMilestonDates = true;

  pushTCMilestonDates = false;

  role: number;

  isVtChecked = true;

  confirm: (value) => void;

  @Input('projectInput') projectInput: Project;

  @Input('callAfterSave') callAfterSave: (p: Project) => void;

  @Input('back') back: () => void;

  @ViewChild('projectForm') projectForm;

  constructor(private messageService: MessageService,
    private dashboardService: DashboardService,
    private projectService: ProjectService,
    private userService: UserService,
    private route: ActivatedRoute,
    private app: AppService,
    private router: Router) { }

  ngOnInit() {
    this.isUpdateEnable = this.projectInput != null || this.route.snapshot.url.join('').includes('update');
    if (!this.userService.getUser().createAccess) {
      this.messageService.change(new Message(`You are not authorized to ${this.isUpdateEnable ? 'update' : 'create'} any program.`, 'danger'));
      return;
    }
    this.projectTypes = this.app.pTypes;
    this.currencies = this.app.pCurrencies;
    this.divisions = this.app.pDivisn;
    this.phase = this.app.pPhase;
    this.milestone = this.app.pMilestone;
    this.setProject();
  }

  private getProcess = () => this.projectTypes.find(p => p.typeId === this.project.prjTypeId);

  private setProject = () => (this.isUpdateEnable) ? this.getProject() : this.initProject();

  private reset = (filds: string[]) => filds.forEach(f => this.project[f] = null);

  private resetForm = () => {
    if (this.projectForm) {
      Object.keys(this.projectForm.form.controls).forEach(control => this.projectForm.form.controls[control].markAsPristine());
    }

    this.changeVal = false;
  }

  private initProject = () => {
    this.resetForm();
    this.project = new Project;
    ['platforms', 'productLines', 'productFamilies', 'units'].forEach(f => this[f] = []);
    this.projectTypes = this.projectTypes.filter(pt => pt.isActive === 'Y');
    this.projectStatus = this.app.pStatus.filter(ps => ps.statusId === 1 || ps.statusId === 2);

  }

  private getProject = () => {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.messageService.change(new Message(`Loading program details...`, 'info'));
    const project = this.dashboardService.getProject(id);
    if (project) {
      this.finalize(project);
    } else if (this.projectInput) {
      this.finalize(this.projectInput);
    } else {
      this.projectService.getProject(id).subscribe(proj => {
        this.finalize(proj);
      });
    }
  }

  private finalize = (p: Project) => {
    this.role = this.app.getRole(this.user, p.prjId);
    if (!this.user.admin && ((this.role !== 1 && this.role !== 2) || p.prjStatusId === 4)) {
      this.messageService.change(new Message(`You are not authorized to update this program.`, 'danger'));
      return;
    }
    this.resetForm();
    this.savedStstusId = p.prjStatusId;
    const currentStatus = this.app.pStatus.find(s => s.statusId === p.prjStatusId);
    this.projectStatus = [currentStatus].concat(this.app.pStatus.filter(s => currentStatus && currentStatus.mappedIds.findIndex(sId => sId === s.statusId) !== -1));
    this.projectTypes = this.projectTypes;
    this.project = this.projectService.deepCopy(p);

    this.platforms = this.app.getPlatfrmByDiv(this.project.divId);
    this.productLines = this.app.getPrdtLineByPlatfrm(this.project.pltfmId);
    this.productFamilies = this.app.getPrdtFmlyByPrdtLine(this.project.prdlnId);
    this.units = this.app.getUnitByPrdtFmly(this.project.prdfmlyId);
    this.messageService.change(null);

  }

  getPahse = () => this.getProcess() ? this.phase.filter(p => p.processId === this.getProcess().processId) : [];

  getMaxDate = (d: Date) => this.userService.getUser().admin ? d : (d > this.app.today) ? d : this.app.today;

  getMinDate = (d: Date) => this.userService.getUser().admin ? d : (d < this.app.today) ? d : this.app.today;

  getMilestone = (phaseId: number) => this.milestone.filter(p => p.phaseId === phaseId);

  isDateDisable = (d: Date) => !this.userService.getUser().admin && d && d < this.app.today;

  get user() { return this.userService.getUser(); }

  get maxDate() { return this.app.maxDate; }


  isSaveDisabled(projectForm) {
    return (projectForm.form.pristine && !this.changeVal) || (!this.user.admin && this.project.prjStatusId === 4) || projectForm.form.invalid ;
  }

  saveProject = () => {
    if (this.projectForm.form.invalid ) {
      this.messageService.change(new Message(`Please enter valid data to save program.`, 'danger'));
    } else {

      const messages: Message[] = [];
      if (!this.inprogress && messages.length === 0) {
        this.inprogress = true;
        this.messageService.change(new Message(`Program save in progress...`, 'info'));
        this.projectService.saveProject(this.project).subscribe(resp => {
          let msg: Message[];
          this.project = resp.body;
          if (this.isUpdateEnable) {
            msg = [new Message(`Program successfully updated.`, 'success')];
            this.finalize(this.project);

          } else {
            msg = [new Message(`Program #${resp.body.prjId} successfully created. Redirecting to program detail`, 'success')];
            this.initProject();
            setTimeout((msg)=>{this.router.navigateByUrl(`/web/programs/detail/${resp.body.prjId}`)}, 1000);
          }
          if (resp.messages) {
            resp.messages.forEach(m => msg.push(new Message(m.data, 'warning')));
          }
          if (!this.user.admin && this.project.prjStatusId === 4) {
            let i = 10;
            msg = [new Message(`You can not update this project in future as the project is completed. You will be redirect from this page in ${i} seconds.`, 'info')].concat(msg);
            const ref = setInterval(() => {
              msg[0].message = `You can not update this project in future as the project is completed. You will be redirect from this page in ${--i} second${i > 1 ? 's' : ''}`;
              if (i === 0) {
                clearInterval(ref);
                this.router.navigateByUrl(`/web/programs/detail/${this.project.prjId}`);
              }
            }, 1000);
          }
          this.messageService.changes(msg);
          this.dashboardService.reload(false);
          this.inprogress = false;
          if (this.callAfterSave) {
            this.callAfterSave(this.project);
          }
        }, err => this.inprogress = false);
      }
    }
  }

  setPlatform = () => {
    this.platforms = this.app.getPlatfrmByDiv(this.project.divId);
    this.reset(['pltfmId', 'prdlnId', 'prdfmlyId', 'unitId']);
  }

  setProductLine = () => {
    this.productLines = this.app.getPrdtLineByPlatfrm(this.project.pltfmId);
    this.reset(['prdlnId', 'prdfmlyId', 'unitId']);
  }

  setProductFamily = () => {
    this.productFamilies = this.app.getPrdtFmlyByPrdtLine(this.project.prdlnId);
    this.reset(['prdfmlyId', 'unitId']);
  }

  setUnit = () => {
    this.units = this.app.getUnitByPrdtFmly(this.project.prdfmlyId);
    this.reset(['unitId']);
  }

  get today() {
    return this.app.today;
  }


}
