import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Resp } from '../../../app.service';


@Injectable()
export class PreferenceService {

  constructor(private http: HttpClient) { }

  getPreferences = (progId: number) => this.http.get<Resp<Preferences>>(`/api/preference/prj/${progId}`);

  getUserPreferences = () => this.http.get<Resp<Preferences>>(`/api/preference`);

  savePreferences = (preferences: Preferences) => this.http.post<Resp<Preferences>>(`/api/preference`, preferences);

}

export class Preferences {
    id: number;

    userId: string;

    progId: number;

    defaultPref: string;

    selectedColumns: string;

    lastUpdatedBy: string;

    lastUpdatedTimestamp: Date;

    chngSelColmns: string[];

    isChecked: boolean;
}