import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AppService, PreferenceArr } from '../../../app.service';
import { DashboardService } from '../../dashboard/dashboard.service';
import { ProjectService } from '../projects.service';
import { UserService } from '../../../common/user.service';
import { PreferenceService, Preferences } from './program-preference.service';
import { Message, MessageService, MessageType } from '../../../common/message.service';

@Component({
  selector: 'app-program-preference',
  templateUrl: './program-preference.component.html',
  styleUrls: ['./program-preference.component.css']
})
export class ProgramPreferenceComponent implements OnInit {

  @Input() closeModal: () => false;

  @Input() preference: Preferences;

  @Output() savePreference1 = new EventEmitter<Preferences>();

  prgId: number;
  preferenceCols: any[][];
  prefFields = [];
  array: PreferenceArr[];
  checkAll = true;
  leftSide: any[];
  rightSide: any[];

  allColmns: any[][];

  constructor(private userService: UserService,
    private route: ActivatedRoute,
    private app: AppService,
    private messageService: MessageService,
    private prefSevice: PreferenceService) { }

  ngOnInit() {
    this.prgId = Number(this.route.snapshot.paramMap.get('id'));
    let urlContains = this.route.snapshot.url.join('').includes('preference');

    let col = this.app.allColmns.map(t => t[0]);
    let colName = this.app.allColmns.map(t => t[1]);

    this.array = new Array;

    const c = new PreferenceArr();
    c.colName = 'Select All' ; c.col = 'all';
    this.array.push(c);

    this.app.allColmns.filter( column => {
      let a = new PreferenceArr;
      a.col = column[0];
      a.colName = column[1];
      this.array.push(a);
    });

    this.leftSide = this.array.splice(0, Math.ceil(this.array.length / 2));
    this.preferenceCols =  this.leftSide.map((l, i) => [l, this.array[i]]);

    let a = this.app.getColumns();
    if (this.preference && this.preference.selectedColumns) {
        this.preference.selectedColumns.split(',').map(p => p.trim()).forEach(p => this.prefFields[p] = true);
    } else if(urlContains) {
        this.getUserPreference();
    } else {
      a.forEach(k => this.prefFields[k.col] = true);
    }
    this.prefFields['all'] = a.every( col => this.prefFields[col.col]);
  }

  save() {
    const selCol =  this.app.allColmns.map(t => t[0]).filter( k => this.prefFields[k]).join(',');
    const preferences = this.preference ? this.preference : new Preferences;
    preferences.selectedColumns = selCol;
    preferences.defaultPref = 'N';
    preferences.userId = this.userService.getUser().userId;
    preferences.progId =  this.prgId;
    this.savePreference1.emit(preferences);
  }

  savePref() {
    this.messageService.change(new Message(`Saving column preferences...`, 'info'));
    const selCol =  this.app.allColmns.map(t => t[0]).filter( k => this.prefFields[k]).join(',');
    this.preference = this.preference ?  this.preference : new Preferences;
    this.preference.selectedColumns = selCol;
    this.preference.defaultPref = 'Y';
    this.preference.userId = this.userService.getUser().userId;
    this.preference.progId =  0;

    this.prefSevice.savePreferences(this.preference).subscribe(resp => {
      if (resp.status === 'SUCCESS') {
        this.preference = resp.body;
        this.messageService.change(new Message('Preference saved.', 'success'));
      }
     }, error => {
      this.messageService.change(new Message('Not able to save preference.', 'danger'));
    });
  }

changePref = (pref, ckecked) => {
  this.prefFields[pref] = ckecked;
  let a = this.app.getColumns();
  if (pref === 'all') {
    a.map(p => p.col).forEach(p => this.prefFields[p] = ckecked);
  } else {
    this.prefFields[pref] = ckecked;
  }
  this.prefFields['all'] = a.every(col => this.prefFields[col.col]);
}

getUserPreference() {
  this.messageService.change(new Message(` Getting user preference...`, 'info'));
  this.prefSevice.getPreferences(this.prgId).subscribe(r => {
    this.preference = r.body;
     if (this.preference) {
      this.preference.selectedColumns.split(',').map(p => p.trim()).forEach(p => this.prefFields[p] = true);
    }else {
      this.app.getColumns().forEach(k => this.prefFields[k.col] = true);
    }
    this.prefFields['all'] = this.app.getColumns().every(col => this.prefFields[col.col]);
  });
this.messageService.change(null);
}

isValidPref = () => this.app.getColumns().filter(k => this.prefFields[k.col]).length > 0;
}


