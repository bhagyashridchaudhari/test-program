import { HttpModule } from '@angular/http';

import { NgModule, ErrorHandler } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppCommonModule } from '@app/common';
import { MatDatepickerModule, MatNativeDateModule, MatAutocompleteModule, DateAdapter, MAT_DATE_FORMATS } from '@angular/material';

import { DatePipe } from '@angular/common';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';

import { DashboardComponent } from './container/dashboard/dashboard.component';
import { ProjectCreateUpdateComponent } from './container/projects/project-create-update/project-create-update.component';
import { ProjectDeleteComponent } from './container/projects/project-delete/project-delete.component';
import { ProjectDetailsComponent } from './container/projects/project-details/project-details.component';
import { ProjectSearchComponent } from './container/projects/project-search/project-search.component';
import { ProjectTeamComponent } from './container/projects/project-team/project-team.component';
import { ProjectTransferComponent } from './container/projects/project-transfer/project-transfer.component';
import { ProjectUpdateStatusComponent } from './container/projects/project-update-status/project-update-status.component';
import { AppService } from './app.service';
import { ProjectService } from './container/projects/projects.service';
import { UserService } from './common/user.service';
import { MessageService } from './common/message.service';
import { DashboardService } from './container/dashboard/dashboard.service';
import { CapitalizePipe } from './common/capitalize.pipe';
import { DateFormatPipe } from './common/date-format.pipe';
import { ProjectSearchService } from './container/projects/project-search/project-search.service';
import { UserValidator } from './common/user.validator';
import { FindUserDirective } from './common/find-user.directive';
import { SetNameDirective, SetNamePipe } from './common/set-name.directive';
import { AccrdionDirective } from './common/accrdion.directive';
import { TriggerService } from './common/trigger.service';
import { CoustomDateAdapter } from './common/custom-date-adapter';
import { MaxValValidator } from './common/max-val.validator';
import { TooltipDirective } from './common/tooltip.directive';
import { SimulateUserLogComponent } from './simulate-user-log/simulate-user-log.component';
import { WrapTextComponent } from './wrap-text/wrap-text.component';
import { RiskService } from './container/projects/risk/risk.service';
import { AppInterceptor } from './app.interceptor';
import { MenuDirective } from './common/menu.directive';
import { ProgramReportComponent } from './container/reports/program-report/program-report.component';
import { BackColorComponent } from './back-color/back-color.component';

import { CategoryImpactDetailComponent } from './container/risk-category/category-impact-detail/category-impact-detail.component';

import { ChartsModule } from 'ng2-charts';
import { ProgramPreferenceComponent } from './container/projects/program-preference/program-preference.component';
import { PreferenceService } from './container/projects/program-preference/program-preference.service';
import { ReportService } from './container/reports/report.service';
import { ExportService } from './common/export-service';

import { ErrorComponent } from './error/error.component';
import { ErrorNotFoundComponent } from './error-not-found/error-not-found.component';

import { ViewImpactDescComponent } from './container/risk-category/view-impact-desc/view-impact-desc.component';

export const MY_FORMATS = {
  parse: {
    dateInput: 'DD-MMM-YYYY',
  },
  display: {
    dateInput: 'DD-MMM-YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@NgModule({
  declarations: [
    AccrdionDirective,
    AppComponent,
    CapitalizePipe,
    DateFormatPipe,
    FindUserDirective,
    WrapTextComponent,
    HeaderComponent,
    DashboardComponent,
    MaxValValidator,
    ProjectCreateUpdateComponent,
    ProjectDeleteComponent,
    ProjectDetailsComponent,
    ProjectSearchComponent,
    ProjectTeamComponent,
    ProjectTransferComponent,
    ProjectUpdateStatusComponent,
    SetNameDirective,
    TooltipDirective,
    SetNamePipe,
    UserValidator,
    MenuDirective,
    SimulateUserLogComponent,
    ProgramReportComponent,
    BackColorComponent,
    CategoryImpactDetailComponent,
    ProgramPreferenceComponent,
    ErrorComponent,
    ErrorNotFoundComponent,
    ViewImpactDescComponent
  ],
  imports: [
    AppCommonModule,
    AppRoutingModule,
    BrowserModule,
    FormsModule,
    HttpClientModule,
    HttpModule,
    MatAutocompleteModule,
    MatDatepickerModule,
    MatNativeDateModule,
    ReactiveFormsModule,
    ChartsModule
  ],
  providers: [
    AppService,
    CapitalizePipe,
    DashboardService,
    MessageService,
    ProjectService,
    ProjectSearchService,
    TriggerService,
    RiskService,
    UserService,
    ReportService,
    ExportService,
    PreferenceService,
    { provide: DateAdapter , useClass: CoustomDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
    { provide: DatePipe, useClass: DateFormatPipe},
    { provide: HTTP_INTERCEPTORS, useClass: AppInterceptor, multi: true },
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }


