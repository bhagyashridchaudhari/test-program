import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Injectable } from '@angular/core';
import { User } from '../app.service';

@Injectable()
export class UserService {

  private userSource = new BehaviorSubject<User>(null);

  currentUser = this.userSource.asObservable();

  constructor() {}

  loadUser = (data: User) => this.userSource.next(data);

  getUser = () => this.userSource.getValue();
}
