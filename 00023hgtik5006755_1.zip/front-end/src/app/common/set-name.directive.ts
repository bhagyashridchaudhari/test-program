import { Directive, ElementRef, HostListener, OnInit, Pipe, PipeTransform, Input } from '@angular/core';
import { CapitalizePipe } from './capitalize.pipe';
import { TriggerService } from './trigger.service';
import { AppService } from '../app.service';

@Directive({
  // tslint:disable-next-line:directive-selector
  selector: '[setName]',
})
export class SetNameDirective implements OnInit {

  @Input('setNameDisabled') setNameDisabled = false;

  private isFocused = false;

  constructor(private app: AppService,
    private capitalizePipe: CapitalizePipe,
    private triggerService: TriggerService,
    private el: ElementRef) { }

  ngOnInit() {
    setTimeout(() => this.addName(), 100);
    this.triggerService.eventUserChange.subscribe(event => event ? setTimeout(() => { this.addName(); this.triggerService.changeUser(false); }, 10) : false);
  }

  @HostListener('focusout') onFocusout = () => this.addName();

  @HostListener('focus') onfocus = () => {
    this.isFocused =  true;
    if (this.el.nativeElement.value && this.el.nativeElement.value.includes('|')) {
      this.el.nativeElement.value = this.el.nativeElement.value.substring(0, this.el.nativeElement.value.indexOf('|')).trim();
    }
  }
  private addName = () => {
    this.isFocused =  false;
    const id = this.el.nativeElement.value;
    if (!this.setNameDisabled && id && !id.includes('|') && /^[A-Z0-9]{6,7}$/i.test(id)) {
      let name = this.app.userMap.get(id);
      if (name) {
        this.el.nativeElement.value = `${id} | ${this.capitalizePipe.transform(name, true)}`;
      } else {
        this.app.getUserName(id).subscribe(resp => {
          if (!this.isFocused && resp.body !== id) {
            name = resp.body;
            this.el.nativeElement.value = `${id} | ${this.capitalizePipe.transform(name, true)}`;
            if (name !== 'User Removed') {
              this.app.userMap.set(id, name);
            }
          }
        });
      }
    }
  }
}

@Pipe({
  name: 'setName',
  pure: false
})
export class SetNamePipe implements PipeTransform {

  private idName: string;

  constructor(private capitalizePipe: CapitalizePipe, private app: AppService) { }

  transform(id: string) {
    if (id && /^[A-Z0-9]{6,7}$/i.test(id)) {
      const name = this.app.userMap.get(id);
      if (name) {
        this.idName = `${id} (${this.capitalizePipe.transform(name, true)})`;
      } else {
        let fetchUser = this.app.fetchUserMap.get(id);
        if (!fetchUser) {
          fetchUser = this.app.getUserName(id);
          this.app.fetchUserMap.set(id, fetchUser);
        }
        fetchUser.subscribe(response => {
          this.idName = `${id} (${this.capitalizePipe.transform(response.body, true)})`;
          this.app.userMap.set(id, response.body);
          this.app.fetchUserMap.delete(id);
        }, err => {
          this.idName = `${id} (User Removed)`;
          this.app.fetchUserMap.delete(id);
        });
      }
    } else {
      this.idName = `${id} (AD Group)`;
    }
    return this.idName;
  }
}
