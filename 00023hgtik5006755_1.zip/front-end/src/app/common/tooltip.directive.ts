import { Directive, Input, ElementRef, OnInit, Renderer2 } from '@angular/core';

@Directive({
    // tslint:disable-next-line:directive-selector
    selector: '[tooltip]'
})
export class TooltipDirective implements OnInit {

    @Input('tooltip') tooltip: 'left' | 'right' | 'top' | 'bottom';

    @Input('sizeTooltip') sizeTooltip: 'esm'|'sm' | 'md' | 'lg' | 'xl';

    @Input('dataTooltip') dataTooltip: string;

    constructor(private _elRef: ElementRef, private _renderer: Renderer2) { }

    ngOnInit() {
        this._renderer.setAttribute(this._elRef.nativeElement, 'data-tooltip', this.dataTooltip);
        this._renderer.addClass(this._elRef.nativeElement, 'tooltip');
        if (this.tooltip) {
            this._renderer.addClass(this._elRef.nativeElement, 'tooltip-' + this.tooltip);
        }
        if (this.sizeTooltip) {
            this._renderer.addClass(this._elRef.nativeElement, 'tooltip-' + this.sizeTooltip);
        }
    }
}
