export class ChartOption {

  private static barFunc = function () {
    const ci = this.chart, ctx = ci.ctx;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'bottom';
    ctx.font = 'bold 12px Arial';
    this.data.datasets.forEach(function (dataset, i) {
      const meta = ci.controller.getDatasetMeta(i);
      meta.data.forEach(function (bar, index) {
        const data = dataset.data[index];
        ctx.fillText(!ci.getDatasetMeta(i).hidden && data !== 0 ? data : '', bar._model.x, bar._model.y - 5);
      });
    });
  };

  // tslint:disable-next-line:member-ordering
  public static chartBarOptions = {
    hover: {
      mode: 'nearest',
      intersec: true,
      onHover: function (e, el) {
        e.target.style.cursor = el[0] ? 'pointer' : 'default';
      }
    },
    scales: {
      yAxes: [{
        ticks: {
          beginAtZero: true,
          userCallback: function (label, index, labels) {
            if (Math.floor(label) === label) {
              return label;
            }
          }
        }
      }],
      xAxes: [{
        ticks: {
          autoSkip: false
        }
      }]
    },
    legend: { position: 'bottom' },
    layout: { padding: { top: 20 } },
    tooltips: { enabled: false },
    events: ['click', 'mousemove'],
    animation: {
      onProgress: ChartOption.barFunc,
      onComplete: ChartOption.barFunc
    }
  };
  private static pieFunc = function () {
    const ctx = this.chart.ctx;
    ctx.textAlign = 'center';
    ctx.fillStyle = '#000000';
    ctx.font = 'bold 12px Arial';
    this.config.data.datasets.forEach((dataset, idx) => {
      let total = 0, lastend = 0;
      const meta = this.chart.getDatasetMeta(idx);
      dataset.data.forEach((val, i) => total += (!meta.data[i].hidden) ? val : 0);
      for (let index = 0; index < meta.data.length; index++) {
        if (!meta.data[index].hidden) {
          const element = meta.data[index], radius = element._view.outerRadius + 10;
          const val = dataset.data[index], arcsector = Math.PI * (2 * val / total);
          if (element.hasValue() && val > 0) {
            const langle = lastend + (arcsector / 2) + Math.PI + (Math.PI / 2);
            const dx = element._model.x + radius * Math.cos(langle), dy = element._model.y + radius * Math.sin(langle);
            ctx.fillText(val, dx, dy);
          }
          lastend += arcsector;
        }
        ctx.restore();
      }
    });
  };

  // tslint:disable-next-line:member-ordering
  public static chartPieOptions: any = {
    hover: {
      onHover: function (e, el) {
        e.target.style.cursor = el[0] ? 'pointer' : 'default';
      }
    },
    tooltips: { enabled: false },
    events: ['click', 'mousemove'],
    layout: { padding: { left: 20, right: 20, top: 20, bottom: 20 } },
    legend: { position: 'right' },
    animation: {
      onProgress: ChartOption.pieFunc,
      onComplete: ChartOption.pieFunc
    }
  };
}
