import { Directive, OnInit, ElementRef, AfterViewInit, Input } from '@angular/core';
import { Observable } from 'rxjs/Observable';

@Directive({
  // tslint:disable-next-line:directive-selector
  selector: '[menu]',
})
export class MenuDirective implements AfterViewInit {

  @Input('menu') menu: Element;

  @Input('poulate') poulate: false;

  private _li_1: Element[];

  private observer;

  private config = { attributes: false, childList: true, characterData: false };

  constructor(private el: ElementRef) {
  }

  ngAfterViewInit() {
    if (!this.poulate) {
      return;
    }
    Observable.fromEvent(this.menu, 'click').subscribe(($event: any) => {
      this.toggle(this.el.nativeElement);
      if (!this.el.nativeElement.classList.contains('show-menu')) {
        this.closeAll();
      }
    });
    this._li_1 = Array.from((<HTMLElement>this.el.nativeElement).children[0].children);
    this.setEvent(this._li_1);
    this.observer = new MutationObserver(mutations => {
      mutations.forEach(mutation => {
        this._li_1 = Array.from((<HTMLElement>this.el.nativeElement).children[0].children);
        if (mutation.addedNodes.length > 0) {
          this.setEvent(<HTMLElement[]>Array.from(mutation.addedNodes));
        }
      });
    }).observe(this.el.nativeElement.children[0], this.config);
  }

  private setEvent = (_li: Element[]) => {
    _li.forEach(li => {
      if (li.children.length > 1) {
        Observable.fromEvent(li.children[0], 'click').subscribe(($event: any) => {
          this.toggle(li.children[1]);
        });
        this.setEventInner(Array.from(li.children[1].children));
        new MutationObserver(mutations => {
          mutations.forEach(mutation => {
            if (mutation.addedNodes.length > 0) {
              this.setEventInner(<HTMLElement[]>Array.from(mutation.addedNodes));
            }
          });
        }).observe(li.children[1], this.config);
      } else {
        Observable.fromEvent(li.children[0], 'click').subscribe(($event: any) => this.closeAll());
      }
    });
  }

  private setEventInner = (_li: Element[]) => {
    for (let j = 0; j < _li.length; j++) {
      Observable.fromEvent(_li[j].children[0], 'click').subscribe(($event: any) => this.closeAll());
    }
  }

  private closeAll = () => {
    for (let i = 0; i < this._li_1.length; i++) {
      if (this._li_1[i].children.length > 1) {
        this._li_1[i].children[1].classList.remove('show-menu');
      }
    }
    this.el.nativeElement.classList.remove('show-menu');
  }

  private toggle = (el: Element) => {
    if (!el.classList.contains('show-menu') && window.innerWidth < 768) {
      el.classList.add('show-menu');
    } else {
      el.classList.remove('show-menu');
    }
  }
}
