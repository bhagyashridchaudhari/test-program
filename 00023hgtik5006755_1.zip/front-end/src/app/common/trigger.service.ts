import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Injectable } from '@angular/core';
import { User } from '../app.service';

@Injectable()
export class TriggerService {

  private userChange = new BehaviorSubject<boolean>(false);

  eventUserChange = this.userChange.asObservable();

  changeUser = (event: boolean) => this.userChange.next(event);
}
