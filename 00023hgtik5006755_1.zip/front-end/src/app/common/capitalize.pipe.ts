import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'capitalize'
})
export class CapitalizePipe implements PipeTransform {

  transform(value: string, words: boolean) {
    if (value) {
      if (words) {
        return value.toLowerCase().replace(/\b\w/g, first => first.toLocaleUpperCase());
      } else {
        return value.charAt(0).toUpperCase() + value.slice(1).toLowerCase();
      }
    }
    return value;
  }
}

