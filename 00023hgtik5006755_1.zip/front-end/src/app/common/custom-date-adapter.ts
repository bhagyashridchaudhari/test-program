import { MAT_DATE_LOCALE, NativeDateAdapter, MAT_DATE_FORMATS } from '@angular/material';
import { Inject, Injectable, Optional } from '@angular/core';
import * as moment from 'moment';

@Injectable()
export class CoustomDateAdapter extends NativeDateAdapter {

  useUtcForDisplay = false;

  constructor( @Optional() @Inject(MAT_DATE_LOCALE) dateLocale: string, @Inject(MAT_DATE_FORMATS) private dateFormats) {
    super(dateLocale);
  }

  format(date: Date, displayFormat: Object): string {
    if (date && displayFormat && typeof displayFormat === 'string') {
      return moment(date).format(displayFormat);
    }
    return super.format(date, displayFormat);
  }

  parse(value: any): Date | null {
    if (typeof value === 'string' &&  /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(value)) {
      return moment(value, 'YYYY-MM-DD[T]HH:mm:ss.SSS[Z]').toDate();
    }
    return value && value !== '' ? moment(value, this.dateFormats.parse.dateInput , true).toDate() : null;
  }
}

