import { Directive, Input, ElementRef, Renderer2, AfterViewInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';

@Directive({
  // tslint:disable-next-line:directive-selector
  selector: '[accrdion]',
  exportAs: 'accrdion'
})
export class AccrdionDirective implements AfterViewInit {

  @Input('open') open = false;

  @Input('accrdion') accrdion: ElementRef;

  constructor(private _elRef: ElementRef, private _renderer: Renderer2) { }

  ngAfterViewInit() {
    Observable.fromEvent(this._elRef.nativeElement, 'click').subscribe(e => { this.open = !this.open; this.setClass(); });
    this._renderer.addClass(this.accrdion, 'accordion-collapse');
    this.setClass();
  }

  private setClass = () => {
    this._renderer.removeClass(this._elRef.nativeElement, 'collapsed');
    this._renderer.removeClass(this.accrdion, 'in');
    if (this.open) {
      this._renderer.addClass(this.accrdion, 'in');
    } else {
      this._renderer.addClass(this._elRef.nativeElement, 'collapsed');
    }
  }
}
