import { Directive, ElementRef, Input, OnInit } from '@angular/core';
import { AppService, UserList, UserView } from '../app.service';
import { Observable } from 'rxjs/Observable';
import { NgModel } from '@angular/forms';

@Directive({
  // tslint:disable-next-line:directive-selector
  selector: '[findUsers][ngControl], [findUsers][formControl], [findUsers][ngModel]',
})
export class FindUserDirective implements OnInit {

  @Input('findUsers') findUsers: boolean;

  @Input('userList') userList: UserList;

  constructor(private app: AppService, private el: ElementRef, private model: NgModel) { }

  ngOnInit() {
    Observable.fromEvent(this.el.nativeElement, 'input').subscribe(keyboardEvent => {
      let val = <string>this.el.nativeElement.value;
      val = (this.findUsers) ? val.replace(/[^a-zA-Z0-9'\s]/g , '') : val;
      this.model.valueAccessor.writeValue(val.toUpperCase());
    });

    Observable.fromEvent(this.el.nativeElement, 'input')
      .debounceTime(200)
      .distinctUntilChanged()
      .subscribe(keyboardEvent => {
        if (this.findUsers) {
          const val: string = this.el.nativeElement.value;
          if (val.length > 2 && !val.includes('|')) {
            this.el.nativeElement.classList.add('loading');
            this.app.findUsers(val).subscribe(data => {
              this.userList.value = data;
              this.el.nativeElement.classList.remove('loading');
            }, err => this.el.nativeElement.classList.remove('loading'));
          }
        }
      });
  }
}
