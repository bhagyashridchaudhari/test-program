import { Http, Headers, Response, RequestOptions, ResponseContentType } from '@angular/http';
import { MessageService, Message } from './message.service';
import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Rx';

@Injectable()
export class ExportService {
  private options = new RequestOptions({ headers: new Headers({ 'Content-Type': 'application/json' }), responseType: ResponseContentType.Blob });

  constructor(private http: Http, private messageService: MessageService) { }
  exportExcel = (excelData: ExcelData) => {
    this.messageService.change(new Message('Generating excel sheet. Please wait...', 'info'));
    this.http.post('/api/report/export-excel', excelData, this.options).subscribe(
      resp => {
        this.downloadExcel(resp, excelData.name);
      }, err => this.messageService.change(new Message('Not able to generate excel. Please contact support.', 'danger')));
  }

  private downloadExcel = (resp: Response, name: String) => {
    const blob = resp.blob();
    if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      window.navigator.msSaveOrOpenBlob(blob, name + '.xlsx');
    } else {
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = name + '.xlsx';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
    this.messageService.change(new Message('Excel successfully generated. Please check your download folder.', 'success'));
  }

  generatePowerPoint = (reportData: ReportData) => {
    this.messageService.change(new Message('Generating PPT. Please wait...', 'info'));
    this.http.post(`/api/admin/chart-data/export`, reportData, this.options).subscribe(
      resp => {
        const blob = resp.blob();
        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
          window.navigator.msSaveOrOpenBlob(blob, reportData.name + '.pptx');
        } else {
          const a = document.createElement('a');
          a.href = URL.createObjectURL(blob);
          a.download = reportData.name + '.pptx';
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
        }
        this.messageService.change(new Message('PPT successfully generated. Please check your download folder.', 'success'));
      }, err => this.messageService.change(new Message('Not able to generate PPT. Please contact support.', 'danger')));
  }

  generateScorecardRopert = (image: DataImage, name: string , fun?: Function) => {
    this.messageService.change(new Message('Generating PPT. Please wait...', 'info'));
    this.http.post(`/api/admin/scorecard/export`, image, this.options).subscribe(
      resp => {
        const blob = resp.blob();
        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
          window.navigator.msSaveOrOpenBlob(blob, name + '.pptx');
        } else {
          const a = document.createElement('a');
          a.href = URL.createObjectURL(blob);
          a.download = name + '.pptx';
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
        }
        if (fun) {
          fun();
        }
        this.messageService.change(new Message('PPT successfully generated. Please check your download folder.', 'success'));
      }, err => this.messageService.change(new Message('Not able to generate PPT. Please contact support.', 'danger')));
  }
  downloadImage = (projId: number, riskId: number, imgId: number) => {
    this.messageService.change(new Message('Downloading image. Please wait...', 'info'));
    const imageData = new ImageData(projId, riskId, imgId);
    this.http.post('/api/risk/downloadImage', imageData, this.options).subscribe(
      resp => {
        const blob = resp.blob();
        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
          window.navigator.msSaveOrOpenBlob(blob, projId + ' Image-'+ imgId + '.jpeg');
        } else {
          const a = document.createElement('a');
          a.href = URL.createObjectURL(blob);
          a.download = 'Project -'+ projId + ' Image-' + imgId + '.jpeg';
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
        }
        this.messageService.change(new Message('Image successfully downloaded. Please check your download folder.', 'success'));
      }, err => this.messageService.change(new Message('Not able to download image. Please contact support.', 'danger')));
  }
}

/**
 * Power Point Export Models
 */
export class ReportData { constructor(public name: string, public author: string, public pages: Page[]) { } }

export class Page { constructor(public header: string, public desc: string[], public images?: DataImage[]) { } }

export class DataImage { constructor(public imageDataURL: string, public x: number, public y: number, public width: number, public height: number) { } }

export class ImageData { constructor(public projId: number, public riskId: number, public imgId: number) { } }
/**
 * Excel Export Models
 */
export class ExcelData { constructor(public name: string, public sheets: Sheet[]) { } }

export class Sheet { constructor(public name: string, public rows: Row[], public style?: Style, public lock?: Lock, public widths?: ColWidth[],) { } }

export class Row { constructor(public cells: Cell[], public style?: Style) { } }

export class Cell { constructor(public data: string | number, public style?: Style, public colSpan?: number, public rowSpan?: number) { } }

export class Style {

  border?: boolean;

  bold?: boolean;

  wrap?: boolean;

  size?: number;

  color?: Colors;

  bgcolor?: Colors;

  align?: Align;
}

export class Lock {
  row?: number;

  col?: number;
}

export class ColWidth {
  constructor(public col: number, public width: number) { }
}

export type Colors = 'BLACK' | 'WHITE' | 'RED' | 'BRIGHT_GREEN' | 'BLUE' | 'YELLOW' | 'PINK' | 'TURQUOISE' | 'DARK_RED' | 'GREEN'
  | 'DARK_BLUE' | 'DARK_YELLOW' | 'VIOLET' | 'TEAL' | 'GREY_25_PERCENT' | 'GREY_50_PERCENT' | 'CORNFLOWER_BLUE' | 'MAROON'
  | 'LEMON_CHIFFON' | 'ORCHID' | 'CORAL' | 'ROYAL_BLUE' | 'LIGHT_CORNFLOWER_BLUE' | 'SKY_BLUE' | 'LIGHT_TURQUOISE'
  | 'LIGHT_GREEN' | 'LIGHT_YELLOW' | 'PALE_BLUE' | 'ROSE' | 'LAVENDER' | 'TAN' | 'LIGHT_BLUE' | 'AQUA' | 'LIME'
  | 'GOLD' | 'LIGHT_ORANGE' | 'ORANGE' | 'BLUE_GREY' | 'GREY_40_PERCENT' | 'DARK_TEAL' | 'SEA_GREEN'
  | 'DARK_GREEN' | 'OLIVE_GREEN' | 'BROWN' | 'PLUM' | 'INDIGO' | 'GREY_80_PERCENT' | 'AUTOMATIC';

  export type Align = 'GENERAL' | 'LEFT' | 'CENTER' | 'RIGHT' | 'FILL' | 'JUSTIFY' | 'CENTER_SELECTION';
