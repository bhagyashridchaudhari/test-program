import { Directive, Input, forwardRef, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { NG_VALIDATORS, Validator, ValidatorFn, AbstractControl, Validators } from '@angular/forms';
import { isPresent } from './lang';


export const max = (val: number): ValidatorFn => {
  return (control: AbstractControl): { [key: string]: any } => {
    if (!isPresent(val) && isPresent(control.value)) {
      return { requiredValue: null, val: true };
    }
    if (!isPresent(val)) {
      return null;
    }
    if (isPresent(Validators.required(control))) {
      return null;
    }
    const v: number = +control.value;
    return v <= +val ? null : { actualValue: v, requiredValue: +val, val: true };
  };
};

const MAX_VALIDATOR: any = {
  provide: NG_VALIDATORS,
  useExisting: forwardRef(() => MaxValValidator),
  multi: true
};

@Directive({
  // tslint:disable-next-line:directive-selector
  selector: '[maxVal][formControlName],[maxVal][formControl],[maxVal][ngModel]',
  providers: [MAX_VALIDATOR]
})
export class MaxValValidator implements Validator, OnInit, OnChanges {
  @Input() maxVal: number;

  private validator: ValidatorFn;
  private onChange: () => void;

  ngOnInit() {
    this.validator = max(this.maxVal);
  }

  ngOnChanges(changes: SimpleChanges) {
    for (const key in changes) {
      if (key === 'maxVal') {
        this.validator = max(changes[key].currentValue);
        if (this.onChange) {
          this.onChange();
        }
      }
    }
  }

  validate(c: AbstractControl): { [key: string]: any } {
    return this.validator(c);
  }

  registerOnValidatorChange(fn: () => void): void {
    this.onChange = fn;
  }
}
