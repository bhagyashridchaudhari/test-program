import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';

@Pipe({
  name: 'dateFormat'
})
export class DateFormatPipe extends DatePipe implements PipeTransform {
  transform(value: any, args?: any): string | null {
    return (value &&  value.toString() !== 'Invalid Date') ? super.transform(value, args ? args : 'dd-MMM-yyyy') : null;
  }
}

