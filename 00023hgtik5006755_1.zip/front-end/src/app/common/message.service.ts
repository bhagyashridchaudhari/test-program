import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class MessageService {

  private messageSource = new BehaviorSubject<Message[]>(null);
  currentMessage = this.messageSource.asObservable();

  constructor() {}

  change(message: Message) {
    this.messageSource.next(message ? [message] : null);
  }

  changes(message: Message[]) {
    this.messageSource.next(message);
  }
}

export class Message {
  message: string;
  messageType: MessageType;

  constructor(message: string, messageType: MessageType) {
    this.message = message;
    this.messageType = messageType;
  }
}

export type MessageType = 'success' | 'danger' | 'warning' | 'info';
