import { Validator, AbstractControl, NG_ASYNC_VALIDATORS } from '@angular/forms';
import { Directive, forwardRef, Input } from '@angular/core';
import { AppService } from '../app.service';

@Directive({
  // tslint:disable-next-line:directive-selector
  selector: '[validateUser][ngControl], [validateUser][formControl], [validateUser][ngModel]',
  providers: [
    { provide: NG_ASYNC_VALIDATORS, useExisting: forwardRef(() => UserValidator), multi: true }
  ]
})
export class UserValidator implements Validator {

  @Input('validateUser') validateUser: boolean;

  @Input('invalidUids') invalidUids: any[];

  @Input('uid') uid: any;

  constructor(private app: AppService) { }

  validate(c: AbstractControl): Promise<{ [key: string]: boolean }> {
    return new Promise(resolve => {
      if (this.validateUser && c.value && c.value !== '') {
        const id = c.value.replace(/[^a-zA-Z0-9\s]/g, '').toUpperCase();
        if (/^[A-Z0-9]{6,7}$/i.test(id)) {
          const nm = this.app.userMap.get(id);
          if (nm && nm.toLowerCase() !== 'user removed') {
            this.isValid(true);
            resolve(null);
          } else if (nm && nm.toLowerCase() === 'user removed') {
            this.isValid(false);
            resolve({ invalidUser: true });
          } else {
            this.app.isValidUser(id).subscribe(resp => {
              if (resp && resp.body) {
                this.isValid(true);
                resolve(null);
              } else {
                this.isValid(false);
                resolve({ invalidUser: true });
              }
            });
          }
        } else {
          this.isValid(false);
          resolve({ invalidUser: true });
        }
      } else {
        this.isValid(true);
        resolve(null);
      }
    });
  }

  private isValid = (isValid: boolean) => {
    if (this.invalidUids) {
      if (isValid) {
        const index = this.invalidUids.findIndex(uId => uId === this.uid);
        if (index !== -1) {
          this.invalidUids.splice(index, 1);
        }
      } else if (this.invalidUids.findIndex(uId => uId === this.uid) === -1) {
        this.invalidUids.push(this.uid);
      }
    }
  }
}
