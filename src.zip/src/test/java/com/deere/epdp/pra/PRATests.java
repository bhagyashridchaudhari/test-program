package com.deere.epdp.pra;

import org.junit.Test;

//@RunWith(SpringRunner.class)
//@SpringBootTest
public class PRATests {

	@Test
	public void contextLoads() {
	}

}
