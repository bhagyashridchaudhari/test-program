package com.deere.epdp.pra.serviceImpl.prm;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deere.epdp.pra.domain.prm.ResponseStratergy;
import com.deere.epdp.pra.repo.prm.ResponseStratergyRepository;
import com.deere.epdp.pra.service.prm.ResponseStratergyService;

@Service
public class ResponseStratergyServiceImpl implements ResponseStratergyService{
	
	@Autowired
	private ResponseStratergyRepository respStratergyRepository;
	
	private Map<Integer, ResponseStratergy> respStratergyMap;

	@PostConstruct
	public void init() {
		respStratergyMap = StreamSupport.stream(respStratergyRepository.findAll().spliterator(), false)
				.collect(Collectors.toMap(ResponseStratergy::getStratergyId, Function.identity()));
	}

	@Override
	public List<ResponseStratergy> getAllResponseStratergy() {
		return respStratergyMap.values().stream().sorted(Comparator.comparing(ResponseStratergy::getStratergyName)).collect(Collectors.toList());
		}

	@Override
	public String getResponseStratergyById(Integer id) {
		ResponseStratergy stratergy = respStratergyMap.get(id);
		return stratergy != null ? stratergy.getStratergyName() : null;
	}

}
