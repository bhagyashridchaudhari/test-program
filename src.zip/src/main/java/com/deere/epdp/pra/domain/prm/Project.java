package com.deere.epdp.pra.domain.prm;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;
import java.util.function.Function;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "program")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Project implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "prgm_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer prjId;

	@Column(name = "name", nullable = false)
	private String prjName;

	@Column(name = "prgm_typ_id")
	private Integer prjTypeId;

	@Column(name = "prgm_status_id")
	private Integer prjStatusId;

	@Column(name = "div_id")
	private Integer divId;

	@Column(name = "pltfm_id")
	private Integer pltfmId;

	@Column(name = "prdln_id")
	private Integer prdlnId;

	@Column(name = "prdfmly_id")
	private Integer prdfmlyId;

	@Column(name = "unt_id")
	private Integer unitId;

	@Column(name = "owner", nullable = false)
	private String prjOwner;

	@Column(name = "manager", nullable = false)
	private String prjManager;

	@Column(name = "director", nullable = false)
	private String prjDirector;

	@Column(name = "mrkt_dirctor", nullable = false)
	private String prjMrktDirctor;

	@Column(name = "engr_dirctor", nullable = false)
	private String prjEngrDirctor;

	@Column(name = "strt_dt", nullable = false)
	private Date prjStartDate;

	@Column(name = "end_dt", nullable = false)
	private Date prjEndDt;

	@Column(name = "lst_aprvl_dt")
	private Date prjLastAprvlDt;

	@Column(name = "cmplt_dt", updatable = false)
	private Date prjCmpltDt;

	@Column(name = "afe_no")
	private String afeNo;

	@Column(name = "total_part_cnt")
	private Integer totalPartCount;

	@Column(name = "new_part_cnt")
	private Integer newPartCount;

	@Column(name = "created_by", nullable = false, updatable = false)
	private String createdBy;


	@Column(name = "created_ts", nullable = false, updatable = false)
	private Timestamp createdTs;

	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdtBy;

	
	@Column(name = "last_updt_ts")
	private Timestamp lastUpdtTs;
	
	@Column(name = "dst_rls_dt")
	private Date dstRlsDt;

	public Project() {
		super();
	}

	public Project(Integer prjId) {
		super();
		this.prjId = prjId;
	}

	public Integer getPrjId() {
		return prjId;
	}

	public void setPrjId(Integer prjId) {
		this.prjId = prjId;
	}

	public String getPrjName() {
		return prjName;
	}

	public void setPrjName(String prjName) {
		this.prjName = prjName;
	}

	public Integer getPrjTypeId() {
		return prjTypeId;
	}

	public void setPrjTypeId(Integer prjTypeId) {
		this.prjTypeId = prjTypeId;
	}

	public Integer getPrjStatusId() {
		return prjStatusId;
	}

	public void setPrjStatusId(Integer prjStatusId) {
		this.prjStatusId = prjStatusId;
	}

	public Integer getDivId() {
		return divId;
	}

	public void setDivId(Integer divId) {
		this.divId = divId;
	}

	public Integer getPltfmId() {
		return pltfmId;
	}

	public void setPltfmId(Integer pltfmId) {
		this.pltfmId = pltfmId;
	}

	public Integer getPrdlnId() {
		return prdlnId;
	}

	public void setPrdlnId(Integer prdlnId) {
		this.prdlnId = prdlnId;
	}

	public Integer getPrdfmlyId() {
		return prdfmlyId;
	}

	public void setPrdfmlyId(Integer prdfmlyId) {
		this.prdfmlyId = prdfmlyId;
	}

	public Integer getUnitId() {
		return unitId;
	}

	public void setUnitId(Integer unitId) {
		this.unitId = unitId;
	}

	public String getPrjOwner() {
		return prjOwner;
	}

	public void setPrjOwner(String prjOwner) {
		this.prjOwner = prjOwner;
	}

	public String getPrjManager() {
		return prjManager;
	}

	public void setPrjManager(String prjManager) {
		this.prjManager = prjManager;
	}

	public String getPrjDirector() {
		return prjDirector;
	}

	public void setPrjDirector(String prjDirector) {
		this.prjDirector = prjDirector;
	}

	public String getPrjMrktDirctor() {
		return prjMrktDirctor;
	}

	public void setPrjMrktDirctor(String prjMrktDirctor) {
		this.prjMrktDirctor = prjMrktDirctor;
	}

	public String getPrjEngrDirctor() {
		return prjEngrDirctor;
	}

	public void setPrjEngrDirctor(String prjEngrDirctor) {
		this.prjEngrDirctor = prjEngrDirctor;
	}

	public Date getPrjStartDate() {
		return prjStartDate;
	}

	public void setPrjStartDate(Date prjStartDate) {
		this.prjStartDate = prjStartDate;
	}

	public Date getPrjEndDt() {
		return prjEndDt;
	}

	public void setPrjEndDt(Date prjEndDt) {
		this.prjEndDt = prjEndDt;
	}

	public Date getPrjLastAprvlDt() {
		return prjLastAprvlDt;
	}

	public void setPrjLastAprvlDt(Date prjLastAprvlDt) {
		this.prjLastAprvlDt = prjLastAprvlDt;
	}

	public Date getPrjCmpltDt() {
		return prjCmpltDt;
	}

	public void setPrjCmpltDt(Date prjCmpltDt) {
		this.prjCmpltDt = prjCmpltDt;
	}

	public String getAfeNo() {
		return afeNo;
	}

	public void setAfeNo(String afeNo) {
		this.afeNo = afeNo;
	}

	public Integer getTotalPartCount() {
		return totalPartCount;
	}

	public void setTotalPartCount(Integer totalPartCount) {
		this.totalPartCount = totalPartCount;
	}

	public Integer getNewPartCount() {
		return newPartCount;
	}

	public void setNewPartCount(Integer newPartCount) {
		this.newPartCount = newPartCount;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedTs() {
		return createdTs;
	}

	public void setCreatedTs(Timestamp createdTs) {
		this.createdTs = createdTs;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public void setLastUpdtBy(String lastUpdtBy) {
		this.lastUpdtBy = lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}

	public void setLastUpdtTs(Timestamp lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}

	public Date getDstRlsDt() {
		return dstRlsDt;
	}

	public void setDstRlsDt(Date dstRlsDt) {
		this.dstRlsDt = dstRlsDt;
	}

	public <R> R map(Function<Project, R> function) {
		return function.apply(this);
	}
}