package com.deere.epdp.pra.domain.epdp;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

//@Entity
//@Table(name = "prcs_rltn")
public class ProcessSubProcess implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "pr_rltn_id")
	private Integer prRltnId;
	
	@Column(name = "prcs_id")
	private Integer prcsId;

	@Column(name = "sub_prcs_id")
	private Integer subPrcsId;

	public Integer getPrRltnId() {
		return prRltnId;
	}

	public void setPrRltnId(Integer prRltnId) {
		this.prRltnId = prRltnId;
	}

	public Integer getPrcsId() {
		return prcsId;
	}

	public void setPrcsId(Integer prcsId) {
		this.prcsId = prcsId;
	}

	public Integer getSubPrcsId() {
		return subPrcsId;
	}

	public void setSubPrcsId(Integer subPrcsId) {
		this.subPrcsId = subPrcsId;
	}
	
}
