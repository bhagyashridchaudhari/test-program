package com.deere.epdp.pra.domain.prm;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "response_stratergy")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResponseStratergy implements Serializable{
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id")
	private Integer stratergyId;

	@Column(name = "name", nullable = false)
	private String stratergyName;

	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdtBy;
	
	@JsonIgnore
	@Column(name = "last_updt_ts")
	private Timestamp lastUpdtTs;

	public Integer getStratergyId() {
		return stratergyId;
	}

	public void setStratergyId(Integer stratergyId) {
		this.stratergyId = stratergyId;
	}

	public String getStratergyName() {
		return stratergyName;
	}

	public void setStratergyName(String stratergyName) {
		this.stratergyName = stratergyName;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public void setLastUpdtBy(String lastUpdtBy) {
		this.lastUpdtBy = lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}

	public void setLastUpdtTs(Timestamp lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}

}
