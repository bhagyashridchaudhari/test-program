package com.deere.epdp.pra.model;

import java.util.List;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;

public class ExcelData {
	
	private String name;
	
	private List<Sheet> sheets;
	
	public ExcelData() {
		super();
	}

	public ExcelData(String name, List<Sheet> sheets) {
		super();
		this.name = name;
		this.sheets = sheets;
	}

	public String getName() {
		return name;
	}

	public List<Sheet> getSheets() {
		return sheets;
	}

	public static class Sheet {
		
		private String name;
		
		private List<Row> rows;
		
		private Style style;
		
		private Lock lock;
		
		private Integer colCount;
		
		private List<ColWidth> widths;
		
		public Sheet() {
			super();
		}

		public Sheet(String name, List<Row> rows, Style style, Lock lock) {
			super();
			this.name = name;
			this.rows = rows;
			this.style = style;
			this.lock = lock;
		}

		public String getName() {
			return name;
		}

		public List<Row> getRows() {
			return rows;
		}

		public Style getStyle() {
			return style;
		}

		public Lock getLock() {
			return lock;
		}

		public Integer getColCount() {
			return colCount;
		}

		public void setColCount(Integer colCount) {
			this.colCount = colCount;
		}
		
		public List<ColWidth> getWidths() {
			return widths;
		}
		
		

		public static class Row {
			
			private List<Cell> cells;
			
			private Style style;
			
			public Row() {
				super();
			}

			public Row(List<Cell> cells, Style style) {
				super();
				this.cells = cells;
				this.style = style;
			}

			public List<Cell> getCells() {
				return cells;
			}

			public Style getStyle() {
				return style;
			}

			public static class Cell {
				
				private String data;
				
				private Style style;
				
				private Integer colSpan;
				
				private Integer rowSpan;

				public Cell() {
					super();
				}

				public Cell(String data, Style style, Integer colSpan, Integer rowSpan) {
					super();
					this.data = data;
					this.style = style;
					this.colSpan = colSpan;
					this.rowSpan = rowSpan;
				}

				public String getData() {
					return data;
				}

				public Style getStyle() {
					return style;
				}

				public Integer getColSpan() {
					return colSpan;
				}

				public Integer getRowSpan() {
					return rowSpan;
				}
			}
		}
		
		public static class Lock {
			private Integer row;
			
			private Integer col;

			public Lock() {
				super();
			}

			public Lock(Integer row, Integer col) {
				super();
				this.row = row;
				this.col = col;
			}

			public Integer getRow() {
				return row == null ? 0 : row;
			}

			public Integer getCol() {
				return col == null ? 0 : col;
			}
		}
		
		public static class ColWidth {

			private Integer col;
			
			private Integer width;

			public Integer getCol() {
				return col;
			}

			public Integer getWidth() {
				return width;
			}
		}
		
	}
	
	public static class Style {
		
		public enum Align {
			GENERAL(CellStyle.ALIGN_GENERAL), LEFT(CellStyle.ALIGN_LEFT), CENTER(CellStyle.ALIGN_CENTER), RIGHT(CellStyle.ALIGN_RIGHT), FILL(CellStyle.ALIGN_FILL), JUSTIFY(CellStyle.ALIGN_JUSTIFY), CENTER_SELECTION(
					CellStyle.ALIGN_CENTER_SELECTION);

			private short value;

			private Align(short value) {
				this.value = value;
			}

			public short getValue() {
				return value;
			}
		}

		private Boolean border;
		
		private Boolean bold;
		
		private Boolean wrap;
		
		private Short size;
		
		private IndexedColors color;
		
		private IndexedColors bgcolor;
		
		private Align align;

		public Style() {
			super();
		}

		public Style(Boolean border, Boolean bold, Boolean wrap, Short size, IndexedColors color, IndexedColors bgcolor, Align align) {
			super();
			this.border = border;
			this.bold = bold;
			this.wrap = wrap;
			this.size = size;
			this.color = color;
			this.bgcolor = bgcolor;
			this.align = align;
		}

		public Boolean getBorder() {
			return border;
		}

		public void setBorder(Boolean border) {
			this.border = border;
		}

		public Boolean getBold() {
			return bold;
		}

		public void setBold(Boolean bold) {
			this.bold = bold;
		}

		public Boolean getWrap() {
			return wrap;
		}

		public void setWrap(Boolean wrap) {
			this.wrap = wrap;
		}

		public Short getSize() {
			return size;
		}

		public void setSize(Short size) {
			this.size = size;
		}

		public IndexedColors getColor() {
			return color;
		}

		public void setColor(IndexedColors color) {
			this.color = color;
		}

		public IndexedColors getBgcolor() {
			return bgcolor;
		}

		public void setBgcolor(IndexedColors bgcolor) {
			this.bgcolor = bgcolor;
		}

		public Align getAlign() {
			return align;
		}

		public void setAlign(Align align) {
			this.align = align;
		}
	}
}
