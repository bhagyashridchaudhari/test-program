package com.deere.epdp.pra.service.prm;

import java.sql.Timestamp;
import java.util.List;
import java.util.Set;

import com.deere.epdp.pra.domain.prm.Project;
import com.deere.epdp.pra.domain.prm.ProjectTeam;
import com.deere.epdp.pra.domain.prm.ProjectTeam.ProjectTeamId;
import com.deere.epdp.pra.model.ProjectFilter;
import com.deere.epdp.pra.model.Response;

public interface ProjectService {
	
	boolean isValid(Project project);
	
	boolean isProjectExist(Integer prjId);

	Project saveProject(Project project, List<ProjectTeam> added, List<ProjectTeamId> removed);
	
	void transferProjects(List<Project> projects);
	
	void updateProjectStatus(List<Project> projects);

	Project getProjectById(Integer prjId);
	
	void deleteProject(Integer prjId);

	List<Integer> getAllProjectIdsByOwner(String owner);

	Project sortProjectDetail(Integer prjId);

	List<Project> getAllProjects();

	List<Project> getAllProjects(ProjectFilter projectFilter);

	List<Project> searchProjects(Project project);
	
	Set<String> getAllProjectOwnerUserId();

	String getOwner(Integer prjId);
	
	Response updateProjLastModDate(Integer prjId,Timestamp lastUpdtTs);
	

}
