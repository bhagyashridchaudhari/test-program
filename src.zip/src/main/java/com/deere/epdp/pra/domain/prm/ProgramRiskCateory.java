package com.deere.epdp.pra.domain.prm;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "prg_risk_ctgry")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProgramRiskCateory {
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer catgryId;

	@Column(name = "name", nullable = false)
	private String catgryName;
	
	@Column(name = "prgm_id" , nullable = false)
	private Integer progId;
	
	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdtBy;
	
	@JsonIgnore
	@Column(name = "last_updt_ts")
	private Timestamp lastUpdtTs;

	
	
	public ProgramRiskCateory(Integer catgryId, String catgryName, Integer progId, String lastUpdtBy,
			Timestamp lastUpdtTs) {
		super();
		this.catgryId = catgryId;
		this.catgryName = catgryName;
		this.progId = progId;
		this.lastUpdtBy = lastUpdtBy;
		this.lastUpdtTs = lastUpdtTs;
	}
	
	public ProgramRiskCateory( String catgryName, Integer progId, String lastUpdtBy,
			Timestamp lastUpdtTs) {
		super(); 
		this.catgryName = catgryName;
		this.progId = progId;
		this.lastUpdtBy = lastUpdtBy;
		this.lastUpdtTs = lastUpdtTs;
	}

	
	public ProgramRiskCateory() {}

	public Integer getCatgryId() {
		return catgryId;
	}

	public void setCatgryId(Integer catgryId) {
		this.catgryId = catgryId;
	}

	public String getCatgryName() {
		return catgryName;
	}

	public void setCatgryName(String catgryName) {
		this.catgryName = catgryName;
	}

	public Integer getProgId() {
		return progId;
	}

	public void setProgId(Integer progId) {
		this.progId = progId;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public void setLastUpdtBy(String lastUpdtBy) {
		this.lastUpdtBy = lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}

	public void setLastUpdtTs(Timestamp lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}
}
