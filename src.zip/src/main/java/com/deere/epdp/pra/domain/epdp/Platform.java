package com.deere.epdp.pra.domain.epdp;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "platform")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Platform implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "pltfm_id")
	private Integer pltfmId;

	@Column(name = "pltfm_nm", nullable = false)
	private String pltfmNm;

	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdtBy;

	@JsonIgnore
	@Column(name = "last_updt_ts")
	private Timestamp lastUpdtTs;

	public Integer getPltfmId() {
		return pltfmId;
	}

	public String getPltfmNm() {
		return pltfmNm;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}

}