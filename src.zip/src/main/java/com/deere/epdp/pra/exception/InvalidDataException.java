package com.deere.epdp.pra.exception;

/**
 * @author RM43492
 * @version 1.0
 * @since 2017-11-01
 */
public class InvalidDataException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public InvalidDataException(String message, Throwable cause) {
		super(message, cause);
	}

	public InvalidDataException(String message) {
		super(message);
	}
}
