package com.deere.epdp.pra.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class RiskCategoryData {
	
	Integer catgryId;
	
	Integer progId;

	String 	catgryName;

	List<String> impactDesc;
	
	String catgryType;
	
	char active;
	
	String catgryAcronym;
	
	public RiskCategoryData() {}

	public RiskCategoryData(Integer catgryId, Integer progId, String catgryName, List<String> impactDesc,
			String catgryType, char active,String catgryAcronym) {
		super();
		this.catgryId = catgryId;
		this.progId = progId;
		this.catgryName = catgryName;
		this.impactDesc = impactDesc;
		this.catgryType = catgryType;
		this.active = active;
		this.catgryAcronym= catgryAcronym;
	}

	public String getCatgryAcronym() {
		return catgryAcronym;
	}

	public void setCatgryAcronym(String catgryAcronym) {
		this.catgryAcronym = catgryAcronym;
	}

	public Integer getCatgryId() {
		return catgryId;
	}

	public void setCatgryId(Integer catgryId) {
		this.catgryId = catgryId;
	}

	public String getCatgryName() {
		return catgryName;
	}

	public void setCatgryName(String catgryName) {
		this.catgryName = catgryName;
	}

	public List<String> getImpactDesc() {
		return impactDesc;
	}

	public void setImpactDesc(List<String> impactDesc) {
		this.impactDesc = impactDesc;
	}

	public Integer getProgId() {
		return progId;
	}

	public void setProgId(Integer progId) {
		this.progId = progId;
	}

	public String getCatgryType() {
		return catgryType;
	}

	public void setCatgryType(String catgryType) {
		this.catgryType = catgryType;
	}

	public char getActive() {
		return active;
	}

	public void setActive(char active) {
		this.active = active;
	}

	
	
	
	
   
	
}
