package com.deere.epdp.pra.domain.epdp;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "division")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Division implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "div_id")
	private Integer divId;

	@Column(name = "div_nm", nullable = false)
	private String divNm;

	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdtBy;

	@JsonIgnore
	@Column(name = "last_updt_ts")
	private Timestamp lastUpdtTs;

	public Integer getDivId() {
		return divId;
	}

	public String getDivNm() {
		return divNm;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}
}