package com.deere.epdp.pra.domain.prm;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "sub_design_team")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DesignSubTeam {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	@Column(name = "name", length = 50, nullable = false)
	private String name;
	
	@Column(name = "prgm_id", nullable = false)
	private Integer prgmId;
	
	@Column(name = "member_typ")
	private Character type;
	
	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdtBy;
	
	@JsonIgnore
	@Column(name = "last_updt_ts")
	private Timestamp lastUpdtTs;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getPrgmId() {
		return prgmId;
	}

	public void setPrgmId(Integer prgmId) {
		this.prgmId = prgmId;
	}

	public Character getType() {
		return type;
	}

	public void setType(Character type) {
		this.type = type;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public void setLastUpdtBy(String lastUpdtBy) {
		this.lastUpdtBy = lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}

	public void setLastUpdtTs(Timestamp lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}

	public DesignSubTeam(Integer id, String name, Integer prgmId, Character type, String lastUpdtBy,
			Timestamp lastUpdtTs) {
		super();
		this.id = id;
		this.name = name;
		this.prgmId = prgmId;
		this.type = type;
		this.lastUpdtBy = lastUpdtBy;
		this.lastUpdtTs = lastUpdtTs;
	}

	public DesignSubTeam() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
