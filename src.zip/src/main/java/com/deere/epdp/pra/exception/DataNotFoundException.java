package com.deere.epdp.pra.exception;

/**
 * @author RM43492
 * @version 1.0
 * @since 2017-11-01
 */
public class DataNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public DataNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	public DataNotFoundException(String message) {
		super(message);
	}
}
