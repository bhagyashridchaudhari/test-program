package com.deere.epdp.pra.serviceImpl.prm;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.deere.epdp.pra.domain.prm.DesignSubTeam;
import com.deere.epdp.pra.domain.user.User;
import com.deere.epdp.pra.model.Response;
import com.deere.epdp.pra.model.Response.RespMessage;
import com.deere.epdp.pra.model.Response.RespMessage.Type;
import com.deere.epdp.pra.model.Response.Status;
import com.deere.epdp.pra.model.SubDesignTeam;
import com.deere.epdp.pra.repo.prm.DesignSubTeamRepository;
import com.deere.epdp.pra.service.prm.DesignSubTeamService;
import com.deere.epdp.pra.utility.CommonUtility;
import com.deere.epdp.pra.utility.Converter;

@Service
public class DesignSubTeamServiceImpl implements DesignSubTeamService {
	
	@Autowired
	private User user;
	
	@Autowired
	private DesignSubTeamRepository teamRepository;

	@Override
	public Iterable<SubDesignTeam> getTeamByPrjId(Integer prjId) {
	  return ((Collection<DesignSubTeam>) teamRepository.findAll()).stream().filter(p -> p.getPrgmId() == prjId).map(Converter::convertToTeam).collect(Collectors.toList()); 
	}

	@Override
	public Response<SubDesignTeam> saveTeam(SubDesignTeam team) {
		List<RespMessage> errors = new ArrayList<>();
		String userId = user.getUserId();
		Timestamp currntTime = CommonUtility.getCurrentTime();
		teamRepository.save(new DesignSubTeam(team.getId(),team.getName(),team.getPrgmId(),team.getType(),userId, currntTime));
		return new Response<>(Status.SUCCESS, team, errors.isEmpty() ? null : errors );
	}

	@Override
	public Response<SubDesignTeam> deleteProjectTeam(Integer id) {
		List<RespMessage> errors = new ArrayList<>();
		try {
			teamRepository.delete(id);
		}catch(Exception e) {
			errors.add(new RespMessage("Not able to delete team.", Type.WARNING));
		}
		return new Response<>(Status.SUCCESS, errors.isEmpty() ? null : errors);
	}

	@Override
	@Transactional(value="prmTransactionManager",readOnly=false,propagation=Propagation.REQUIRED) 
	public void deleteDesignSubTeamByProgram(Integer prjId) {
        teamRepository.deleteDesignSubTeamByProgram(prjId);
	
	}
	

	
	

}
