package com.deere.epdp.pra.service.prm;

import com.deere.epdp.pra.model.ExcelData;

public interface ReportsService {

	public byte[] generateExcel(ExcelData excelData);

	
}
