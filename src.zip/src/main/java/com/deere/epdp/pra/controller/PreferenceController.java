package com.deere.epdp.pra.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deere.epdp.pra.domain.prm.Preferences;
import com.deere.epdp.pra.model.Preference;
import com.deere.epdp.pra.model.Response;
import com.deere.epdp.pra.service.prm.PreferencesService;

@RestController
@RequestMapping("/api/preference")
public class PreferenceController {
	
	@Autowired
	private PreferencesService prefService;
	
	@GetMapping
	public Response<Preference> getPreference() {
		return prefService.getUserPreference();
	}

	@GetMapping("/prj/{prjId}")
	public Response<Preference> getPrgmPreference(@PathVariable Integer prjId) {
		return prefService.getPrgmPreference(prjId);
	}
	
	@PostMapping
	public Response<Preferences> savePreference(@RequestBody Preference pref) {
		return prefService.savePreference(pref);
	}
	
}
