package com.deere.epdp.pra.model;

public class ImageData {

	private Integer projId;
	private Integer riskId;
	private Integer imgId;
	
	public ImageData(Integer projId, Integer riskId, Integer imgId) {
		super();
		this.projId = projId;
		this.riskId = riskId;
		this.imgId = imgId;
	}

	public Integer getProjId() {
		return projId;
	}

	public void setProjId(Integer projId) {
		this.projId = projId;
	}

	public Integer getRiskId() {
		return riskId;
	}

	public void setRiskId(Integer riskId) {
		this.riskId = riskId;
	}

	public Integer getImgId() {
		return imgId;
	}

	public ImageData() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void setImgId(Integer imgId) {
		this.imgId = imgId;
	}
	
	
	
}
