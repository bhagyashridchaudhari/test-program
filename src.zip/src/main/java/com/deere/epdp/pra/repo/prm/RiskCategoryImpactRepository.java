package com.deere.epdp.pra.repo.prm;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.deere.epdp.pra.domain.prm.RiskCategoryImpact;
import com.deere.epdp.pra.domain.prm.RiskCategoryImpact.RiskCategoryImpactId;

public interface RiskCategoryImpactRepository extends CrudRepository<RiskCategoryImpact, RiskCategoryImpactId>{
	
	
	@Query("SELECT rci FROM RiskCategoryImpact rci INNER JOIN rci.id rc where rci.id.ctgryId =?1")
	List<RiskCategoryImpact> findImpactByCategory(Integer id);
	
	
}
