package com.deere.epdp.pra.domain.epdp;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "project_type")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProjectType implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "proj_type_id")
	private Integer typeId;

	@Column(name = "proj_type_name", nullable = false)
	private String typeName;
	
	@Column(name = "acronym")
	private String typeAcronym;

	@Column(name = "proj_type_desc")
	private String typeDesc;

	@Column(name = "process_id")
	private Integer processId;

	@Column(name = "is_active", length = 1)
	@ColumnDefault("'Y'")
	private String isActive;

	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdtBy;

	@JsonIgnore
	@Column(name = "last_updt_ts")
	private Timestamp lastUpdtTs;

	public Integer getTypeId() {
		return typeId;
	}

	public String getTypeName() {
		return typeName;
	}

	public String getTypeDesc() {
		return typeDesc;
	}

	public Integer getProcessId() {
		return processId;
	}

	public String getIsActive() {
		return isActive;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}
	
	public String getTypeAcronym() {
		return typeAcronym;
	}
}