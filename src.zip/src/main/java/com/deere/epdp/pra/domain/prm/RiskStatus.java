package com.deere.epdp.pra.domain.prm;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "risk_status")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RiskStatus implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "id")
	private Integer statusId;

	@Column(name = "name", nullable = false)
	private String statusName;

	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdtBy;
	
	@JsonIgnore
	@Column(name = "last_updt_ts")
	private Timestamp lastUpdtTs;

	public Integer getStatusId() {
		return statusId;
	}

	public void setStatusId(Integer statusId) {
		this.statusId = statusId;
	}

	public String getStatusName() {
		return statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public void setLastUpdtBy(String lastUpdtBy) {
		this.lastUpdtBy = lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}

	public void setLastUpdtTs(Timestamp lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}
	
	
	
}
