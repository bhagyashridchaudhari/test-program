package com.deere.epdp.pra.repo.epdp;

import org.springframework.data.repository.CrudRepository;

import com.deere.epdp.pra.domain.epdp.ProjectProcess;

public interface ProcessRepository extends CrudRepository<ProjectProcess, Integer> {}
