package com.deere.epdp.pra.repo.prm;

import org.springframework.data.repository.CrudRepository;

import com.deere.epdp.pra.domain.prm.RiskImpact;

public interface RiskImpactRepository extends CrudRepository<RiskImpact, Integer> {}
