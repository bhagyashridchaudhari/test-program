package com.deere.epdp.pra.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deere.epdp.pra.model.ExcelData;
import com.deere.epdp.pra.service.prm.ReportsService;

@RestController
@RequestMapping("/api/report")
public class ReportsController {

	@Autowired
	private  ReportsService reportService;
	
	@PostMapping("/export-excel")
	public ResponseEntity<byte[]> downloadSampleCSV(@RequestBody ExcelData excelData) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.parseMediaType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
		return new ResponseEntity<>(reportService.generateExcel(excelData), headers, HttpStatus.OK);
	}
	
}
