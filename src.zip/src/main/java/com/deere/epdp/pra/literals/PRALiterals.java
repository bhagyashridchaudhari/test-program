package com.deere.epdp.pra.literals;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class PRALiterals {
	
	/* Date Time Formats in Risk Assessment */
	public static final String DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'";
	
	/* User Roles in PRA */
	public static final int OWNER_ROLE = 1;
	public static final int FULL_ACCESS_ROLE = 2;
	public static final int UPDATE_ROLE = 3;
	public static final int VIEW_ROLE = 4;

	
	/* Processes Id in PRA */
	public static final int EPDP_PROCESS_ID = 1;
	// public static final int TDP_PROCESS_ID = 2
	public static final int NME_PROCESS_ID = 4;
	public static final int INORGANIC_PROCESS_ID = 5;
	public static final int CIP_PROCESS_ID = 6;
	//	public static final int PIW1_PROCESS_ID = 7
	//	public static final int PIW2_PROCESS_ID = 8
	public static final int ISDP_PROCESS_ID = 9;
	
	/* Program type process mapping for PRA */
	public static final Map<Integer, Integer> PROGRAMTYPE_PROCESS_MAP;

	/* Status Id mapping for PRA */
	public static final Map<Integer, List<Integer>> STATUS_ID_MAP;

	/* All country currency for PRA */
	public static final List<String> ALL_COUNTRY_CURRENCY;

	/* User Types allowed for application */
	public static final List<String> APP_ALLOW_USER_TYPE;

	/* User Types allowed for create and manage projects */
	public static final List<String> CREATE_ALLOW_USER_TYPE;

	/* Production Admin */
	public static final List<String> PROD_ADMIN;

	/* Non Production Admin */
	public static final List<String> NON_PROD_ADMIN;
	
//	public static final List<String> PREFERENCE_COLS;
	public static final Map<String,String> PREFERENCE_COLS;
	
	// Email Literals
	public static final String EMAIL_FROM = "PRM@JohnDeere.com";
	public static final String REG_AUDIT_NOTIFICATION_EMAIL_SUBJECT = "Program Risk Management";
	public static final String HOST = "mail.dx.deere.com";
	public static final String SMTP_HOST = "mail.smtp.host";
	
	
	static {

		Map<Integer, Integer> programtypeProcessMap = new HashMap<>();
		programtypeProcessMap.put(1, EPDP_PROCESS_ID);
		programtypeProcessMap.put(2, INORGANIC_PROCESS_ID);
		programtypeProcessMap.put(3, EPDP_PROCESS_ID);
		programtypeProcessMap.put(5, EPDP_PROCESS_ID);
		programtypeProcessMap.put(6, NME_PROCESS_ID);
		programtypeProcessMap.put(9, ISDP_PROCESS_ID);
		PROGRAMTYPE_PROCESS_MAP = Collections.unmodifiableMap(programtypeProcessMap);

		Map<Integer, List<Integer>> statusIdMap = new HashMap<>();
		statusIdMap.put(1, Arrays.asList(2, 3, 5, 6)); // Removed 4 for Completed status
		statusIdMap.put(2, Arrays.asList(1, 5, 6));
		statusIdMap.put(3, Arrays.asList(1, 5, 6)); // Removed 4 for Completed status
		statusIdMap.put(4, Arrays.asList(1));
		statusIdMap.put(5, Arrays.asList(1, 3, 6));
		statusIdMap.put(6, Arrays.asList(1, 5));
		STATUS_ID_MAP = Collections.unmodifiableMap(statusIdMap);

		ALL_COUNTRY_CURRENCY = Collections.unmodifiableList(Arrays.asList("United States (US$)", "Brazil (R$)", "China (Renminbi ¥)", "European Union (Euro €)", "India (Rupee ₨)", "Mexico (Peso ₱)"));

		APP_ALLOW_USER_TYPE = Collections.unmodifiableList(Arrays.asList("WAGE EMPLOYEE", "SALARIED EMPLOYEE", "CONTRACTOR ON-SITE", "CONTINGENT ON-SITE"));

		CREATE_ALLOW_USER_TYPE = Collections.unmodifiableList(Arrays.asList("WAGE EMPLOYEE", "SALARIED EMPLOYEE", "CONTRACTOR ON-SITE", "CONTINGENT ON-SITE"));

		PROD_ADMIN = Collections.unmodifiableList(Arrays.asList("DA77241", "LV00916", "RG39824", "TX17364"));

		NON_PROD_ADMIN = Collections.unmodifiableList(Arrays.asList("BC04761","AS22820","WW2WQQH","PG80882", "DS1ZT83"));
		
		Map<String,String> cols = new LinkedHashMap<>();
	//	cols.put("action", "Action");
	//	cols.put("rsktitle", "Risk Title");
		cols.put("rlevel", "Level");
		cols.put("mlevel", "Mitigated Level");
		cols.put("mowner", "Mitigation Owner");
		cols.put("trgtclsre", "Target Closure");
		cols.put("subteam", "Sub Team");
		cols.put("designteam", "Design Team");
		cols.put("cseif", "Cause IF");
		cols.put("effctthn", "Effect THEN");
		cols.put("rcrdate", "Date Created");
		cols.put("rorgntor", "Risk Originator");
		cols.put("nxtreview", "Next Review");
		cols.put("ctgry", "Category");
		cols.put("mstatus", "Mitigation Status");
		cols.put("rstrgy", "Response Strategy");
		cols.put("msbprcs", "Owner Subprocess");
		PREFERENCE_COLS = Collections.unmodifiableMap(cols);
		
	}
	// rcrdate
}
