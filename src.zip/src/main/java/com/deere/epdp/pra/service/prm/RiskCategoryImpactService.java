package com.deere.epdp.pra.service.prm;

import java.util.List;

import com.deere.epdp.pra.domain.prm.RiskCategoryImpact;

public interface RiskCategoryImpactService {
	
	void init();

	List<RiskCategoryImpact> getAllRiskCategoryImpact();
	
	
	List<RiskCategoryImpact> findImpactByCategory(Integer id);
	
	
	

}
