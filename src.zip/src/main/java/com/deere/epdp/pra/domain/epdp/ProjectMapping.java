package com.deere.epdp.pra.domain.epdp;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.ColumnDefault;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "proj_mapping")
public class ProjectMapping implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ProjectMappingId id;

	@Column(name = "is_active", length = 1)
	@ColumnDefault("'N'")
	private String isActive;

	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdtBy;

	@JsonIgnore
	@Column(name = "last_updt_ts")
	private Timestamp lastUpdtTs;
	
	@Transient
	private String name;

	public ProjectMapping() {
		super();
	}

	public ProjectMapping(Integer prjId, Integer sourceId, Integer mappedId, String isActive) {
		super();
		this.id = new ProjectMappingId(prjId, sourceId, mappedId);
		this.isActive = isActive;
	}

	public ProjectMappingId getId() {
		return id;
	}

	public void setId(ProjectMappingId id) {
		this.id = id;
	}

	public String getIsActive() {
		return isActive;
	}

	public void setIsActive(String isActive) {
		this.isActive = isActive;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public void setLastUpdtBy(String lastUpdtBy) {
		this.lastUpdtBy = lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}

	public void setLastUpdtTs(Timestamp lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Embeddable
	public static class ProjectMappingId implements Serializable {

		private static final long serialVersionUID = 1L;

		@Column(name = "proj_id")
		private Integer prjId;

		@Column(name = "app_id")
		private Integer appId;

		@Column(name = "mapped_id")
		private Integer mappedId;

		public ProjectMappingId() {
			super();
		}

		public ProjectMappingId(Integer prjId, Integer appId, Integer mappedId) {
			super();
			this.prjId = prjId;
			this.appId = appId;
			this.mappedId = mappedId;
		}

		public Integer getPrjId() {
			return prjId;
		}

		public void setPrjId(Integer prjId) {
			this.prjId = prjId;
		}

		public Integer getAppId() {
			return appId;
		}

		public void setAppId(Integer appId) {
			this.appId = appId;
		}

		public Integer getMappedId() {
			return mappedId;
		}

		public void setMappedId(Integer mappedId) {
			this.mappedId = mappedId;
		}
	}
}