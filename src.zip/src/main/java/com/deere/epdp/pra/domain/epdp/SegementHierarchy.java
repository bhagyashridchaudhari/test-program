package com.deere.epdp.pra.domain.epdp;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "seg_hrchy")
public class SegementHierarchy implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SegementHierarchyId id;

	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdtBy;

	@JsonIgnore
	@Column(name = "last_updt_ts")
	private Timestamp lastUpdtTs;

	@Column(name = "is_active", length = 1)
	@ColumnDefault("'Y'")
	private String isActive;

	public SegementHierarchyId getId() {
		return id;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}

	public String getIsActive() {
		return isActive;
	}

	@Embeddable
	public static class SegementHierarchyId implements Serializable {

		private static final long serialVersionUID = 1L;

		@Column(name = "div_id")
		private Integer divId;

		@Column(name = "pltfm_id")
		private Integer pltfmId;

		@Column(name = "prdln_id")
		private Integer prdlnId;

		@Column(name = "prdfmly_id")
		private Integer prdfmlyId;

		@Column(name = "unt_id")
		private Integer unitId;

		public Integer getDivId() {
			return divId;
		}

		public Integer getPltfmId() {
			return pltfmId;
		}

		public Integer getPrdlnId() {
			return prdlnId;
		}

		public Integer getPrdfmlyId() {
			return prdfmlyId;
		}

		public Integer getUnitId() {
			return unitId;
		}
	}
}