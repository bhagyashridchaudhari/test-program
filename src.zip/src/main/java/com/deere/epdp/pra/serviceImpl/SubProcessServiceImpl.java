package com.deere.epdp.pra.serviceImpl;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deere.epdp.pra.domain.epdp.SubProcess;
import com.deere.epdp.pra.repo.epdp.SubprocessRepository;
import com.deere.epdp.pra.service.SubProcessService;

@Service
public class SubProcessServiceImpl implements SubProcessService {
	
	@Autowired
	private SubprocessRepository subProcessRepository;

	private Map<Integer, SubProcess> subProcessMap;

	@PostConstruct
	public void init() {
		subProcessMap = StreamSupport.stream(subProcessRepository.findAll().spliterator(), false)
				.collect(Collectors.toMap(SubProcess::getId, Function.identity()));
	}

	@Override
	public List<SubProcess> getAllSubProcess() {
		 return subProcessMap.values().stream().filter(s -> s.getStatus() == 'Y').sorted(Comparator.comparing(SubProcess::getAcronym)).collect(Collectors.toList());
	}

	@Override
	public SubProcess getSubProcessById(Integer id) {
		return subProcessMap.get(id);
	}

}
