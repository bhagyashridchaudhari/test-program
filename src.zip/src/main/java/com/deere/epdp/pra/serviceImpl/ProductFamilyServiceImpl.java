package com.deere.epdp.pra.serviceImpl;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deere.epdp.pra.domain.epdp.ProductFamily;
import com.deere.epdp.pra.repo.epdp.ProductFamilyRepository;
import com.deere.epdp.pra.service.ProductFamilyService;

@Service
public class ProductFamilyServiceImpl implements ProductFamilyService {

	@Autowired
	private ProductFamilyRepository productFamilyRepository;

	private Map<Integer, ProductFamily> productFamilyMap;

	@PostConstruct
	public void init() {
		productFamilyMap = StreamSupport.stream(productFamilyRepository.findAll().spliterator(), false)
				.collect(Collectors.toMap(ProductFamily::getPrdfmyId, Function.identity()));
	}

	@Override
	public List<ProductFamily> getAllProductFamily() {
		return productFamilyMap.values().stream().sorted(Comparator.comparing(ProductFamily::getPrdfmyNm)).collect(Collectors.toList());
	}

	@Override
	public String getProductFamilyNameById(Integer id) {
		ProductFamily family = productFamilyMap.get(id);
		return family != null ? family.getPrdfmyNm() : null;
	}

}
