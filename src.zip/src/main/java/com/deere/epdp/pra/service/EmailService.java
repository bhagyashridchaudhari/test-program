package com.deere.epdp.pra.service;

public interface EmailService {
	
	 void sendSimpleMessage(String to,
             String subject,
             String text);

}
