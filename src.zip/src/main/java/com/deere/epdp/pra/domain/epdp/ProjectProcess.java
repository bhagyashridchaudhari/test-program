package com.deere.epdp.pra.domain.epdp;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "process")
public class ProjectProcess implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "process_id")
	private Integer processId;

	@Column(name = "process_nm", nullable = false)
	private String processNm;

	@Column(name = "process_acronym", nullable = false)
	private String processAcronym;

	@Column(name = "is_active")
	private Boolean isActive;

	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdtBy;

	@JsonIgnore
	@Column(name = "last_updt_ts", nullable = false)
	private Timestamp lastUpdtTs;

	public Integer getProcessId() {
		return processId;
	}

	public String getProcessNm() {
		return processNm;
	}

	public String getProcessAcronym() {
		return processAcronym;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}
}
