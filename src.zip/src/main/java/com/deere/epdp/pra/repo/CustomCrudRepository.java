package com.deere.epdp.pra.repo;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.data.repository.Repository;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;


@NoRepositoryBean
public interface CustomCrudRepository<T, ID extends Serializable> extends Repository<T, ID> {
	
	<S extends T> S save(S arg0);

	<S extends T> Iterable<S> save(Iterable<S> arg0);
	
	int[] saveAndFlush(String arg0, MapSqlParameterSource[] arg1);
	
	int saveAndFlush(String arg0, MapSqlParameterSource arg1);
	
	List<T> findAll(Specification<T> spec);

	T findOne(ID arg0);

	boolean exists(ID arg0);

	Iterable<T> findAll();

	Iterable<T> findAll(Iterable<ID> arg0);
	
	List<T> findAll(String arg0, MapSqlParameterSource parameters, RowMapper<T> arg2);

	long count();

	void delete(ID arg0);
	
	void deleteAndFlush(Iterable<ID> arg0);

	void delete(T arg0);

	void delete(Iterable<? extends T> arg0);

	void deleteById(ID arg0);
}
