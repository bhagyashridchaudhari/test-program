package com.deere.epdp.pra.repo.prm;

import org.springframework.data.repository.CrudRepository;

import com.deere.epdp.pra.domain.prm.Preferences;

public interface PreferencesRepository extends CrudRepository<Preferences, Integer> {}
