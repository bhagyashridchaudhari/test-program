package com.deere.epdp.pra.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

import com.deere.epdp.pra.service.EmailService;

// @Component
public class EmailServiceImpl implements EmailService {
  
    @Autowired
    public JavaMailSender emailSender;
 
    public void sendSimpleMessage(
      String to, String subject, String text) {
		try {
			SimpleMailMessage simpleMailMessage=new SimpleMailMessage();
		      simpleMailMessage.setSubject(subject);
		      simpleMailMessage.setFrom("ChaudhariBhagyashree@JohnDeere.com");
		      simpleMailMessage.setTo("ChaudhariBhagyashree@JohnDeere.com");
		      simpleMailMessage.setText("test mail ...!!!");
		      emailSender.send(simpleMailMessage);
		}catch(Exception e) {
			e.printStackTrace();
		}
    }
}