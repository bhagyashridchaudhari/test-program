package com.deere.epdp.pra.model;

import java.util.List;
import java.util.stream.Collectors;

// import com.deere.epdp.commonseg.utility.CommonUtility;
import com.deere.epdp.pra.domain.epdp.BuildDate;
import com.deere.epdp.pra.domain.epdp.Division;
import com.deere.epdp.pra.domain.epdp.Milestone;
import com.deere.epdp.pra.domain.epdp.Phase;
import com.deere.epdp.pra.domain.epdp.Platform;
import com.deere.epdp.pra.domain.epdp.ProcessSubProcess;
import com.deere.epdp.pra.domain.epdp.ProductFamily;
import com.deere.epdp.pra.domain.epdp.ProductLine;
import com.deere.epdp.pra.domain.epdp.ProjectAssociations;
import com.deere.epdp.pra.domain.epdp.ProjectProcess;
import com.deere.epdp.pra.domain.epdp.ProjectStatus;
import com.deere.epdp.pra.domain.epdp.ProjectType;
import com.deere.epdp.pra.domain.epdp.SegementHierarchy;
import com.deere.epdp.pra.domain.epdp.SubProcess;
import com.deere.epdp.pra.domain.epdp.Unit;
import com.deere.epdp.pra.domain.prm.MitigationStatus;
import com.deere.epdp.pra.domain.prm.ResponseStratergy;
import com.deere.epdp.pra.domain.prm.RiskCategory;
import com.deere.epdp.pra.domain.prm.RiskCategoryImpact;
import com.deere.epdp.pra.domain.prm.RiskImpact;
import com.deere.epdp.pra.domain.prm.RiskProbability;
import com.deere.epdp.pra.domain.prm.RiskScoreLevel;
import com.deere.epdp.pra.domain.prm.Role;
import com.deere.epdp.pra.literals.PRALiterals;

public class CommonData {
	
	private List<ProjectAssociations> ppa;
	
	private List<SegementHierarchy> psh;
	
	private List<ProjectType> ptp;
	
	private List<ProjectStatus> pst;
	
	private List<Division> pdv;
	
	private List<Platform> plf;
	
	private List<ProductLine> pln;
	
	private List<ProductFamily> pfm;
	
	private List<Unit> put;
	
	private List<Role> prl;
	
	private List<ProjectProcess> prs;
	
	private List<Phase> pps;
	
	private List<Milestone> pms;
	
	private List<BuildDate> bdt;
		
	private List<String> pcu;
	
	private Integer[] eapt;
	
	private String env;

	private List<RiskCategory> rCtgry;
	
	private List<RiskImpact> rImp;
	
	private List<ResponseStratergy> rspStrgy;
	
	private List<RiskProbability> rPblty;
	
	private List<RiskCategoryImpact> rCI;
	
	private List<RiskScoreLevel> rsl;
	
	private List<MitigationStatus> mSts;
	
	private List<SubProcess> subp;
	
	private List<ProcessSubProcess> psubprltn;
	
//	Map<ProjectType, List<SubProcess>> prgSubPrcsMap;
	
	private List<String[]> preferenceCols = PRALiterals.PREFERENCE_COLS.entrySet().stream().map(e -> new String[] { e.getKey(), e.getValue() }).collect(Collectors.toList());

	public CommonData() {
		super();
	}

	public List<ProjectAssociations> getPpa() {
		return ppa;
	}

	public void setPpa(List<ProjectAssociations> ppa) {
		this.ppa = ppa;
	}
	

	public List<MitigationStatus> getmSts() {
		return mSts;
	}

	public void setmSts(List<MitigationStatus> mSts) {
		this.mSts = mSts;
	}

	public List<SegementHierarchy> getPsh() {
		return psh;
	}

	public void setPsh(List<SegementHierarchy> psh) {
		this.psh = psh;
	}

	public List<ProjectType> getPtp() {
		return ptp;
	}

	public void setPtp(List<ProjectType> ptp) {
		this.ptp = ptp;
	}

	public List<ProjectStatus> getPst() {
		return pst;
	}

	public void setPst(List<ProjectStatus> pst) {
		this.pst = pst;
	}

	public List<Division> getPdv() {
		return pdv;
	}

	public void setPdv(List<Division> pdv) {
		this.pdv = pdv;
	}

	public List<Platform> getPlf() {
		return plf;
	}

	public void setPlf(List<Platform> plf) {
		this.plf = plf;
	}

	public List<ProductLine> getPln() {
		return pln;
	}

	public void setPln(List<ProductLine> pln) {
		this.pln = pln;
	}

	public List<ProductFamily> getPfm() {
		return pfm;
	}

	public void setPfm(List<ProductFamily> pfm) {
		this.pfm  = pfm;
	}

	public List<Unit> getPut() {
		return put;
	}

	public void setPut(List<Unit> put) {
		this.put = put;
	}

	public List<Role> getPrl() {
		return prl;
	}

	public void setPrl(List<Role> prl) {
		this.prl = prl;
	}

	public List<ProjectProcess> getPrs() {
		return prs;
	}

	public void setPrs(List<ProjectProcess> prs) {
		this.prs = prs;
	}

	public List<Phase> getPps() {
		return pps;
	}

	public void setPps(List<Phase> pps) {
		this.pps = pps;
	}

	public List<Milestone> getPms() {
		return pms;
	}

	public void setPms(List<Milestone> pms) {
		this.pms = pms;
	}

	public List<BuildDate> getBdt() {
		return bdt;
	}

	public void setBdt(List<BuildDate> bdt) {
		this.bdt = bdt;
	}

	public List<String> getPcu() {
		return pcu;
	}

	public void setPcu(List<String> pcu) {
		this.pcu = pcu;
	}

	public Integer[] getEapt() {
		return eapt;
	}

	public void setEapt(Integer[] eapt) {
		this.eapt = eapt;
	}

	public String getEnv() {
		return env;
	}

	public void setEnv(String env) {
		this.env = env;
	}

	public List<RiskCategory> getrCtgry() {
		return rCtgry;
	}

	public void setrCtgry(List<RiskCategory> rCtgry) {
		this.rCtgry = rCtgry;
	}

	public List<RiskImpact> getrImp() {
		return rImp;
	}

	public void setrImp(List<RiskImpact> rImp) {
		this.rImp = rImp;
	}

	public List<ResponseStratergy> getRspStrgy() {
		return rspStrgy;
	}

	public void setRspStrgy(List<ResponseStratergy> rspStrgy) {
		this.rspStrgy = rspStrgy;
	}

	public List<RiskProbability> getrPblty() {
		return rPblty;
	}

	public void setrPblty(List<RiskProbability> rPblty) {
		this.rPblty = rPblty;
	}

	public List<RiskCategoryImpact> getrCI() {
		return rCI;
	}

	public void setrCI(List<RiskCategoryImpact> rCI) {
		this.rCI = rCI;
	}

	public List<RiskScoreLevel> getRsl() {
		return rsl;
	}

	public void setRsl(List<RiskScoreLevel> rsl) {
		this.rsl = rsl;
	}

	public List<SubProcess> getSubp() {
		return subp;
	}

	public void setSubp(List<SubProcess> subp) {
		this.subp = subp;
	}

	public List<String[]> getPreferenceCols() {
		return preferenceCols;
	}

	public void setPreferenceCols(List<String[]> preferenceCols) {
		this.preferenceCols = preferenceCols;
	}

	public List<ProcessSubProcess> getPsubprltn() {
		return psubprltn;
	}

	public void setPsubprltn(List<ProcessSubProcess> psubprltn) {
		this.psubprltn = psubprltn;
	}

	public CommonData copy(){
		CommonData cd =  new CommonData();
		cd.setPpa(this.ppa);
		cd.setPsh(this.psh);
		cd.setPtp(this.ptp);
		cd.setPst(this.pst);
		cd.setPdv(this.pdv);
		cd.setPlf(this.plf);
		cd.setPln(this.pln);
		cd.setPfm(this.pfm);
		cd.setPut(this.put);
		cd.setPrl(this.prl);
		cd.setPrs(this.prs);
		cd.setPps(this.pps);
		cd.setPms(this.pms);
		cd.setBdt(this.bdt);
		cd.setPcu(this.pcu);
		cd.setEapt(this.eapt);
		cd.setEnv(this.env);
		cd.setrCtgry(this.rCtgry);
		cd.setrImp(this.rImp);
		cd.setRspStrgy(this.rspStrgy);
		cd.setrPblty(this.rPblty);
		cd.setrCI(this.rCI);
		cd.setRsl(this.rsl);
		cd.setmSts(this.mSts);
		cd.setSubp(this.subp);
		cd.setPreferenceCols(this.preferenceCols);
		cd.setPsubprltn(psubprltn);
		return cd;
	}
}
