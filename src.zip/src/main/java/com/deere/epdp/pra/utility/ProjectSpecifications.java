package com.deere.epdp.pra.utility;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

import javax.persistence.criteria.Predicate;

import org.springframework.data.jpa.domain.Specification;

import com.deere.epdp.pra.domain.prm.Project;
import com.deere.epdp.pra.domain.prm.Project_;
import com.deere.epdp.pra.model.ProjectFilter;

public final class ProjectSpecifications {

	private ProjectSpecifications() {
	}

	public static Specification<Project> build(Project project) {
		return (root, query, cb) -> {
			List<Predicate> p = new ArrayList<>();

			if (project.getPrjId() != null)
				p.add(cb.equal(root.<Integer> get(Project_.prjId), project.getPrjId()));

			if (project.getDivId() != null)
				p.add(cb.equal(root.<Integer> get(Project_.divId), project.getDivId()));

			if (project.getPltfmId() != null)
				p.add(cb.equal(root.<Integer> get(Project_.pltfmId), project.getPltfmId()));

			if (project.getPrdlnId() != null)
				p.add(cb.equal(root.<Integer> get(Project_.prdlnId), project.getPrdlnId()));

			if (project.getPrdfmlyId() != null)
				p.add(cb.equal(root.<Integer> get(Project_.prdfmlyId), project.getPrdfmlyId()));

			if (project.getUnitId() != null)
				p.add(cb.equal(root.<Integer> get(Project_.unitId), project.getUnitId()));

			if (project.getPrjStatusId() != null)
				p.add(cb.equal(root.<Integer> get(Project_.prjStatusId), project.getPrjStatusId()));
			
			if (project.getPrjTypeId() != null)
				p.add(cb.equal(root.<Integer> get(Project_.prjTypeId), project.getPrjTypeId()));

			if (project.getPrjId() != null)
				p.add(cb.equal(root.<Integer> get(Project_.prjId), project.getPrjId()));

			if (project.getPrjName() != null && !project.getPrjName().isEmpty())
				p.add(cb.like(cb.lower(root.<String> get(Project_.prjName)), "%" + project.getPrjName().toLowerCase() + "%"));

			if (project.getPrjOwner() != null && !project.getPrjOwner().isEmpty())
				p.add(cb.equal(root.<String> get(Project_.prjOwner), project.getPrjOwner()));

			return cb.and(p.toArray(new Predicate[p.size()]));
		};
	}
	
	public static Specification<Project> build(ProjectFilter projectFilter, Set<Integer> prjIds) {
		return (root, query, cb) -> {
			List<Predicate> p = new ArrayList<>();
			
			if (prjIds != null && !prjIds.isEmpty())
				p.add(root.<Integer> get(Project_.prjId).in(prjIds));

			if (projectFilter.getDivIds() != null && !projectFilter.getDivIds().isEmpty())
				p.add(root.<Integer> get(Project_.divId).in(projectFilter.getDivIds()));

			if (projectFilter.getPltfmIds() != null && !projectFilter.getPltfmIds().isEmpty())
				p.add(root.<Integer> get(Project_.pltfmId).in(projectFilter.getPltfmIds()));

			if (projectFilter.getPrdlnIds() != null && !projectFilter.getPrdlnIds().isEmpty())
				p.add(root.<Integer> get(Project_.prdlnId).in(projectFilter.getPrdlnIds()));

			if (projectFilter.getPrdfmlyIds() != null && !projectFilter.getPrdfmlyIds().isEmpty())
				p.add(root.<Integer> get(Project_.prdfmlyId).in(projectFilter.getPrdfmlyIds()));

			if (projectFilter.getUnitIds() != null && !projectFilter.getUnitIds().isEmpty())
				p.add(root.<Integer> get(Project_.unitId).in(projectFilter.getUnitIds()));

			if (projectFilter.getPrjStatusIds() != null && !projectFilter.getPrjStatusIds().isEmpty())
				p.add(root.<Integer> get(Project_.prjStatusId).in(projectFilter.getPrjStatusIds()));
			
			if (projectFilter.getPrjTypeIds() != null && !projectFilter.getPrjTypeIds().isEmpty())
				p.add(root.<Integer> get(Project_.prjTypeId).in(projectFilter.getPrjTypeIds()));
			
			p.add(cb.greaterThanOrEqualTo(root.<Date> get(Project_.prjEndDt), projectFilter.getStartDate()));
			
			p.add(cb.lessThanOrEqualTo(root.<Date> get(Project_.prjStartDate), projectFilter.getEndDate()));

			return cb.and(p.toArray(new Predicate[p.size()]));
		};
	}
}
