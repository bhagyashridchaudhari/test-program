package com.deere.epdp.pra.repo.prm;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.deere.epdp.pra.domain.prm.ProgramRiskCateory;
import com.deere.epdp.pra.repo.CustomCrudRepository;

public interface ProgramCategoryRepository extends CustomCrudRepository<ProgramRiskCateory, Serializable> {
	
	List<ProgramRiskCateory> findProrgamRiskCateoryByProgId(Integer progid);

	@Modifying
	@Query("update ProgramRiskCateory prc set prc.catgryName =?2,prc.lastUpdtBy=?4, prc.lastUpdtTs=?5 where prc.catgryId = ?1 and prc.progId=?3")
	void update(Integer catgryId, String catgryName, Integer progId, String userId,Timestamp currentTime);	
}
