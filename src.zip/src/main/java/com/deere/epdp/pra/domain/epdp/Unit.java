package com.deere.epdp.pra.domain.epdp;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "unit")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Unit implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "unt_id")
	private Integer unitId;

	@Column(name = "unt_cd")
	private String unitCd;

	@Column(name = "unt_nm", nullable = false)
	private String unitNm;

	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdtBy;

	@JsonIgnore
	@Column(name = "last_updt_ts")
	private Timestamp lastUpdtTs;

	public Integer getUnitId() {
		return unitId;
	}

	public String getUnitCd() {
		return unitCd;
	}

	public String getUnitNm() {
		return unitNm;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}
}