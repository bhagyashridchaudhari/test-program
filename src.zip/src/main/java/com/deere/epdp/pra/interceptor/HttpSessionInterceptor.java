package com.deere.epdp.pra.interceptor;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.deere.dsfj.utility.ServletUtility;
import com.deere.epdp.pra.domain.user.User;
import com.deere.epdp.pra.service.UserService;
import com.deere.epdp.pra.utility.CommonUtility;

@Component(value = "httpSessionInterceptor")
public class HttpSessionInterceptor extends HandlerInterceptorAdapter {

	@Autowired
	private UserService userService;

	@Autowired
	private User user;

	@Value("${spring.profiles.active:Local}")
	private String env;

	private static final Logger LOGGER = LoggerFactory.getLogger(HttpSessionInterceptor.class);

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
		HttpSession session = request.getSession();
		String userId = CommonUtility.getUserId(request);
		final String loggedId = request.getHeader("logged-user");
		
		if ("Local".equals(env) && userId == null)
			userId = "AS22820";

		MDC.put("userId", userId);
		MDC.put("sessionId", session.getId());

		if (loggedId != null && !loggedId.isEmpty() && user.getUserId() != null && !loggedId.equals(userId)) {
			session.removeAttribute(ServletUtility.getUserIdHeaderKey());
			user.consume(new User());
			throw new RuntimeException("You are not authenticated. Please authenticate again.");
		} else if (user.getUserId() == null) {
			try {
				user.consume(userService.getUserDetails(userId));
				user.setUserId(userId);
				user.setSimulated(session.getAttribute(ServletUtility.getUserIdHeaderKey()) != null);
				LOGGER.info("{} successfully logged in at {}", userId, new Date());
			} catch (Exception ex) {
				throw new RuntimeException("Got exception fetching user for userId " + userId, ex);
			}
		}
		return true;
	}
}