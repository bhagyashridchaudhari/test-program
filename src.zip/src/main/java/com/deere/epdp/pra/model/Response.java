package com.deere.epdp.pra.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Response<T> {
	
	public enum Status {SUCCESS, ERROR, IN_PROGRESS}
	
	private Status status = Status.SUCCESS;
	
	private T body;
	
	private List<RespMessage> messages;

	public Response() {
		super();
	}

	public Response(Status status) {
		super();
		this.status = status;
	}

	public Response(T body) {
		super();
		this.body = body;
	}

	public Response(Status status, T body) {
		super();
		this.status = status;
		this.body = body;
	}

	public Response(Status status, List<RespMessage> messages) {
		super();
		this.status = status;
		this.messages = messages;
	}

	public Response(Status status, T body, List<RespMessage> messages) {
		super();
		this.status = status;
		this.body = body;
		this.messages = messages;
	}

	public Status getStatus() {
		return status;
	}

	public T getBody() {
		return body;
	}

	public List<RespMessage> getMessages() {
		return messages;
	}
	
	public static class RespMessage {

		public enum Type {SUCCESS, DANGER, WARNING, INFO, ALERT}
		
		private String data;
		
		private Type type = Type.DANGER;

		public RespMessage() {
			super();
		}

		public RespMessage(String data) {
			super();
			this.data = data;
		}

		public RespMessage(String data, Type type) {
			super();
			this.data = data;
			this.type = type;
		}

		public String getData() {
			return data;
		}

		public Type getType() {
			return type;
		}
	}

}
