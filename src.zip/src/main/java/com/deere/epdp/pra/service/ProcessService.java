package com.deere.epdp.pra.service;

import java.util.List;

import com.deere.epdp.pra.domain.epdp.ProjectProcess;

public interface ProcessService {
	
	void init();

	List<ProjectProcess> getAllProcess();

	ProjectProcess getProcessById(Integer id);

}
