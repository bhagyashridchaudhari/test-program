package com.deere.epdp.pra.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.deere.epdp.pra.interceptor.HttpSessionInterceptor;
import com.deere.epdp.pra.interceptor.SegmentApiInterceptor;

@Configuration
public class MvcConfig extends WebMvcConfigurerAdapter {

	@Autowired
	private HttpSessionInterceptor httpSessionInterceptor;
	
	
	@Autowired
	private SegmentApiInterceptor segmentApiInterceptor;
	 
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(httpSessionInterceptor).addPathPatterns("/api/**").excludePathPatterns("/api/users/**", "/api/segment/**","/web/api/comseg/**");
		registry.addInterceptor(segmentApiInterceptor).addPathPatterns("/api/segment/**");
	}

	@Override
	public void addViewControllers(ViewControllerRegistry registry) {
		registry.addViewController("/web/**").setViewName("forward:/index.html");
	}
}