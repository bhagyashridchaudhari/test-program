package com.deere.epdp.pra.serviceImpl;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deere.epdp.pra.domain.epdp.ProjectStatus;
import com.deere.epdp.pra.repo.epdp.ProjectStatusRepository;
import com.deere.epdp.pra.service.ProjectStatusService;
import com.deere.epdp.pra.utility.CommonUtility;

@Service
public class ProjectStatusServiceImpl implements ProjectStatusService {

	@Autowired
	private ProjectStatusRepository projectStatusRepository;

	private Map<Integer, ProjectStatus> projectStatusMap;

	@PostConstruct
	public void init() {
		projectStatusMap = StreamSupport.stream(projectStatusRepository.findAll().spliterator(), false)
				.map(CommonUtility::setMappedStatusId)
				.collect(Collectors.toMap(ProjectStatus::getStatusId, Function.identity()));
	}

	@Override
	public List<ProjectStatus> getAllProjectStatus() {
		return projectStatusMap.values().stream().sorted(Comparator.comparing(ProjectStatus::getStatusNm)).collect(Collectors.toList());
	}

	@Override
	public String getProjectStatusNameById(Integer id) {
		ProjectStatus status = projectStatusMap.get(id);
		return status != null ? status.getStatusNm() : null;
	}
}
