package com.deere.epdp.pra.service.prm;

import java.util.List;

import com.deere.epdp.pra.domain.prm.RiskCategory;
import com.deere.epdp.pra.model.MitigationPlanOwner;
import com.deere.epdp.pra.model.Response;
import com.deere.epdp.pra.model.RiskCategoryData;

public interface RiskCategoryService {

	void init();

	List<RiskCategory> getAllRiskCategory();

	// String getRiskCategoryById(Integer id);

	//public List<RiskCategoryData> getAllRiskCategory(Integer progId );


	// List<ProgramRiskCateory> getProgRiskcategories(Integer id);

	Response<RiskCategoryData> saveProgRiskCategory(RiskCategoryData risk);

	// RiskCategoryData getProgRiskcategoryImpact(Integer id,Integer porgId);

	List<RiskCategoryData> getRiskCategoryImpactDesc(Integer progId);

	public  List<MitigationPlanOwner> getDistinctOwner(Integer progId);

	Response<MitigationPlanOwner> updateOwners(MitigationPlanOwner mitigation);

	Response<RiskCategoryData>  cloneRiskCategory(List<RiskCategoryData> riskCategoryData);
	
	Response<RiskCategoryData> updateCategory(List<RiskCategoryData> riskCategoryData);

}
