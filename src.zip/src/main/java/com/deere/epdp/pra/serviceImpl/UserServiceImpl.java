package com.deere.epdp.pra.serviceImpl;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.deere.epdp.pra.domain.prm.ProjectTeam;
import com.deere.epdp.pra.domain.user.User;
import com.deere.epdp.pra.domain.user.UserSolr;
import com.deere.epdp.pra.exception.SaveProjectException;
import com.deere.epdp.pra.literals.PRALiterals;
import com.deere.epdp.pra.repo.solr.SolrUserRepository;
import com.deere.epdp.pra.service.prm.ProjectService;
import com.deere.epdp.pra.service.prm.ProjectTeamService;
import com.deere.epdp.pra.service.UserService;
import com.deere.epdp.pra.utility.ActiveDirectoryUtility;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private SolrUserRepository solrUserRepository;

	@Autowired
	private ProjectTeamService projectTeamService;

	@Autowired
	private ProjectService projectService;

	private Map<String, Map<Integer, Integer>> groupsProjectIdRoleMap = new ConcurrentHashMap<>();

	@Value("${ad.group.admin}")
	private String adminGroup;

	@Value("${ad.group.support}")
	private String supportGroup;

	@Value("${spring.profiles.active}")
	private String env;

	private static final Logger LOGGER = LoggerFactory.getLogger(UserServiceImpl.class);

	@PostConstruct
	public void init() {
		projectTeamService.getProjectTeamByMemType(ProjectTeam.MemberType.G).forEach(this::groupProcess);
	}

	@Override
	public UserSolr getUserSolr(String userId) {
		return solrUserRepository.findTopByUserIdAndUserTypeCdIn(userId, Arrays.asList(1, 2, 4, 9));
	}

	@Override
	public List<UserSolr> searchUser(String value) {
		if (!value.contains(" "))
			return solrUserRepository.searchByUserIdFirstNameLastName(value, new PageRequest(0, 5)).getContent();
		else {
			value = value.trim();
			Integer lastIndex = value.lastIndexOf(' ');
			return lastIndex == -1 ? solrUserRepository.searchByFirstNameLastName(value, new PageRequest(0, 5)).getContent()
					: solrUserRepository.searchByFirstNameLastName(value.replace(" ", "\\ "), value.substring(0, lastIndex).replace(" ", "\\ "), value.substring(lastIndex + 1), new PageRequest(0, 5)).getContent();
		}
	}
	
	@Override
	public List<UserSolr> allUser(List<String> ids) {
		return !ids.isEmpty() ? solrUserRepository.findByUserIdInAndUserTypeCdIn(ids, Arrays.asList(1, 2, 4, 9)) : Collections.emptyList();
	}

	@Override
	public User getUserDetails(String userId) {
		UserSolr userSolr = solrUserRepository.findOne(userId);
		try {
		if (userSolr != null) {
			User user = userSolr.map(u -> new User(u.getUserId(), u.getFullName(), u.getUserType(), u.getEmail()));
			user.setGroups(ActiveDirectoryUtility.getGroupmembership(userId));
			user.setAdmin(user.getGroups().contains(adminGroup) || PRALiterals.PROD_ADMIN.contains(userId) || (!"Prod".equals(env) && PRALiterals.NON_PROD_ADMIN.contains(userId)));
			user.setItSupport(user.getGroups().contains(supportGroup));
			user.setAppAccess(PRALiterals.APP_ALLOW_USER_TYPE.contains(user.getUserType()));
			user.setCreateAccess(PRALiterals.CREATE_ALLOW_USER_TYPE.contains(user.getUserType()));
			return user;
		}
			throw new Exception("Error fetching user for userId " + userId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Map<Integer, Integer> getProjAccessMap(User user) {
		final Map<Integer, Integer> progAccessMap = projectTeamService.getProjectTeamByMemId(user.getUserId()).stream().collect(Collectors.toMap(p -> p.getId().getProjId(), ProjectTeam::getRoleId));
		progAccessMap.putAll(projectService.getAllProjectIdsByOwner(user.getUserId()).stream().collect(Collectors.toMap(Function.identity(), p -> 1)));	
		user.getGroups().stream().map(g -> groupsProjectIdRoleMap.get(g)).filter(Objects::nonNull).forEach(m ->
			m.forEach((id, r) -> {
				Integer role = progAccessMap.get(id);
				if(role == null || r < role)
					progAccessMap.put(id, r);
			})
		);
		return progAccessMap;
	}

	@Override
	public boolean isValidUser(String userId) {
		return solrUserRepository.countByUserIdAndUserTypeCdIn(userId, Arrays.asList(1, 2, 4, 9)) > 0;
	}

	@Override
	public String findUserName(String userId) {
		UserSolr userSolr = solrUserRepository.findTopByUserIdAndUserTypeCdIn(userId, Arrays.asList(1, 2, 4, 9));
		return userSolr != null ? userSolr.getFullName() : "User Removed";
	}

	private void groupProcess(ProjectTeam p) {
		Map<Integer, Integer> projectIdRoleMap = groupsProjectIdRoleMap.get(p.getId().getMemberId());
		if(projectIdRoleMap == null){
			projectIdRoleMap = new HashMap<>();
			groupsProjectIdRoleMap.put(p.getId().getMemberId(), projectIdRoleMap);
		}
		projectIdRoleMap.put(p.getId().getProjId(), p.getRoleId());
	}
	

	@Override
	public void addUserAndRole(ProjectTeam p) {
		try {
			if (p.getMemberType() == ProjectTeam.MemberType.G) {
				groupProcess(p);
			}
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			throw new SaveProjectException("Not able to add group members.");
		}
	}

	@Override
	public void updateUserAndRole(ProjectTeam p) {
		try {
			Map<Integer, Integer> projectIdRoleMap = groupsProjectIdRoleMap.get(p.getId().getMemberId());
			if(projectIdRoleMap != null)
				projectIdRoleMap.put(p.getId().getProjId(), p.getRoleId());
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			throw new SaveProjectException("Not able to update group member acess.");
		}
	}

	@Override
	public void removeUserAndRole(ProjectTeam p) {
		try {
			Map<Integer, Integer> projectIdRoleMap = groupsProjectIdRoleMap.get(p.getId().getMemberId());
			if(projectIdRoleMap != null)
				projectIdRoleMap.remove(p.getId().getProjId());
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			throw new SaveProjectException("Not able to delete group member acess.");
		}
	}
}
