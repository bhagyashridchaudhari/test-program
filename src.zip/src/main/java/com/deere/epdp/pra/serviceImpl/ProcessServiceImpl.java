package com.deere.epdp.pra.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deere.epdp.pra.domain.epdp.ProjectProcess;
import com.deere.epdp.pra.repo.epdp.ProcessRepository;
import com.deere.epdp.pra.service.ProcessService;

@Service
public class ProcessServiceImpl implements ProcessService {

	@Autowired
	private ProcessRepository processRepository;

	private Map<Integer, ProjectProcess> processMap;

	@PostConstruct
	public void init() {
		processMap = StreamSupport.stream(processRepository.findAll().spliterator(), false)
				.collect(Collectors.toMap(ProjectProcess::getProcessId, Function.identity()));
	}

	@Override
	public List<ProjectProcess> getAllProcess() {
		return new ArrayList<>(processMap.values());
	}

	@Override
	public ProjectProcess getProcessById(Integer id) {
		return processMap.get(id);
	}

}