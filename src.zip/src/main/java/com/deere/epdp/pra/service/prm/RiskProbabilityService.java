package com.deere.epdp.pra.service.prm;

import java.util.List;

import com.deere.epdp.pra.domain.prm.RiskProbability;

public interface RiskProbabilityService {
	
	void init();

	List<RiskProbability> getAllRiskProbability();

	String getRiskProbabilityById(Integer id);
}
