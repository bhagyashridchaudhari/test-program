package com.deere.epdp.pra.model;

import java.sql.Timestamp;

import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class RiskMitigation {
	
	private Integer riskId;
	
	private String title;
	
	private String dscCause;
	
	private String dscEffect;
	
	private Integer prgmId;

	private Integer rskCtgryId;
	
	private Integer prbltyId;
	
	private Integer impactId;
	
	private Integer rsStrtrgyId;
	
	private String lastUpdtBy;
	
	private Timestamp lastUpdtTs;
	
	private String createdBy;

	private Timestamp createdTs;
	
	private Integer rskLevel;
	
	private Integer rskScore;
	
	private String comment;
	
	private Mitigation mitigation;
	
	private Integer categorySource;

    MultipartFile selectedFile1;
 
    MultipartFile selectedFile2;

	
	public MultipartFile getSelectedFile1() {
		return selectedFile1;
	}

	public void setSelectedFile1(MultipartFile selectedFile1) {
		this.selectedFile1 = selectedFile1;
	}

	public MultipartFile getSelectedFile2() {
		return selectedFile2;
	}

	public void setSelectedFile2(MultipartFile selectedFile2) {
		this.selectedFile2 = selectedFile2;
	}

	public Integer getRiskId() {
		return riskId;
	}

	public void setRiskId(Integer riskId) {
		this.riskId = riskId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDscCause() {
		return dscCause;
	}

	public void setDscCause(String dscCause) {
		this.dscCause = dscCause;
	}

	public String getDscEffect() {
		return dscEffect;
	}

	public void setDscEffect(String dscEffect) {
		this.dscEffect = dscEffect;
	}

	public Integer getPrgmId() {
		return prgmId;
	}

	public void setPrgmId(Integer prgmId) {
		this.prgmId = prgmId;
	}

	public Integer getRskCtgryId() {
		return rskCtgryId;
	}

	public void setRskCtgryId(Integer rskCtgryId) {
		this.rskCtgryId = rskCtgryId;
	}

	public Integer getPrbltyId() {
		return prbltyId;
	}

	public void setPrbltyId(Integer prbltyId) {
		this.prbltyId = prbltyId;
	}

	public Integer getImpactId() {
		return impactId;
	}

	public void setImpactId(Integer impactId) {
		this.impactId = impactId;
	}

	public Integer getRsStrtrgyId() {
		return rsStrtrgyId;
	}

	public void setRsStrtrgyId(Integer rsStrtrgyId) {
		this.rsStrtrgyId = rsStrtrgyId;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public void setLastUpdtBy(String lastUpdtBy) {
		this.lastUpdtBy = lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}

	public void setLastUpdtTs(Timestamp lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedTs() {
		return createdTs;
	}

	public void setCreatedTs(Timestamp createdTs) {
		this.createdTs = createdTs;
	}

	public Integer getRskLevel() {
		return rskLevel;
	}

	public void setRskLevel(Integer rskLevel) {
		this.rskLevel = rskLevel;
	}

	public Integer getRskScore() {
		return rskScore;
	}

	public void setRskScore(Integer rskScore) {
		this.rskScore = rskScore;
	}

	public Mitigation getMitigation() {
		return mitigation;
	}

	public void setMitigation(Mitigation mitigation) {
		this.mitigation = mitigation;
	}
	
	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}
	
	

	public Integer getCategorySource() {
		return categorySource;
	}

	public void setCategorySource(Integer categorySource) {
		this.categorySource = categorySource;
	}

	public RiskMitigation() {
		super();
	}

	public RiskMitigation(Integer riskId, String title, String dscCause,String dscEffect,  Integer prgmId, Integer rskCtgryId,
			Integer prbltyId, Integer impactId, Integer rsStrtrgyId, String lastUpdtBy, Timestamp lastUpdtTs,
			String createdBy, Timestamp createdTs, Integer rskLevel, Integer rskScore,String comment, Mitigation mitigation,Integer categorySource) {
		super();
		this.riskId = riskId;
		this.title = title;
		this.dscCause = dscCause;
		this.dscEffect = dscEffect;
		this.prgmId = prgmId;
		this.rskCtgryId = rskCtgryId;
		this.prbltyId = prbltyId;
		this.impactId = impactId;
		this.rsStrtrgyId = rsStrtrgyId;
		this.lastUpdtBy = lastUpdtBy;
		this.lastUpdtTs = lastUpdtTs;
		this.createdBy = createdBy;
		this.createdTs = createdTs;
		this.rskLevel = rskLevel;
		this.rskScore = rskScore;
		this.comment = comment;
		this.mitigation = mitigation;
		this.categorySource=categorySource;
	}	
	
}
