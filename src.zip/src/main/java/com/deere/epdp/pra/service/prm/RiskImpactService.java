package com.deere.epdp.pra.service.prm;

import java.util.List;

import com.deere.epdp.pra.domain.prm.RiskImpact;

public interface RiskImpactService {
	
	void init();

	List<RiskImpact> getAllRiskImpact();

	Integer getRiskImpactById(Integer id);

}
