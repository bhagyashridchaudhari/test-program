package com.deere.epdp.pra.service;

import com.deere.epdp.pra.domain.prm.Project;
import com.deere.epdp.pra.model.CommonData;
import com.deere.epdp.pra.model.Response;

public interface CommonService  {
	
	CommonData getCommonData();

	CommonData reloadCommonData();
	Response<Project> saveProject(Project project);
	Response<Project> deleteProject(Integer id);

}
