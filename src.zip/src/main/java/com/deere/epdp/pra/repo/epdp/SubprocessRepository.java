package com.deere.epdp.pra.repo.epdp;

import org.springframework.data.repository.CrudRepository;

import com.deere.epdp.pra.domain.epdp.SubProcess;

public interface SubprocessRepository extends CrudRepository<SubProcess, Integer> {
	
	
}
