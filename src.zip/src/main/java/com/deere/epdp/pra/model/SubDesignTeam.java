package com.deere.epdp.pra.model;

import java.sql.Timestamp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SubDesignTeam {

	private Integer id;
	
	private String name;
	
	private Integer prgmId;
	
	private Character type;
	
	private String lastUpdtBy;
	
	private Timestamp lastUpdtTs;
	
//	@JsonIgnoreProperties(ignoreUnknown = true)
//	private boolean isDisplayEdit;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getPrgmId() {
		return prgmId;
	}

	public void setPrgmId(Integer prgmId) {
		this.prgmId = prgmId;
	}

	public Character getType() {
		return type;
	}

	public void setType(Character type) {
		this.type = type;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public void setLastUpdtBy(String lastUpdtBy) {
		this.lastUpdtBy = lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}

	public void setLastUpdtTs(Timestamp lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}

	public SubDesignTeam(Integer id, String name, Integer prgmId, Character type, String lastUpdtBy,
			Timestamp lastUpdtTs) {
		super();
		this.id = id;
		this.name = name;
		this.prgmId = prgmId;
		this.type = type;
		this.lastUpdtBy = lastUpdtBy;
		this.lastUpdtTs = lastUpdtTs;
	}

	public SubDesignTeam() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	
}
