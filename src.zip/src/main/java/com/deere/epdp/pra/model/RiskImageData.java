package com.deere.epdp.pra.model;

public class RiskImageData {
	
	Integer imgId;
	
	String data;

	String filename;

	public RiskImageData(Integer imgId, String data) {
		super();
		this.imgId = imgId;
		this.data = data;
	}
	
	public RiskImageData() { // default
		super();
	}

	public Integer getImgId() {
		return imgId;
	}

	public void setImgId(Integer imgId) {
		this.imgId = imgId;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}
}
