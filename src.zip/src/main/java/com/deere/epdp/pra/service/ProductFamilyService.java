package com.deere.epdp.pra.service;

import java.util.List;

import com.deere.epdp.pra.domain.epdp.ProductFamily;

public interface ProductFamilyService {
	
	void init();

	List<ProductFamily> getAllProductFamily();

	String getProductFamilyNameById(Integer id);

}
