package com.deere.epdp.pra.domain.epdp;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "project_schedule")
public class ProjectPhaseSchedule implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ProjectPhaseScheduleId id;

	@JsonIgnore
	@Column(name = "mlstn_id")
	private Integer mlstnId;

	@Column(name = "planned_start_dt")
	private Date plannedStartDt;

	@Column(name = "planned_exit_dt")
	private Date plannedExitDt;

	@Column(name = "actual_exit_dt")
	private Date actualExitDt;

	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdtBy;

	@JsonIgnore
	@Column(name = "last_updt_ts", nullable = false)
	private Timestamp lastUpdtTs;

	@Transient
	private List<ProjectMlstnSchedule> mlstns = new ArrayList<>(0);

	public ProjectPhaseScheduleId getId() {
		return id;
	}

	public void setId(ProjectPhaseScheduleId id) {
		this.id = id;
	}

	public Integer getMlstnId() {
		return mlstnId;
	}

	public void setMlstnId(Integer mlstnId) {
		this.mlstnId = mlstnId;
	}

	public Date getPlannedStartDt() {
		return plannedStartDt;
	}

	public void setPlannedStartDt(Date plannedStartDt) {
		this.plannedStartDt = plannedStartDt;
	}

	public Date getPlannedExitDt() {
		return plannedExitDt;
	}

	public void setPlannedExitDt(Date plannedExitDt) {
		this.plannedExitDt = plannedExitDt;
	}

	public Date getActualExitDt() {
		return actualExitDt;
	}

	public void setActualExitDt(Date actualExitDt) {
		this.actualExitDt = actualExitDt;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public void setLastUpdtBy(String lastUpdtBy) {
		this.lastUpdtBy = lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}

	public void setLastUpdtTs(Timestamp lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}

	public List<ProjectMlstnSchedule> getMlstns() {
		return mlstns;
	}

	public void setMlstns(List<ProjectMlstnSchedule> mlstns) {
		if (mlstns != null)
			this.mlstns = mlstns;
	}

	@Embeddable
	public static class ProjectPhaseScheduleId implements Serializable {

		private static final long serialVersionUID = 1L;

		@Column(name = "project_id")
		private Integer projectId;

		@Column(name = "phase_id")
		private Integer phaseId;

		public Integer getProjectId() {
			return projectId;
		}

		public void setProjectId(Integer projectId) {
			this.projectId = projectId;
		}

		public Integer getPhaseId() {
			return phaseId;
		}

		public void setPhaseId(Integer phaseId) {
			this.phaseId = phaseId;
		}
	}
}
