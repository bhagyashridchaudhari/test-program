package com.deere.epdp.pra.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.deere.epdp.pra.domain.user.UserSolr;
import com.deere.epdp.pra.model.Response;
import com.deere.epdp.pra.service.UserService;

@RestController
@RequestMapping("/api/users")
public class UserController {

	@Autowired
	private UserService userService;

	@GetMapping
	public List<UserSolr> getUser(@RequestParam List<String> ids) {
		return userService.allUser(ids);
	}

	@GetMapping("/search")
	public List<UserSolr> getUser(@RequestParam String value) {
		return userService.searchUser(value);
	}

	@GetMapping("/valid/{id}")
	public Response<Boolean> idValidUser(@PathVariable String id) {
		return new Response<>(userService.isValidUser(id));
	}

	@GetMapping("/name/{id}")
	public Response<String> getName(@PathVariable String id) {
		return new Response<>(userService.findUserName(id));
	}
}