package com.deere.epdp.pra.service;

import java.util.List;

import com.deere.epdp.pra.domain.epdp.ProductLine;

public interface ProductLineService {
	
	void init();

	List<ProductLine> getAllProductLine();

	String getProductLineNameById(Integer id);

}
