package com.deere.epdp.pra.domain.epdp;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "phase")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Phase implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "phase_id")
	private Integer phaseId;

	@Column(name = "phase_no", nullable = false)
	private Integer phaseNo;

	@Column(name = "phase_nm", nullable = false)
	private String phaseNm;

	@Column(name = "phase_desc", nullable = false)
	private String phaseDesc;

	@Column(name = "process_id", nullable = false)
	private Integer processId;

	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdtBy;

	@JsonIgnore
	@Column(name = "last_updt_ts", nullable = false)
	private Timestamp lastUpdtTs;

	public Integer getPhaseId() {
		return phaseId;
	}

	public Integer getPhaseNo() {
		return phaseNo;
	}

	public String getPhaseNm() {
		return phaseNm;
	}

	public String getPhaseDesc() {
		return phaseDesc;
	}

	public Integer getProcessId() {
		return processId;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}
}
