package com.deere.epdp.pra.serviceImpl.prm;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deere.epdp.pra.domain.prm.RiskCategoryImpact;
import com.deere.epdp.pra.repo.prm.RiskCategoryImpactRepository;
import com.deere.epdp.pra.service.prm.RiskCategoryImpactService;

@Service
public class RiskCategoryImpactServiceImpl implements RiskCategoryImpactService {
	
	@Autowired
	private RiskCategoryImpactRepository riskCtgryImpactRepository;
	
	private List<RiskCategoryImpact> riskCtgryImpact;
	
	@PostConstruct
	public void init() {
		riskCtgryImpact = StreamSupport.stream(riskCtgryImpactRepository.findAll().spliterator(), false)
				.collect(Collectors.toList());
	}
	
	@Override
	public List<RiskCategoryImpact> getAllRiskCategoryImpact(){
		return riskCtgryImpact.stream().sorted(Comparator.comparing(i -> i.getId().getImpactId())).collect(Collectors.toList());
	}

	@Override
	public List<RiskCategoryImpact> findImpactByCategory(Integer id) {
	return 	riskCtgryImpactRepository.findImpactByCategory(id);
	}


	
}
