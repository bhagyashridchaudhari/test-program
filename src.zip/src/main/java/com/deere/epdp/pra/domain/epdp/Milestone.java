package com.deere.epdp.pra.domain.epdp;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "milestone")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Milestone implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "mlstn_id")
	private Integer mlstnId;

	@Column(name = "mlstn_no", nullable = false)
	private Integer mlstnNo;

	@Column(name = "mlstn_nm", nullable = false)
	private String mlstnNm;

	@Column(name = "mlstn_desc", nullable = false)
	private String mlstnDesc;

	@Column(name = "phase_id", nullable = false)
	private Integer phaseId;

	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdtBy;

	@JsonIgnore
	@Column(name = "last_updt_ts", nullable = false)
	private Timestamp lastUpdtTs;

	public Integer getMlstnId() {
		return mlstnId;
	}

	public Integer getMlstnNo() {
		return mlstnNo;
	}

	public String getMlstnNm() {
		return mlstnNm;
	}

	public String getMlstnDesc() {
		return mlstnDesc;
	}

	public Integer getPhaseId() {
		return phaseId;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}
}
