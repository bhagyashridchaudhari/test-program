package com.deere.epdp.pra.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;
import org.springframework.security.oauth2.provider.token.store.jwk.JwkTokenStore;

@Configuration
@EnableResourceServer
@Order(SecurityProperties.ACCESS_OVERRIDE_ORDER-1)
public class ResourceServerConfig extends ResourceServerConfigurerAdapter {
	
	@Value("${security.oauth2.okta.enable:false}")
	private boolean okatEnable;
	
	@Value("${jwk.key-set-uri}")
	private String jwkKeySet;		
	
	@Value("${authorization-server-id}")
	private String authServerId;
	
	@Override
	public void configure(ResourceServerSecurityConfigurer resources) throws Exception {
		JwkTokenStore tokenStore = new JwkTokenStore(jwkKeySet);
		DefaultTokenServices defaultTokenServices = new DefaultTokenServices();
		defaultTokenServices.setTokenStore(tokenStore);
		resources.resourceId(authServerId);
		resources.tokenServices(defaultTokenServices);
		resources.tokenStore(tokenStore);
	}

	@Override
	public void configure(HttpSecurity http) throws Exception {
		if(okatEnable)
			http.antMatcher("/web/api/comseg/**").authorizeRequests().anyRequest().authenticated();
		else
			http.antMatcher("/web/api/comseg/**").authorizeRequests().anyRequest().permitAll();
	}
}