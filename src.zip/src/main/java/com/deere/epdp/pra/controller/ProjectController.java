package com.deere.epdp.pra.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deere.epdp.pra.domain.prm.Project;
import com.deere.epdp.pra.model.Response;
import com.deere.epdp.pra.model.Response.RespMessage;
import com.deere.epdp.pra.model.Response.RespMessage.Type;
import com.deere.epdp.pra.model.Response.Status;
import com.deere.epdp.pra.service.CommonService;
import com.deere.epdp.pra.service.prm.ProjectService;
import com.deere.epdp.pra.utility.CommonUtility;

@RestController
@RequestMapping(value = { "/api/projects", "/api/comseg/projects" })
public class ProjectController {

	@Autowired
	private ProjectService projectService;

	@Autowired
	private CommonService commonService;

	
	@GetMapping
	public List<Project> getProjects() {
		return projectService.getAllProjects();
	}

	@PostMapping
	public Response<Project> saveProject(@RequestBody Project project) {
		return commonService.saveProject(project);
	}

	@PutMapping("/transfer")
	public Response<Project> transferProject(@RequestBody List<Project> projects) {
		List<RespMessage> errors = new ArrayList<>();
		projectService.transferProjects(projects);
		return new Response<>(Status.SUCCESS, errors.isEmpty() ? null : errors);
	}

	@PutMapping("/status")
	public Response<Project> updateProjectStatus(@RequestBody List<Project> projects) {
		List<RespMessage> errors = new ArrayList<>();
		projectService.updateProjectStatus(projects);
		return new Response<>(Status.SUCCESS, errors.isEmpty() ? null : errors);
	}	

	@DeleteMapping("/{id}")
	public Response<Project> deleteProject(@PathVariable Integer id) {
		return commonService.deleteProject(id);
	}

	@GetMapping("/{id}")
	public Project getProject(@PathVariable Integer id) {
		return projectService.getProjectById(id);
	}
	
	@GetMapping("/search")
	public List<Project> searchProjects(Project project) {
		return projectService.searchProjects(project);
	}

	@GetMapping("/sort-detail/{id}")
	public Project sortProjectDetail(@PathVariable Integer id) {
		return projectService.sortProjectDetail(id);
	}
	
	
	@PutMapping("/updatedate/{prjId}")
	public Response updateProjLastModDate(@PathVariable Integer prjId) {
		projectService.updateProjLastModDate(prjId,CommonUtility.getCurrentTime());
		return new Response<>(Status.SUCCESS, Arrays.asList(new RespMessage("Last updated date modified successfully.", Type.SUCCESS)));
	}
	
}
