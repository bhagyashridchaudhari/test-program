package com.deere.epdp.pra.domain.epdp;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "build_dates")
public class BuildDate implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "date_id")
	private Integer dateId;

	@Column(name = "date_name", length = 60, nullable = false)
	private String dateName;

	@Column(name = "date_desc", length = 500)
	private String dateDesc;

	@Column(name = "is_optional", length = 1)
	@ColumnDefault("'N'")
	private String isOptional;

	@JsonIgnore
	@Column(name = "created_by", length = 7, nullable = false)
	private String createdBy;

	@JsonIgnore
	@Column(name = "created_ts", nullable = false)
	private Timestamp createdTs;

	@JsonIgnore
	@Column(name = "last_updt_by", length = 7, nullable = false)
	private String lastUpdtBy;

	@JsonIgnore
	@Column(name = "last_updt_ts", nullable = false)
	private Timestamp lastUpdtTs;

	public Integer getDateId() {
		return dateId;
	}

	public String getDateName() {
		return dateName;
	}

	public String getDateDesc() {
		return dateDesc;
	}

	public String getIsOptional() {
		return isOptional;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public Timestamp getCreatedTs() {
		return createdTs;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}
}
