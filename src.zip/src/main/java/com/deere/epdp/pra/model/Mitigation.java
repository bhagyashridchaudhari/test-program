package com.deere.epdp.pra.model;

import java.sql.Timestamp;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Mitigation {
	
	private Integer mtgtnId;

	private String mtgtnTitle;

	private String mtgtnDesc;
	
	private Date trgtClosure;

	private Date nxtReview;
	
	private String mtgtnOwner;

	private Integer mtgtnSubFunction;
	
	private Integer mtgtnSubTeamId;
	
	private Integer mtgtnDesignTeamId;
	
	private Integer mtgtnStatusId;
	
	private Integer  mtgtnPrbltyId;
	
	private Integer mtgtnImpactId;
	
	private String mtgtnLastUpdtBy;

	private Timestamp mtgtnLastUpdtTs;
	
	private Integer mtgtnScore;
	
	private Integer mtgtnLevel;
	


	public Integer getMtgtnId() {
		return mtgtnId;
	}

	public void setMtgtnId(Integer mtgtnId) {
		this.mtgtnId = mtgtnId;
	}

	public String getMtgtnTitle() {
		return mtgtnTitle;
	}

	public void setMtgtnTitle(String mtgtnTitle) {
		this.mtgtnTitle = mtgtnTitle;
	}

	public String getMtgtnDesc() {
		return mtgtnDesc;
	}

	public void setMtgtnDesc(String mtgtnDesc) {
		this.mtgtnDesc = mtgtnDesc;
	}

	public Date getTrgtClosure() {
		return trgtClosure;
	}

	public void setTrgtClosure(Date trgtClosure) {
		this.trgtClosure = trgtClosure;
	}

	public Date getNxtReview() {
		return nxtReview;
	}

	public void setNxtReview(Date nxtReview) {
		this.nxtReview = nxtReview;
	}

	public String getMtgtnOwner() {
		return mtgtnOwner;
	}

	public void setMtgtnOwner(String mtgtnOwner) {
		this.mtgtnOwner = mtgtnOwner;
	}

	public Integer getMtgtnSubFunction() {
		return mtgtnSubFunction;
	}

	public void setMtgtnSubFunction(Integer mtgtnSubFunction) {
		this.mtgtnSubFunction = mtgtnSubFunction;
	}

	public Integer getMtgtnSubTeamId() {
		return mtgtnSubTeamId;
	}

	public void setMtgtnSubTeamId(Integer mtgtnSubTeamId) {
		this.mtgtnSubTeamId = mtgtnSubTeamId;
	}

	public Integer getMtgtnDesignTeamId() {
		return mtgtnDesignTeamId;
	}

	public void setMtgtnDesignTeamId(Integer mtgtnDesignTeamId) {
		this.mtgtnDesignTeamId = mtgtnDesignTeamId;
	}

	public Integer getMtgtnStatusId() {
		return mtgtnStatusId;
	}

	public void setMtgtnStatusId(Integer mtgtnStatusId) {
		this.mtgtnStatusId = mtgtnStatusId;
	}

	public Integer getMtgtnPrbltyId() {
		return mtgtnPrbltyId;
	}

	public void setMtgtnPrbltyId(Integer mtgtnPrbltyId) {
		this.mtgtnPrbltyId = mtgtnPrbltyId;
	}

	public Integer getMtgtnImpactId() {
		return mtgtnImpactId;
	}

	public void setMtgtnImpactId(Integer mtgtnImpactId) {
		this.mtgtnImpactId = mtgtnImpactId;
	}

	public String getMtgtnLastUpdtBy() {
		return mtgtnLastUpdtBy;
	}

	public void setMtgtnLastUpdtBy(String mtgtnLastUpdtBy) {
		this.mtgtnLastUpdtBy = mtgtnLastUpdtBy;
	}

	public Timestamp getMtgtnLastUpdtTs() {
		return mtgtnLastUpdtTs;
	}

	public void setMtgtnLastUpdtTs(Timestamp mtgtnLastUpdtTs) {
		this.mtgtnLastUpdtTs = mtgtnLastUpdtTs;
	}
	
	public Integer getMtgtnScore() {
		return mtgtnScore;
	}

	public void setMtgtnScore(Integer mtgtnScore) {
		this.mtgtnScore = mtgtnScore;
	}

	public Integer getMtgtnLevel() {
		return mtgtnLevel;
	}

	public void setMtgtnLevel(Integer mtgtnLevel) {
		this.mtgtnLevel = mtgtnLevel;
	}


	public Mitigation(Integer mtgtnId, String mtgtnTitle, Date trgtClosure, Date nxtReview,
			String mtgtnOwner, Integer mtgtnSubFunction, Integer mtgtnSubTeamId, Integer mtgtnDesignTeamId,
			Integer mtgtnStatusId, Integer mtgtnPrbltyId, Integer mtgtnImpactId, String mtgtnLastUpdtBy,
			Timestamp mtgtnLastUpdtTs, Integer mtgtnLevel, Integer mtgtnScore ) {
		super();
		this.mtgtnId = mtgtnId;
		this.mtgtnTitle = mtgtnTitle;
		this.trgtClosure = trgtClosure;
		this.nxtReview = nxtReview;
		this.mtgtnOwner = mtgtnOwner;
		this.mtgtnSubFunction = mtgtnSubFunction;
		this.mtgtnSubTeamId = mtgtnSubTeamId;
		this.mtgtnDesignTeamId = mtgtnDesignTeamId;
		this.mtgtnStatusId = mtgtnStatusId;
		this.mtgtnPrbltyId = mtgtnPrbltyId;
		this.mtgtnImpactId = mtgtnImpactId;
		this.mtgtnLastUpdtBy = mtgtnLastUpdtBy;
		this.mtgtnLastUpdtTs = mtgtnLastUpdtTs;
		this.mtgtnLevel = mtgtnLevel;
		this.mtgtnScore = mtgtnScore;
	}

	public Mitigation() {
		super();
	}
	
	

}
