package com.deere.epdp.pra.serviceImpl;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deere.epdp.pra.domain.epdp.SegementHierarchy;
import com.deere.epdp.pra.repo.epdp.SegementHierarchyRepository;
import com.deere.epdp.pra.service.SegementHierarchyService;

@Service
public class SegementHierarchyServiceImpl implements SegementHierarchyService {

	@Autowired
	private SegementHierarchyRepository segementHierarchyRepository;

	private List<SegementHierarchy> segementHierarchyMap;

	@PostConstruct
	public void init() {
		segementHierarchyMap = StreamSupport.stream(segementHierarchyRepository.findAll().spliterator(), false)
				.collect(Collectors.toList());
	}
	
	@Override
	public List<SegementHierarchy> getAllSegementHierarchy(){
		return segementHierarchyMap;
	}
}
