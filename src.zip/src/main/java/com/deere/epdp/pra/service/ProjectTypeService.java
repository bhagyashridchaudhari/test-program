package com.deere.epdp.pra.service;

import java.util.List;

import com.deere.epdp.pra.domain.epdp.ProjectType;

public interface ProjectTypeService {
	
	void init();

	List<ProjectType> getAllProjectType();

	String getProjectTypeNameById(Integer id);

}
