package com.deere.epdp.pra.exception;

/**
 * Controller advice exception handler to handle exceptions occurs during any operation
 * 
 * @author RM43492
 * @version 1.0
 * @since 2017-11-01
 */
import java.sql.SQLException;
import java.util.List;

import javax.persistence.PersistenceException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
class GlobalExceptionHandler {

	private static final Logger LOGGER = LoggerFactory.getLogger(GlobalExceptionHandler.class);

	/**
	 * @param ex
	 *            is a exception object occurs when an attempt to insert or update data results in violation of an integrity constraint.
	 * @return spring ResponseEntity object with error message
	 * @see DataIntegrityViolationException
	 * @see ResponseEntity
	 */
	@ExceptionHandler(DataIntegrityViolationException.class)
	public ResponseEntity<String> conflict(Exception ex) {
		LOGGER.error(ex.getMessage(), ex);
		return new ResponseEntity<>("Data integrity violation. Please contact support.", HttpStatus.CONFLICT);
	}

	/**
	 * @param ex
	 *            is a exception object occurs during database operation
	 * @return spring ResponseEntity object with error message
	 * @see SQLException
	 * @see DataAccessException
	 * @see PersistenceException
	 * @see ResponseEntity
	 */
	@ExceptionHandler({ SQLException.class, DataAccessException.class, PersistenceException.class })
	public ResponseEntity<String> databaseError(Exception ex) {
		LOGGER.error(ex.getMessage(), ex);
		return new ResponseEntity<>("Data access error. Please contact support.", HttpStatus.BAD_REQUEST);
	}

	/**
	 * @param ex
	 *            is a exception object occurs during import a project from other environment
	 * @return spring ResponseEntity object with error message
	 * @see ImportProjectException
	 * @see ResponseEntity
	 */
	@ExceptionHandler({ ImportProjectException.class })
	public ResponseEntity<List<String>> handleDuplicateMemberException(ImportProjectException ex) {
		return new ResponseEntity<>(ex.getErrors(), HttpStatus.UNPROCESSABLE_ENTITY);
	}

	/**
	 * @param ex
	 *            is a exception object occurs during any operation
	 * @return spring ResponseEntity object with error message
	 * @see AuthorizationException
	 * @see AuthenticationException
	 * @see DuplicateEntityException
	 * @see ResponseEntity
	 */
	@ExceptionHandler(value = Exception.class)
	public ResponseEntity<String> defaultErrorHandler(Exception ex) {
		HttpStatus status = HttpStatus.BAD_REQUEST;
		if (ex instanceof AuthorizationException)
			status = HttpStatus.UNAUTHORIZED;
		else if (ex instanceof AuthenticationException)
			status = HttpStatus.FORBIDDEN;
		else if (ex instanceof DuplicateEntityException)
			status = HttpStatus.CONFLICT;
		else
			LOGGER.error(ex.getMessage(), ex);
		return new ResponseEntity<>(StringUtils.isEmpty(ex.getMessage()) ? "Error processing your request. Please contact support." : ex.getMessage(), status);
	}
}