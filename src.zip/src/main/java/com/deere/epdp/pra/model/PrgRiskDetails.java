package com.deere.epdp.pra.model;

import java.util.List;


public class PrgRiskDetails {
	
	private List<RiskMitigation> riskMtgtn;
	
	private Iterable<SubDesignTeam> subTeamlist;
	
	private Iterable<SubDesignTeam> designTeamlist;
	
	private List<RiskCategoryData> riskCategoryData;

	public List<RiskMitigation> getRiskMtgtn() {
		return riskMtgtn;
	}

	public void setRiskMtgtn(List<RiskMitigation> riskMtgtn) {
		this.riskMtgtn = riskMtgtn;
	}

	public Iterable<SubDesignTeam> getSubTeamlist() {
		return subTeamlist;
	}

	public void setSubTeamlist(Iterable<SubDesignTeam> subTeamlist) {
		this.subTeamlist = subTeamlist;
	}

	public Iterable<SubDesignTeam> getDesignTeamlist() {
		return designTeamlist;
	}

	public void setDesignTeamlist(Iterable<SubDesignTeam> designTeamlist) {
		this.designTeamlist = designTeamlist;
	}

	public List<RiskCategoryData> getRiskCategoryData() {
		return riskCategoryData;
	}

	public void setRiskCategoryData(List<RiskCategoryData> riskCategoryData) {
		this.riskCategoryData = riskCategoryData;
	}

	public PrgRiskDetails(List<RiskMitigation> riskMtgtn, Iterable<SubDesignTeam> subTeamlist,
			Iterable<SubDesignTeam> designTeamlist, List<RiskCategoryData> riskCategoryData) {
		super();
		this.riskMtgtn = riskMtgtn;
		this.subTeamlist = subTeamlist;
		this.designTeamlist = designTeamlist;
		this.riskCategoryData = riskCategoryData;
	}

	public PrgRiskDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
