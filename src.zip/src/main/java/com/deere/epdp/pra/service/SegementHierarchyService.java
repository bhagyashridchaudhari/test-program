package com.deere.epdp.pra.service;

import java.util.List;

import com.deere.epdp.pra.domain.epdp.SegementHierarchy;

public interface SegementHierarchyService {
	
	void init();
	
	List<SegementHierarchy> getAllSegementHierarchy();

}
