package com.deere.epdp.pra.model;

import java.util.Date;
import java.util.List;

/**
 * This model class use for search program based on filter criteria
*/
public class ProjectFilter {
	
	private List<Integer> divIds;
	
	private List<Integer> pltfmIds;
	
	private List<Integer> prdlnIds;
	
	private List<Integer> prdfmlyIds;
	
	private List<Integer> unitIds;
	
	private List<Integer> prjStatusIds;
	
	private List<Integer> prjTypeIds;
	
	private Date startDate;
	
	private Date endDate;

	public List<Integer> getDivIds() {
		return divIds;
	}

	public void setDivIds(List<Integer> divIds) {
		this.divIds = divIds;
	}

	public List<Integer> getPltfmIds() {
		return pltfmIds;
	}

	public void setPltfmIds(List<Integer> pltfmIds) {
		this.pltfmIds = pltfmIds;
	}

	public List<Integer> getPrdlnIds() {
		return prdlnIds;
	}

	public void setPrdlnIds(List<Integer> prdlnIds) {
		this.prdlnIds = prdlnIds;
	}

	public List<Integer> getPrdfmlyIds() {
		return prdfmlyIds;
	}

	public void setPrdfmlyIds(List<Integer> prdfmlyIds) {
		this.prdfmlyIds = prdfmlyIds;
	}

	public List<Integer> getUnitIds() {
		return unitIds;
	}

	public void setUnitIds(List<Integer> unitIds) {
		this.unitIds = unitIds;
	}

	public List<Integer> getPrjStatusIds() {
		return prjStatusIds;
	}

	public void setPrjStatusIds(List<Integer> prjStatusIds) {
		this.prjStatusIds = prjStatusIds;
	}

	public List<Integer> getPrjTypeIds() {
		return prjTypeIds;
	}

	public void setPrjTypeIds(List<Integer> prjTypeIds) {
		this.prjTypeIds = prjTypeIds;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
}