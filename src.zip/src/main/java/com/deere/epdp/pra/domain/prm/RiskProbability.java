package com.deere.epdp.pra.domain.prm;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "risk_prblty")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RiskProbability implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "id")
	private Integer prbltyId;

	@Column(name = "name", nullable = false)
	private String prbltyName;

	@JsonIgnore
	@Column(name = "dsc", nullable = false)
	private String prbltyDsc;
	
	@Column(name = "prblty_typ")
	private Integer prbltyTyp;
	
	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdtBy;
	
	@JsonIgnore
	@Column(name = "last_updt_ts")
	private Timestamp lastUpdtTs;

	public Integer getPrbltyId() {
		return prbltyId;
	}

	public void setPrbltyId(Integer prbltyId) {
		this.prbltyId = prbltyId;
	}

	public String getPrbltyName() {
		return prbltyName;
	}

	public void setPrbltyName(String prbltyName) {
		this.prbltyName = prbltyName;
	}

	public String getPrbltyDsc() {
		return prbltyDsc;
	}

	public void setPrbltyDsc(String prbltyDsc) {
		this.prbltyDsc = prbltyDsc;
	}

	public Integer getPrbltyTyp() {
		return prbltyTyp;
	}

	public void setPrbltyTyp(Integer prbltyTyp) {
		this.prbltyTyp = prbltyTyp;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public void setLastUpdtBy(String lastUpdtBy) {
		this.lastUpdtBy = lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}

	public void setLastUpdtTs(Timestamp lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}

}
