package com.deere.epdp.pra.domain.prm;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "role_dm")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Role implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "role_id")
	private Integer roleId;

	@Column(name = "role_nm", nullable = false)
	private String roleNm;

	@Column(name = "role_dsc")
	private String roleDsc;

	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdtBy;

	@JsonIgnore
	@Column(name = "last_updt_ts")
	private Timestamp lastUpdtTs;

	public Integer getRoleId() {
		return roleId;
	}

	public String getRoleNm() {
		return roleNm;
	}

	public String getRoleDsc() {
		return roleDsc;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}
}