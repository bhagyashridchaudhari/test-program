package com.deere.epdp.pra.domain.prm;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.function.Function;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "prgm_team")
public class ProjectTeam implements Serializable {

	private static final long serialVersionUID = 1L;
	
	public enum MemberType { I, G; }

	@EmbeddedId
	private ProjectTeamId id;

	@Enumerated(EnumType.STRING)
	@Column(name = "member_typ", nullable = false, length = 1)
	private MemberType memberType = MemberType.I;
	
	@Column(name = "role_id")
	private Integer roleId;

	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdatedBy;

	@JsonIgnore
	@Column(name = "last_updt_ts")
	private Timestamp lastUpdatedTs;
	

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public ProjectTeam() {
		super();
	}
	
	public ProjectTeam(ProjectTeamId id, Integer roleId) {
		super();
		this.id = id;
		this.roleId = roleId;
	}

	public ProjectTeam(ProjectTeamId id, MemberType memberType) {
		super();
		this.id = id;
		this.memberType = memberType;
	}

	public ProjectTeam(ProjectTeamId id, MemberType memberType, Integer roleId, String lastUpdatedBy, Timestamp lastUpdatedTs) {
		super();
		this.id = id;
		this.memberType = memberType;
		this.roleId = roleId;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedTs = lastUpdatedTs;
	}

	public ProjectTeamId getId() {
		return id;
	}

	public void setId(ProjectTeamId id) {
		this.id = id;
	}

	public MemberType getMemberType() {
		return memberType;
	}

	public void setMemberType(MemberType memberType) {
		this.memberType = memberType;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Timestamp getLastUpdatedTs() {
		return lastUpdatedTs;
	}

	public void setLastUpdatedTs(Timestamp lastUpdatedTs) {
		this.lastUpdatedTs = lastUpdatedTs;
	}

	public <R> R map(Function<ProjectTeam, R> function) {
		return function.apply(this);
	}

	@Embeddable
	public static class ProjectTeamId implements Serializable {

		private static final long serialVersionUID = 1L;

		@Column(name = "prgm_id")
		private Integer projId;

		@Column(name = "member_id")
		private String memberId;

		public ProjectTeamId() {
			super();
		}

		public ProjectTeamId(Integer projId, String memberId) {
			super();
			this.projId = projId;
			this.memberId = memberId;
		}
		
		public Integer getProjId() {
			return projId;
		}

		public void setProjId(Integer projId) {
			this.projId = projId;
		}

		public String getMemberId() {
			return memberId;
		}

		public void setMemberId(String memberId) {
			this.memberId = memberId;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((memberId == null) ? 0 : memberId.hashCode());
			result = prime * result + ((projId == null) ? 0 : projId.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			ProjectTeamId other = (ProjectTeamId) obj;
			if (memberId == null) {
				if (other.memberId != null)
					return false;
			} else if (!memberId.equals(other.memberId))
				return false;
			if (projId == null) {
				if (other.projId != null)
					return false;
			} else if (!projId.equals(other.projId))
				return false;
			return true;
		}
	}
}