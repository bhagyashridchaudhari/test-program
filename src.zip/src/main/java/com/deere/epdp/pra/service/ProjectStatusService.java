package com.deere.epdp.pra.service;

import java.util.List;

import com.deere.epdp.pra.domain.epdp.ProjectStatus;

public interface ProjectStatusService {
	
	void init();

	List<ProjectStatus> getAllProjectStatus();

	String getProjectStatusNameById(Integer id);

}
