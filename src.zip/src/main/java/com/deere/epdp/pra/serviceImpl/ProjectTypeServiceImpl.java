package com.deere.epdp.pra.serviceImpl;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deere.epdp.pra.domain.epdp.ProjectType;
import com.deere.epdp.pra.repo.epdp.ProjectTypeRepository;
import com.deere.epdp.pra.service.ProjectTypeService;

@Service
public class ProjectTypeServiceImpl implements ProjectTypeService {

	@Autowired
	private ProjectTypeRepository projectTypeRepository;

	private Map<Integer, ProjectType> projectTypeMap;

	@PostConstruct
	public void init() {
		projectTypeMap = StreamSupport.stream(projectTypeRepository.findAll().spliterator(), false)
				.collect(Collectors.toMap(ProjectType::getTypeId, Function.identity()));
	}

	@Override
	public List<ProjectType> getAllProjectType() {
		return projectTypeMap.values().stream().sorted(Comparator.comparing(ProjectType::getTypeName)).collect(Collectors.toList());
	}

	@Override
	public String getProjectTypeNameById(Integer id) {
		ProjectType type = projectTypeMap.get(id);
		return type != null ? type.getTypeName() : null;
	}

}
