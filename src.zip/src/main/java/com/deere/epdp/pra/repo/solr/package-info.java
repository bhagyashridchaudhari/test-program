/**
 * 
 */
/**
 * @author bc04761
 *
 */
package com.deere.epdp.pra.repo.solr;