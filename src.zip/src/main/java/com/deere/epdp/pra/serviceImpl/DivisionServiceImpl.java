package com.deere.epdp.pra.serviceImpl;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deere.epdp.pra.domain.epdp.Division;
import com.deere.epdp.pra.repo.epdp.DivisionRepository;
import com.deere.epdp.pra.service.DivisionService;

@Service
public class DivisionServiceImpl implements DivisionService {

	@Autowired
	private DivisionRepository divisionRepository;

	private Map<Integer, Division> divisionMap;

	@PostConstruct
	public void init() {
		divisionMap = StreamSupport.stream(divisionRepository.findAll().spliterator(), false)
				.collect(Collectors.toMap(Division::getDivId, Function.identity()));
	}

	@Override
	public List<Division> getAllDivision() {
		return divisionMap.values().stream().sorted(Comparator.comparing(Division::getDivNm)).collect(Collectors.toList());
	}

	@Override
	public String getDivisionNameById(Integer id) {
		Division div = divisionMap.get(id);
		return div != null ? div.getDivNm() : null;
	}

}
