package com.deere.epdp.pra.repo.prm;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.deere.epdp.pra.domain.prm.MitigationPlan;

public interface MitigationPlanRepository extends CrudRepository<MitigationPlan, Integer>{
	
	@Query("Select DISTINCT  mp.mtgtnOwner  from MitigationPlan mp INNER JOIN mp.risk r  where  r.prgmId=?1")
	List<String> getDistinctOwner(Integer programId);
	
	
	@Modifying
    @Query("update MitigationPlan mp  set mp.mtgtnOwner = ?1 where  mp.mtgtnOwner = ?2  and  mp.risk.riskId in ( select mp.risk.riskId from mp.risk where  mp.risk.prgmId = ?3)")
	void update(String futureOwner,String currentOwner,Integer prgId);	
	
	

    @Modifying
    @Query("delete from MitigationPlan mp where mp.risk.riskId in ( select r.riskId from ProjectRisk  r  where r.prgmId=?1)")
    public void deleteMgtnPlanByPrjId(Integer prjId);
    
    
    
 
}
