package com.deere.epdp.pra.utility;

import org.jasypt.util.text.BasicTextEncryptor;

/**
 * @author RM43492
 *
 */
public final class JasyptEncriptionUtility {
	
	private static JasyptEncriptionUtility jasyptEncriptionUtility;

	private BasicTextEncryptor textEncryptor;
	
	private boolean setPassword = false;
	
	private JasyptEncriptionUtility(BasicTextEncryptor textEncryptor){
		this.textEncryptor = textEncryptor;
	}
	
	public static JasyptEncriptionUtility getInstance(){
		if(jasyptEncriptionUtility == null)
			jasyptEncriptionUtility = new JasyptEncriptionUtility(new BasicTextEncryptor());
		return jasyptEncriptionUtility;
	}
	
	public JasyptEncriptionUtility init(String key) throws JasyptEncriptionUtilityException{
		if(setPassword)
			throw new JasyptEncriptionUtilityException("You already have initalized");
		textEncryptor.setPassword(key);
		setPassword = true;
		return jasyptEncriptionUtility;
	}
	
	public String encode(String toEncode){
		return textEncryptor.encrypt(toEncode);
	}
	
	public String decode(String toDecode){
		return textEncryptor.decrypt(toDecode);
	}
	
	public static class JasyptEncriptionUtilityException extends Exception {
		
		private static final long serialVersionUID = -6004496353885728687L;

		public JasyptEncriptionUtilityException(String message, Throwable cause) {
			super(message, cause);
		}

		public JasyptEncriptionUtilityException(String message) {
			super(message);
		}

		public JasyptEncriptionUtilityException(Throwable cause) {
			super(cause);
		}
	}

	/**public static void main(String[] args) throws JasyptEncriptionUtilityException {
		
		String encoded = JasyptEncriptionUtility.getInstance().init("xyz").decode("VibtJRrtbV1xwsK0KMXpJaYfwVdppLzn");
		
		System.out.println(encoded);
	}*/
}