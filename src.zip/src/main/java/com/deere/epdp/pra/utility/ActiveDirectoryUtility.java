package com.deere.epdp.pra.utility;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Hashtable;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.ReferralException;
import javax.naming.directory.Attribute;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.deere.epdp.pra.exception.AuthenticationException;

// import com.deere.epdp.pra.exception.AuthenticationException;
// import com.deere.epdp.pra.utility.JasyptEncriptionUtility.JasyptEncriptionUtilityException;

public final class ActiveDirectoryUtility {

	private static final Logger LOGGER = LoggerFactory.getLogger(ActiveDirectoryUtility.class);

	private static final List<String> GROUP_LIST = Arrays.asList("Public Distribution Lists", "Distribution", "Security", "ServersGS3", "UnixLinux", "JDCORP", "PDLs", "JDGroups");

	private static final String SEARCH_BASE = "dc=jdnet,dc=deere,dc=com";
	
	private static final String SEARCH_BASE_SECURITY = "dc=jdnet,dc=deere,dc=com";

	private static final Hashtable<String, String> ENVIRONMENT;

	private ActiveDirectoryUtility() {
		super();
	}

	static {
		String passowrd;
		try {
			passowrd = JasyptEncriptionUtility.getInstance().init("xyz").decode("ia5KYNtKtTBfF2cpRcnhg2kfw3xC6C+4");
		} catch (Exception e1) {
			throw new AuthenticationException("Unable to decript password.");
		}
		ENVIRONMENT = new Hashtable<>();
		ENVIRONMENT.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		ENVIRONMENT.put(Context.PROVIDER_URL, "ldap://jdnet.deere.com:389");
		ENVIRONMENT.put(Context.SECURITY_AUTHENTICATION, "simple");
		ENVIRONMENT.put(Context.SECURITY_PRINCIPAL, "APU6563@jdnet.deere.com");
		ENVIRONMENT.put(Context.SECURITY_CREDENTIALS, passowrd);
		ENVIRONMENT.put(Context.REFERRAL, "throw");
	}

	/**
	 * This utility method returns the connection object of John Deere Active Directory. To connect to AD this method pick User Name and Password from SecureVision.Properties file.
	 * 
	 * @return DirContext. returns the directory context object of AD connection.
	 * @throws NamingException 
	 */
	private static DirContext getADConnection() throws NamingException {
		try {
			return new InitialDirContext(ENVIRONMENT);
		} catch (NamingException e) {
			LOGGER.error("Error creating Active Directory Context.", e);
			throw e;
		}
	}

	/**
	 * @param userId is the Active Directory userId
	 * @return List of all group names user part of
	 */
	public static List<String> getGroupmembership(String userId) {
		List<String> membership = new ArrayList<>();
		DirContext context = null;
		try {
			context = getADConnection();
			NamingEnumeration<SearchResult> answer = context.search(SEARCH_BASE, "(sAMAccountName=" + userId + ")", searchControls("memberOf"));

			while (answer.hasMore()) {
				NamingEnumeration<?> array = answer.next().getAttributes().get("memberOf").getAll();
				while (array.hasMore())
					membership.add(getNameWithType(array.next().toString()).getValue0().toUpperCase());
			}
		} catch (ReferralException e) {
			e.skipReferral();
		} catch (NamingException e) {
			LOGGER.error("There has been an error trying to determin a group membership for AD user : " + userId, e);
		} finally {
			try {
				if(context != null)
					context.close();
			} catch (NamingException e) {
				LOGGER.error("There has been an error trying to close Active Dirctory context.", e);
			}
		}
		return membership;
	}
	
	/**
	 * @param groupName is the Active Directory group name
	 * @return return -1 if Active Directory group is invalid <br>return (0 or greater than 0) no of nested Active Directory group(s) and it represent the Active Directory group is valid
	 */
	public static int getNestedADGroupCount(String groupName) {
		DirContext context = null;
		try {
			context = getADConnection();
			return getAllNestedADGroupWithCount(groupName, context).getValue0();
		} catch (NamingException e) {
			LOGGER.error("There has been an error trying to count nested AD Groups : " + groupName, e);
		} finally {
			try {
				if(context != null)
					context.close();
			} catch (NamingException e) {
				LOGGER.error("There has been an error trying to close Active Dirctory context.", e);
			}
		}
		return -1;
	}
	
	/**
	 * @param groupName is the Active Directory group name
	 * @return return -1 if Active Directory group is invalid <br>return (0 or greater than 0) no of nested Active Directory group(s) and it represent the Active Directory group is valid
	 */
	public static Pair<Integer, List<String>> getNestadeADGroupsWithCount(String groupName) {
		DirContext context = null;
		try {
			context = getADConnection();
			return getAllNestedADGroupWithCount(groupName, context);
		} catch (NamingException e) {
			LOGGER.error("There has been an error trying to count nested AD Groups : " + groupName, e);
		} finally {
			try {
				if(context != null)
					context.close();
			} catch (NamingException e) {
				LOGGER.error("There has been an error trying to close Active Dirctory context.", e);
			}
		}
		return Pair.of(-1, Collections.emptyList());
	}

	/**
	 * @param groupName is the Active Directory group name
	 * @return return List of user name present in the Active Directory
	 */
	public static List<String> getNamesOfMembersOfADGroup(String groupName) {
		DirContext context = null;
		try {
			context = getADConnection();
			return getMemberNamesOfADGroup(context, groupName);
		} catch (NamingException e) {
			LOGGER.error("There has been an error trying to fetch members of AD Group : " + groupName, e);
		} finally {
			try {
				if(context != null)
					context.close();
			} catch (NamingException e) {
				LOGGER.error("There has been an error trying to close Active Dirctory context.", e);
			}
		}
		return Collections.emptyList();
	}

	/**
	 * @param groupName is the Active Directory group name
	 * @return return List of user id (racfId) present in the Active Directory
	 */
	public static List<String> getRacfIdsOfMembersOfADGroup(String groupName) {
		List<String> racfIDs = new ArrayList<>();

		DirContext context = null;
		try {
			context = getADConnection();
			List<String> memberNames = getMemberNamesOfADGroup(context, groupName);

			if (memberNames.isEmpty())
				return racfIDs;

			NamingEnumeration<SearchResult> a = context.search(SEARCH_BASE, "(|(cn=" + String.join(")(cn=", memberNames) + "))", searchControls("sAMAccountName"));
			while (a.hasMore())
				racfIDs.add((String) a.next().getAttributes().get("sAMAccountName").get(0));
		} catch (ReferralException e) {
			e.skipReferral();
		} catch (NamingException e) {
			LOGGER.error("There has been an error trying to fetch racf ids of AD Group : " + groupName, e);
		} finally {
			try {
				if(context != null)
					context.close();
			} catch (NamingException e) {
				LOGGER.error("There has been an error trying to close Active Dirctory context.", e);
			}
		}
		return racfIDs;
	}

	private static List<String> getMemberNamesOfADGroup(DirContext context, String groupName) throws NamingException {

		List<String> members = new ArrayList<>();
		try {
			NamingEnumeration<SearchResult> answer = context.search(SEARCH_BASE_SECURITY, "(cn=" + groupName + ")", searchControls("member"));
			while (answer.hasMore()) {
				Attribute mbrs = answer.next().getAttributes().get("member");
				if (mbrs == null) continue;

				NamingEnumeration<?> array = mbrs.getAll();
				while (array.hasMore()) {
					Pair<String, UserType> nameWithType = getNameWithType(array.next().toString());
					if (nameWithType.getValue0() != null && nameWithType.getValue1() == UserType.U) {
						members.add(nameWithType.getValue0());
					}
				}
			}
		} catch (ReferralException e) {
			e.skipReferral();
		}
		return members;
	}

	private static Pair<Integer, List<String>> getAllNestedADGroupWithCount(String groupName, DirContext context) throws NamingException {
		int count = -1;
		List<String> names = new ArrayList<>();
		try {
			NamingEnumeration<SearchResult> answer = context.search(SEARCH_BASE_SECURITY, "(cn=" + groupName + ")", searchControls("member"));
			while (answer.hasMore()) {
				Attribute mbrs = answer.next().getAttributes().get("member");
				if (mbrs == null) continue;
				count ++;

				NamingEnumeration<?> array = mbrs.getAll();
				while (array.hasMore()) {
					Pair<String, UserType> nameWithType = getNameWithType(array.next().toString());
					if (nameWithType.getValue0() != null && nameWithType.getValue1() == UserType.G) {
						// count += (getNestedADGroupCount(nameWithType.getValue0(), context) + 1); // For all nested groups
						count++;
						names.add(nameWithType.getValue0().toUpperCase());
					}
				}
			}
		} catch (ReferralException e) {
			e.skipReferral();
		}
		return Pair.of(count, names);
	}

	private static SearchControls searchControls(String... returningAttributes) {
		SearchControls ctrls = new SearchControls();
		ctrls.setReturningAttributes(returningAttributes);
		ctrls.setSearchScope(SearchControls.SUBTREE_SCOPE);
		return ctrls;
	}

	private static Pair<String, UserType> getNameWithType(String cnString) {
		Matcher m1 = Pattern.compile("(?<=CN=)(.*?)(?=\\s*\\,)").matcher(cnString);
		Matcher m2 = Pattern.compile("(?<=OU=)(.*?)(?=\\s*\\,)").matcher(cnString);
		UserType type = m2.find() && GROUP_LIST.stream().anyMatch(m2.group()::equalsIgnoreCase) ? UserType.G : UserType.U;
		return Pair.of(m1.find() ? m1.group() : null, type);
	}

	enum UserType {

		U("User"), G("Group"), I("Invalid Group");

		private String value;

		UserType(String value) {
			this.value = value;
		}

		public String getValue() {
			return value;
		}
	}

	public static class Pair<A, B> {

		private final A value0;

		private final B value1;

		public Pair(A value0, B value1) {
			this.value0 = value0;
			this.value1 = value1;
		}

		public static <A, B> Pair<A, B> of(A arg1, B arg2) {
			return new Pair<>(arg1, arg2);
		}

		public A getValue0() {
			return this.value0;
		}

		public B getValue1() {
			return this.value1;
		}

		@Override
		public String toString() {
			return String.format("(%s, %s)", value0, value1);
		}
	}
}
