package com.deere.epdp.pra.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.deere.epdp.pra.domain.prm.ProjectTeam;
import com.deere.epdp.pra.model.ProjectDetail.ProjectTeamDetail;
import com.deere.epdp.pra.model.Response;
import com.deere.epdp.pra.service.prm.ProjectTeamService;

/**
 * @author RM43492
 *
 */
@RestController
@RequestMapping(value = { "/api/project-team", "/api/comseg/project-team" })
public class ProjectTeamController {

	@Autowired
	private ProjectTeamService projectTeamService;

	@PostMapping
	public Response<ProjectTeamDetail> addProjectTeam(@RequestBody ProjectTeam projectTeam) {
		return projectTeamService.addProjectTeam(projectTeam);
	}

	@PutMapping
	public Response<ProjectTeamDetail> updateProjectTeam(@RequestBody List<ProjectTeam> projectTeams) {
		return projectTeamService.updateProjectTeam(projectTeams);
	}
	
	@DeleteMapping("/{projId}")
	public Response<ProjectTeamDetail> deleteProjectTeam(@PathVariable Integer projId, @RequestParam String memberId, @RequestParam ProjectTeam.MemberType type) {
		return projectTeamService.deleteProjectTeam(projId, memberId, type);
	}
	
	@GetMapping("/{projId}")
	public List<ProjectTeamDetail> getProjectTeamDetail(@PathVariable Integer projId) {
		return projectTeamService.getProjectTeamDetailByPrjId(projId);
	}
	
}
