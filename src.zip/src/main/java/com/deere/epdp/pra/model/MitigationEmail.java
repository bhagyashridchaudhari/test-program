package com.deere.epdp.pra.model;

import java.util.Date;

public class MitigationEmail {

	private int progId;
	private String progName;
	private String riskTitle;
	private String causeIf;
	private String effectThen;
	private String mtgtnPlan;
	private Date targetClosure;
	private String comments;
	private String mtgtnStatus;
	private String mtgtnOwner;
	private String mtgtnOwnerName;
	private String message;
	
	private String rskLevel;
	private int rskScore;
	private String mtgtnLevel;
	private int mtgtnScore;
	
	
	public int getProgId() {
		return progId;
	}
	public void setProgId(int progId) {
		this.progId = progId;
	}
	public String getProgName() {
		return progName;
	}
	public void setProgName(String progName) {
		this.progName = progName;
	}
	public String getRiskTitle() {
		return riskTitle;
	}
	public void setRiskTitle(String riskTitle) {
		this.riskTitle = riskTitle;
	}
	public String getCauseIf() {
		return causeIf;
	}
	public void setCauseIf(String causeIf) {
		this.causeIf = causeIf;
	}
	public String getEffectThen() {
		return effectThen;
	}
	public void setEffectThen(String effectThen) {
		this.effectThen = effectThen;
	}
	public String getMtgtnPlan() {
		return mtgtnPlan;
	}
	public void setMtgtnPlan(String mtgtnPlan) {
		this.mtgtnPlan = mtgtnPlan;
	}
	public Date getTargetClosure() {
		return targetClosure;
	}
	public void setTargetClosure(Date targetClosure) {
		this.targetClosure = targetClosure;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getMtgtnStatus() {
		return mtgtnStatus;
	}
	public void setMtgtnStatus(String mtgtnStatus) {
		this.mtgtnStatus = mtgtnStatus;
	}
	public String getMtgtnOwner() {
		return mtgtnOwner;
	}
	public void setMtgtnOwner(String mtgtnOwner) {
		this.mtgtnOwner = mtgtnOwner;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getRskLevel() {
		return rskLevel;
	}
	public void setRskLevel(String rskLevel) {
		this.rskLevel = rskLevel;
	}
	public int getRskScore() {
		return rskScore;
	}
	public void setRskScore(int rskScore) {
		this.rskScore = rskScore;
	}
	public String getMtgtnLevel() {
		return mtgtnLevel;
	}
	public void setMtgtnLevel(String mtgtnLevel) {
		this.mtgtnLevel = mtgtnLevel;
	}
	public int getMtgtnScore() {
		return mtgtnScore;
	}
	public void setMtgtnScore(int mtgtnScore) {
		this.mtgtnScore = mtgtnScore;
	}
	public String getMtgtnOwnerName() {
		return mtgtnOwnerName;
	}
	public void setMtgtnOwnerName(String mtgtnOwnerName) {
		this.mtgtnOwnerName = mtgtnOwnerName;
	}
	
}
