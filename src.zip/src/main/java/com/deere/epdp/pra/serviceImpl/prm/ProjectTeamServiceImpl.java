package com.deere.epdp.pra.serviceImpl.prm;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.deere.epdp.pra.domain.prm.ProjectTeam;
import com.deere.epdp.pra.domain.prm.ProjectTeam.MemberType;
import com.deere.epdp.pra.domain.prm.ProjectTeam.ProjectTeamId;
import com.deere.epdp.pra.domain.user.User;
import com.deere.epdp.pra.exception.DuplicateEntityException;
import com.deere.epdp.pra.exception.InvalidDataException;
import com.deere.epdp.pra.model.ProjectDetail.ProjectTeamDetail;
import com.deere.epdp.pra.model.Response;
import com.deere.epdp.pra.model.Response.RespMessage;
import com.deere.epdp.pra.model.Response.Status;
import com.deere.epdp.pra.repo.prm.ProjectTeamRepository;
import com.deere.epdp.pra.service.prm.ProjectService;
import com.deere.epdp.pra.service.prm.ProjectTeamService;
import com.deere.epdp.pra.service.UserService;
import com.deere.epdp.pra.utility.ActiveDirectoryUtility;
import com.deere.epdp.pra.utility.ActiveDirectoryUtility.Pair;
import com.deere.epdp.pra.utility.CommonUtility;
@Service
public class ProjectTeamServiceImpl implements ProjectTeamService {

	@Autowired
	private ProjectTeamRepository projectTeamRepository;

	@Autowired
	private ProjectService projectService;

	@Autowired
	private UserService userService;

	@Autowired
	private User user;

	@Override
	@Transactional(readOnly = true)
	public List<ProjectTeamDetail> getProjectTeamDetailByPrjId(Integer projId) {
		return projectTeamRepository.findByIdProjId(projId).stream().map(
				pt -> new ProjectTeamDetail(pt.getId().getMemberId(), pt.getMemberType().name(), pt.getRoleId())).collect(Collectors.toList());
	}

	@Override
	@Transactional(readOnly = true)
	public List<ProjectTeam> getProjectTeamByPrjId(Integer projId) {
		return projectTeamRepository.findByIdProjId(projId);
	}

	@Override
	@Transactional(readOnly = true)
	public List<ProjectTeam> getProjectTeamByMemId(String memberId) {
		return projectTeamRepository.findByIdMemberId(memberId).stream().map(
				t -> new ProjectTeam(new ProjectTeamId((Integer) t[0], memberId), (Integer) t[1])).collect(Collectors.toList());
	}

	@Override
	@Transactional(readOnly = true)
	public List<ProjectTeam> getProjectTeamByMemType(ProjectTeam.MemberType memberType) {
		return projectTeamRepository.findByMemberType(memberType);
	}

	@Override
	@Transactional
	public ProjectTeamDetail saveProjectTeam(ProjectTeam projectTeam) {
		projectTeam.setLastUpdatedBy(user.getUserId());
		projectTeam.setLastUpdatedTs(CommonUtility.getCurrentTime());
		projectTeamRepository.save(projectTeam);
	//	userService.addUserAndRole(projectTeam);
		return projectTeam.map(pt -> new ProjectTeamDetail(pt.getId().getMemberId(), pt.getMemberType().name(), pt.getRoleId()));
	}

	@Override
	@Transactional
	public void saveProjectTeams(List<ProjectTeam> projectTeams) {
		projectTeams.forEach(pt -> {
			pt.setLastUpdatedBy(user.getUserId());
			pt.setLastUpdatedTs(CommonUtility.getCurrentTime());
		});
		projectTeamRepository.save(projectTeams);
	}

	@Override
	@Transactional
	public void updateProjectTeams(List<ProjectTeam> projectTeams) {
		projectTeams.forEach(p -> {
			p.setLastUpdatedBy(user.getUserId());
			p.setLastUpdatedTs(CommonUtility.getCurrentTime());
		});
		projectTeamRepository.save(projectTeams);
		projectTeams.forEach(p -> userService.updateUserAndRole(p));
	}

	@Override
	@Transactional
	public void deleteProjectTeams(List<ProjectTeamId> projectTeamIds) {
		projectTeamRepository.deleteAndFlush(projectTeamIds);
	}

	@Override
	@Transactional
	public void deleteProjectTeam(ProjectTeamId projectTeamId) {
		projectTeamRepository.deleteById(projectTeamId);
	}

	@Override
	@Transactional
	public void deleteProjectTeam(ProjectTeam projectTeam) {
		projectTeamRepository.deleteById(projectTeam.getId());
		userService.removeUserAndRole(projectTeam);
	}

	@Override
	@Transactional
	public void deleteProjectTeam(Integer projId) {
		projectTeamRepository.delete(getProjectTeamByPrjId(projId));
	}

	@Override
	@Transactional(readOnly = true)
	public boolean isTeamMemberExist(ProjectTeamId projectTeamId) {
		return projectTeamRepository.exists(projectTeamId) || projectTeamId.getMemberId().equals(projectService.getOwner(projectTeamId.getProjId()));
	}

	@Override
	@Transactional(readOnly = true)
	public Set<String> getAllProjectTeamUserId() {
		return projectTeamRepository.getAllTeamUserId();
	}
	
	@Override
	public Response<ProjectTeamDetail> addProjectTeam(ProjectTeam projectTeam) {
		List<RespMessage> errors = new ArrayList<>();
		Pair<Integer, List<String>> nestadeADGroup = null;
	
		if(projectTeam.getMemberType() == MemberType.G ) {
			nestadeADGroup = ActiveDirectoryUtility.getNestadeADGroupsWithCount(projectTeam.getId().getMemberId());
			if(nestadeADGroup.getValue0() == -1) {
				throw new InvalidDataException("Invalid AD group. Please add a valid AD group.");			
			}
			
	    }else if (isTeamMemberExist(projectTeam.getId()))
			throw new DuplicateEntityException("Duplicate member found for same program.");
		else if (user.getUserId().equals(projectTeam.getId().getMemberId()))
			throw new DuplicateEntityException("You can not add yourself as member.");

		ProjectTeamDetail pt = saveProjectTeam(projectTeam);
	 
		pt = (nestadeADGroup!= null && nestadeADGroup.getValue0() > 0 ? new ProjectTeamDetail(pt.getMemberId(), pt.getMemberType(), pt.getRoleId(),
				String.join(", ", nestadeADGroup.getValue1()), nestadeADGroup.getValue0()) : pt);
		
		return new Response<>(Status.SUCCESS, pt, errors.isEmpty() ? null : errors);
	}
	
	@Override
	public Response<ProjectTeamDetail> deleteProjectTeam(Integer projId, String memberId, MemberType type) {
		List<RespMessage> errors = new ArrayList<>();
		ProjectTeamDetail pt = new ProjectTeamDetail();
		Pair<Integer, List<String>> nestadeADGroup = null;
		pt.setMemberId(memberId);
		pt.setMemberType(type.toString());
		if(type == MemberType.G ) {
			nestadeADGroup = ActiveDirectoryUtility.getNestadeADGroupsWithCount(memberId); 
			pt = (nestadeADGroup!= null && nestadeADGroup.getValue0() > 0 ? new ProjectTeamDetail(pt.getMemberId(), pt.getMemberType(), pt.getRoleId(),
					String.join(", ", nestadeADGroup.getValue1()), nestadeADGroup.getValue0()) : pt);
		}
			
		deleteProjectTeam(new ProjectTeam(new ProjectTeamId(projId, memberId), type));
		
		return new Response<>(Status.SUCCESS, pt, errors.isEmpty() ? null : errors);
	}
	

	@Override
	public Response<ProjectTeamDetail> updateProjectTeam(List<ProjectTeam> projectTeam) {
		List<RespMessage> errors = new ArrayList<>();
		updateProjectTeams(projectTeam); 
		return new Response<>(Status.SUCCESS, null, errors.isEmpty() ? null : errors);
	}

	
	
}