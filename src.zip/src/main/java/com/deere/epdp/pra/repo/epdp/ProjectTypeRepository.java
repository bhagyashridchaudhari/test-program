package com.deere.epdp.pra.repo.epdp;

import org.springframework.data.repository.CrudRepository;

import com.deere.epdp.pra.domain.epdp.ProjectType;

public interface ProjectTypeRepository extends CrudRepository<ProjectType, Integer> {}
