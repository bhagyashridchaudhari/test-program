package com.deere.epdp.pra.serviceImpl;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deere.epdp.pra.domain.epdp.Platform;
import com.deere.epdp.pra.repo.epdp.PlatformRepository;
import com.deere.epdp.pra.service.PlatformService;

@Service
public class PlatformServiceImpl implements PlatformService {

	@Autowired
	private PlatformRepository platformRepository;

	private Map<Integer, Platform> platformMap;

	@PostConstruct
	public void init() {
		platformMap = StreamSupport.stream(platformRepository.findAll().spliterator(), false)
				.collect(Collectors.toMap(Platform::getPltfmId, Function.identity()));
	}

	@Override
	public List<Platform> getAllPlatform() {
		return platformMap.values().stream().sorted(Comparator.comparing(Platform::getPltfmNm)).collect(Collectors.toList());
	}

	@Override
	public String getPlatformNameById(Integer id) {
		Platform platform = platformMap.get(id);
		return platform != null ? platform.getPltfmNm() : null;
	}
}
