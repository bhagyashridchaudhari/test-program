package com.deere.epdp.pra.serviceImpl.prm;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deere.epdp.pra.domain.prm.RiskScoreLevel;
import com.deere.epdp.pra.repo.prm.RiskScoreLevelRepository;
import com.deere.epdp.pra.service.prm.RiskScoreLevelService;

@Service
public class RiskScoreLevelServiceImpl implements RiskScoreLevelService{
	
	@Autowired
	private RiskScoreLevelRepository scoreLevelRepository;
	
	private List<RiskScoreLevel> riskScoreLevel;

	@PostConstruct
	public void init() {
		riskScoreLevel = StreamSupport.stream(scoreLevelRepository.findAll().spliterator(), false)
				.collect(Collectors.toList());
	}

	@Override
	public List<RiskScoreLevel> getAllScoreLevel() {
		Comparator<Object> groupByComparator = Comparator.comparing(i -> ((RiskScoreLevel) i).getId().getImpactId()).thenComparing(i -> ((RiskScoreLevel) i).getId().getPrbltyId());
		riskScoreLevel.sort(groupByComparator);
		
		return riskScoreLevel;
	}
}
