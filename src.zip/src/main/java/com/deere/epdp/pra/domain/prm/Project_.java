package com.deere.epdp.pra.domain.prm;

import java.util.Date;

import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@StaticMetamodel(Project.class)
public class Project_ {

	public static volatile SingularAttribute<Project, Integer> prjId;

	public static volatile SingularAttribute<Project, String> prjName;

	public static volatile SingularAttribute<Project, Integer> prjTypeId;

	public static volatile SingularAttribute<Project, Integer> prjStatusId;

	public static volatile SingularAttribute<Project, Integer> divId;

	public static volatile SingularAttribute<Project, Integer> pltfmId;

	public static volatile SingularAttribute<Project, Integer> prdlnId;

	public static volatile SingularAttribute<Project, Integer> prdfmlyId;

	public static volatile SingularAttribute<Project, Integer> unitId;

	public static volatile SingularAttribute<Project, String> prjOwner;

	public static volatile SingularAttribute<Project, String> prjManager;

	public static volatile SingularAttribute<Project, String> prjDirector;
	
	public static volatile SingularAttribute<Project, Date> prjStartDate;
	
	public static volatile SingularAttribute<Project, Date> prjEndDt;
}