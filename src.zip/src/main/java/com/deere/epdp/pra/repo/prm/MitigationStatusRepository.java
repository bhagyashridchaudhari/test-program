package com.deere.epdp.pra.repo.prm;

import org.springframework.data.repository.CrudRepository;

import com.deere.epdp.pra.domain.prm.MitigationStatus;

public interface MitigationStatusRepository extends CrudRepository<MitigationStatus, Integer>{

}
