package com.deere.epdp.pra.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deere.epdp.pra.domain.epdp.Phase;
import com.deere.epdp.pra.repo.epdp.PhaseRepository;
import com.deere.epdp.pra.service.PhaseService;

@Service
public class PhaseServiceImpl implements PhaseService {

	@Autowired
	private PhaseRepository phaseRepository;

	private Map<Integer, Phase> phaseMap;

	@PostConstruct
	public void init() {
		phaseMap = StreamSupport.stream(phaseRepository.findAll().spliterator(), false).collect(Collectors.toMap(Phase::getPhaseId, Function.identity()));
	}

	@Override
	public List<Phase> getAllPhase() {
		return new ArrayList<>(phaseMap.values());
	}

	@Override
	public Phase getPhaseById(Integer id) {
		return phaseMap.get(id);
	}

}