package com.deere.epdp.pra.repo.prm;
import org.springframework.data.repository.CrudRepository;

import com.deere.epdp.pra.domain.prm.Role;

public interface RoleRepository extends CrudRepository<Role, Integer> {}
