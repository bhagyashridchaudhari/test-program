package com.deere.epdp.pra.domain.epdp;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.ColumnDefault;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "project_status")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProjectStatus implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "proj_status_id")
	private Integer statusId;

	@Column(name = "status_nm", nullable = false)
	private String statusNm;

	@Column(name = "status_dsc")
	private String statusDsc;

	@Column(name = "is_active", length = 1)
	@ColumnDefault("'Y'")
	private String isActive;

	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdtBy;

	@JsonIgnore
	@Column(name = "last_updt_ts")
	private Timestamp lastUpdtTs;

	@Transient
	private List<Integer> mappedIds;

	public Integer getStatusId() {
		return statusId;
	}

	public String getStatusNm() {
		return statusNm;
	}

	public String getStatusDsc() {
		return statusDsc;
	}

	public String getIsActive() {
		return isActive;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}

	public List<Integer> getMappedIds() {
		return mappedIds;
	}

	public void setMappedIds(List<Integer> mappedIds) {
		this.mappedIds = mappedIds;
	}
}