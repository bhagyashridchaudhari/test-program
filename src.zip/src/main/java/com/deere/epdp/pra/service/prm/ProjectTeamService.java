package com.deere.epdp.pra.service.prm;

import java.util.List;
import java.util.Set;

import com.deere.epdp.pra.domain.prm.ProjectTeam;
import com.deere.epdp.pra.domain.prm.ProjectTeam.MemberType;
import com.deere.epdp.pra.domain.prm.ProjectTeam.ProjectTeamId;
import com.deere.epdp.pra.model.ProjectDetail.ProjectTeamDetail;
import com.deere.epdp.pra.model.Response;


public interface ProjectTeamService {
	
	List<ProjectTeamDetail> getProjectTeamDetailByPrjId(Integer projId);

	List<ProjectTeam> getProjectTeamByPrjId(Integer projId);

	List<ProjectTeam> getProjectTeamByMemId(String memberId);
	
	List<ProjectTeam> getProjectTeamByMemType(ProjectTeam.MemberType memberType);

	ProjectTeamDetail saveProjectTeam(ProjectTeam projectTeam);
	
	void saveProjectTeams(List<ProjectTeam> projectTeams);
	
	void updateProjectTeams(List<ProjectTeam> projectTeams);

	void deleteProjectTeams(List<ProjectTeamId> projectTeamIds);
	
	void deleteProjectTeam(ProjectTeamId projectTeamId);
	
	void deleteProjectTeam(ProjectTeam projectTeam);
	
	void deleteProjectTeam(Integer projId);

	boolean isTeamMemberExist(ProjectTeamId projectTeamId);
	
	Set<String> getAllProjectTeamUserId();

	Response<ProjectTeamDetail> addProjectTeam(ProjectTeam projectTeam);

	Response<ProjectTeamDetail> deleteProjectTeam(Integer projId, String memberId, MemberType type);

	Response<ProjectTeamDetail> updateProjectTeam(List<ProjectTeam> projectTeam);
	
}
