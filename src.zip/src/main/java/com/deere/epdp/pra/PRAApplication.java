package com.deere.epdp.pra;

import java.text.SimpleDateFormat;
import java.util.TimeZone;
import java.util.concurrent.Executor;

import javax.annotation.PostConstruct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.deere.epdp.pra.literals.PRALiterals;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;

@SpringBootApplication
@EnableEncryptableProperties
@PropertySource(value="classpath:application-${spring.profiles.active}.properties")
public class PRAApplication {

	public static void main(String[] args) {
		SpringApplication.run(PRAApplication.class, args);
		System.out.println("Started..");
	} 
	
	@PostConstruct
    public void init(){
        TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
    }
	
	@Bean
	public Executor asyncExecutor() {
	    ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
	    executor.setCorePoolSize(5);
	    executor.setMaxPoolSize(5);
	    executor.setQueueCapacity(500);
	    executor.setThreadNamePrefix("Task-");
	    executor.initialize();
	    return executor;
	}
	
	@Bean
    public ObjectMapper objectMapper() {
        ObjectMapper dateFormatMapper = new ObjectMapper();
        dateFormatMapper.setDateFormat(new SimpleDateFormat(PRALiterals.DATE_FORMAT));
        return dateFormatMapper;
    }
}