package com.deere.epdp.pra.serviceImpl;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deere.epdp.pra.domain.epdp.ProductLine;
import com.deere.epdp.pra.repo.epdp.ProductLineRepository;
import com.deere.epdp.pra.service.ProductLineService;

/**
 * @author RM43492
 *
 */
@Service
public class ProductLineServiceImpl implements ProductLineService {

	@Autowired
	private ProductLineRepository productLineDao;

	private Map<Integer, ProductLine> productLineMap;

	@PostConstruct
	public void init() {
		productLineMap = StreamSupport.stream(productLineDao.findAll().spliterator(), false)
				.collect(Collectors.toMap(ProductLine::getPrdlnId, Function.identity()));
	}

	@Override
	public List<ProductLine> getAllProductLine() {
		return productLineMap.values().stream().sorted(Comparator.comparing(ProductLine::getPrdlnNm)).collect(Collectors.toList());
	}

	@Override
	public String getProductLineNameById(Integer id) {
		ProductLine line = productLineMap.get(id);
		return line != null ? line.getPrdlnNm() : null;
	}

}
