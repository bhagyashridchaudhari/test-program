package com.deere.epdp.pra.serviceImpl.prm;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.deere.epdp.pra.exception.ExportException;
import com.deere.epdp.pra.model.ExcelData;
import com.deere.epdp.pra.model.ExcelData.Sheet.ColWidth;
import com.deere.epdp.pra.model.ExcelData.Style;
import com.deere.epdp.pra.service.prm.ReportsService;
import com.deere.epdp.pra.utility.CommonUtility;

@Service
public class ReportsServiceImpl implements ReportsService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ReportsServiceImpl.class);
	
	@Override
	public byte[] generateExcel(ExcelData excelData) {
		try (Workbook workbook = new XSSFWorkbook(); ByteArrayOutputStream os = new ByteArrayOutputStream()) {
			if (excelData != null && excelData.getSheets() != null) {
				excelData.getSheets().forEach(s -> {
					AtomicInteger maxLength = new AtomicInteger();
					Sheet sheet = workbook.createSheet(s.getName());
					CellStyle styleSheet = CommonUtility.getCellStyle(workbook, s.getStyle());
					if (s.getRows() != null) {
						s.setColCount(0);
						AtomicInteger rowIndex = new AtomicInteger();
						s.getRows().forEach(r -> {
							Row row = sheet.createRow(rowIndex.getAndIncrement());
							boolean rowStyleChanged = CommonUtility.changeStyle(r.getStyle(), s.getStyle());								
							CellStyle styleRow = rowStyleChanged ? CommonUtility.getCellStyle(workbook, r.getStyle()) : styleSheet;
							Style rowStyle = rowStyleChanged ? r.getStyle() : s.getStyle();
							if (r.getCells() != null) {
								AtomicInteger cellIndex = new AtomicInteger();
								r.getCells().forEach(c -> {
									if (c.getColSpan() != null)
										sheet.addMergedRegion(new CellRangeAddress(rowIndex.get() - 1, rowIndex.get() - 1, cellIndex.get(), cellIndex.get() + c.getColSpan() - 1));
									CellStyle styleCell = CommonUtility.changeStyle(c.getStyle(), rowStyle) ? CommonUtility.getCellStyle(workbook, c.getStyle()) : styleRow;
									Cell cell = row.createCell(cellIndex.get());
									if (c.getData() != null)
										cell.setCellValue(c.getData());
									if (styleCell != null)
										cell.setCellStyle(styleCell);
									if (c.getColSpan() != null)
										IntStream.range(1, c.getColSpan()).forEach(i -> row.createCell(cellIndex.get() + i).setCellStyle(styleRow));

									cellIndex.set(c.getColSpan() != null ? cellIndex.get() + c.getColSpan() : cellIndex.get() + 1);
								});
								if (cellIndex.get() > maxLength.get())
									maxLength.set(cellIndex.get());
							}
						});
						
					if (s.getLock() != null)
						sheet.createFreezePane(s.getLock().getCol(), s.getLock().getRow());
						
					if (s.getWidths() != null && !s.getWidths().isEmpty()) {
						Map<Integer, Integer> m = s.getWidths().stream().collect(Collectors.toMap(ColWidth::getCol, ColWidth::getWidth));
						IntStream.range(0, maxLength.get()).forEach(i -> {
						if (m.get(i) == null)
							sheet.autoSizeColumn(i);
						else
							sheet.setColumnWidth(i, m.get(i));
						});
					} else					
						IntStream.range(0, maxLength.get()).forEach(sheet::autoSizeColumn);
				  
				}
			  });
			}
			workbook.write(os);
			return os.toByteArray();
		} catch (IOException e) {
			LOGGER.error(e.getMessage(), e);
			throw new ExportException("Error creating excel file");
		}
	}
	

}
