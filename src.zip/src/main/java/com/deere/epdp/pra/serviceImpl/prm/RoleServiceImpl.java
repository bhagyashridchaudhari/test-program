package com.deere.epdp.pra.serviceImpl.prm;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deere.epdp.pra.domain.prm.Role;
import com.deere.epdp.pra.repo.prm.RoleRepository;
import com.deere.epdp.pra.service.prm.RoleService;

@Service
public class RoleServiceImpl implements RoleService {

	@Autowired
	private RoleRepository roleRepository;

	private Map<Integer, Role> roleMap;

	@PostConstruct
	public void init() {
		roleMap = StreamSupport.stream(roleRepository.findAll().spliterator(), false)
				.collect(Collectors.toMap(Role::getRoleId, Function.identity()));
	}

	@Override
	public List<Role> getAllRole() {
		return new ArrayList<>(roleMap.values());
	}

	@Override
	public Role getRoleById(Integer id) {
		return roleMap.get(id);
	}

}