package com.deere.epdp.pra.serviceImpl.prm;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.deere.epdp.pra.domain.prm.ProjectRisk;
import com.deere.epdp.pra.domain.user.User;
import com.deere.epdp.pra.model.ImageData;
import com.deere.epdp.pra.model.MitigationEmail;
import com.deere.epdp.pra.model.PrgRiskDetails;
import com.deere.epdp.pra.model.Response;
import com.deere.epdp.pra.model.Response.RespMessage;
import com.deere.epdp.pra.model.Response.RespMessage.Type;
import com.deere.epdp.pra.model.Response.Status;
import com.deere.epdp.pra.model.RiskCategoryData;
import com.deere.epdp.pra.model.RiskImageData;
import com.deere.epdp.pra.model.RiskMitigation;
import com.deere.epdp.pra.model.SubDesignTeam;
import com.deere.epdp.pra.repo.prm.MitigationPlanRepository;
import com.deere.epdp.pra.repo.prm.ProjectRiskRepository;
import com.deere.epdp.pra.service.prm.DesignSubTeamService;
import com.deere.epdp.pra.service.prm.ProjectRiskService;
import com.deere.epdp.pra.service.prm.RiskCategoryService;
import com.deere.epdp.pra.utility.CommonUtility;
import com.deere.epdp.pra.utility.Converter;
import com.deere.epdp.pra.utility.EmailUtility;
@Service
public class ProjectRiskServiceImpl implements ProjectRiskService{
	
	@Autowired
	private User user;
	
	@Autowired
	private ProjectRiskRepository riskRepository;
	
	@Autowired
	private MitigationPlanRepository mtgtnRepository;
	
	@Autowired
	private  DesignSubTeamService teamService;
	
	@Autowired	
	private RiskCategoryService riskCategoryService;
	
	@Value("${programUrl}")
	private String programUrl;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ProjectRiskServiceImpl.class);
	
	@Override
	public Iterable<RiskMitigation> getAllRiskByProjectId(Integer prjId) {
		return ((Collection<ProjectRisk>) riskRepository.findAll()).stream().filter(p -> p.getPrgmId() == prjId).map(Converter::convertToRiskMitigation).collect(Collectors.toList()); 
	}

	@Override
	@Transactional(readOnly = true)
	public RiskMitigation getRiskById(Integer rskId) {
		return Converter.convertToRiskMitigation(riskRepository.findOne(rskId));
	}

	@Override
	@Transactional(value="prmTransactionManager",readOnly=false,propagation=Propagation.REQUIRED) 
	public Response<RiskMitigation> saveRisk(RiskMitigation rskMtgtn) {
		List<RespMessage> errors = new ArrayList<>();
		Integer riskId = rskMtgtn.getRiskId();
		String userId = user.getUserId();
		Timestamp currntTime = CommonUtility.getCurrentTime();

		if(riskId != null) {
			ProjectRisk riskObj = riskRepository.findOne(rskMtgtn.getRiskId());
			if(( riskObj.getRsStrtrgyId() != null && riskObj.getRsStrtrgyId() == 1 ) && rskMtgtn.getRsStrtrgyId() != 1) {
				mtgtnRepository.delete(riskObj.getMitigationPlan().getMtgtnId());
				rskMtgtn.setMitigation(null);
			}			
		}
		
		ProjectRisk prRisk = Converter.convertToProjectRisk(rskMtgtn,userId, currntTime);
		
		if(!(riskId != null) ) {
			prRisk.setCreatedBy(userId);
			prRisk.setCreatedTs(currntTime);
		}	
		if(rskMtgtn.getMitigation()!=null && (rskMtgtn.getMitigation().getMtgtnTitle()!= null && !rskMtgtn.getMitigation().getMtgtnTitle().trim().isEmpty()))
			prRisk.setMitigationPlan(Converter.convertToMitigationPlan(rskMtgtn.getMitigation(),prRisk,userId, currntTime));
			
		riskRepository.save(prRisk);
		
		return new Response<>(Status.SUCCESS, rskMtgtn, errors.isEmpty() ? null : errors );
	}
	
	@Override
	@Transactional
	public void uploadImages(MultipartFile mFile, Integer progId, Integer riskId, Integer imgId) {
		String path= System.getProperty("IafMOD");
		path+= path.endsWith(File.separator) ?"":File.separator;
		path+="docs"+File.separator+"PRA"+File.separator;
		LOGGER.info("Complete folder path-------------->"+path);

		InputStream input = null;
		OutputStream output = null;
		try {
			String idPath = path + "PID-" + progId;
			File folder = new File(idPath);
			if (!folder.exists()) {
				if (folder.mkdir()) {
					LOGGER.info("Program Directory is created!");
				} else {
					LOGGER.info("Failed to create Program directory!");
				}
			}
			idPath+= File.separator + "RID-"+ riskId;
			File folder1 = new File(idPath);
			if (!folder1.exists()) {
				if (folder1.mkdir()) {
					LOGGER.info("Risk Directory is created!");
				} else {
					LOGGER.info("Failed to create Risk directory!");
				}
			}
			 
			String extension =".jpg";
			//String extension = fileNm.substring(fileNm.lastIndexOf("."), fileNm.length());
			String fileName = "PID" +progId+"_RID" +riskId+"_IID-" +imgId+extension;
			File file = new File(idPath +  File.separator + fileName);
			
			if (!file.exists()) {
				file.createNewFile();
				LOGGER.info("the file is created");
			} else {
				LOGGER.info("file already Exist");
			}
			output = new FileOutputStream(file);
			byte[] buf = new byte[1024];
			int bytesRead;
			input = mFile.getInputStream(); 
			while ((bytesRead = input.read(buf)) > 0) {
				output.write(buf, 0, bytesRead);
			}
		} catch (Exception e) {
			LOGGER.error("Exception uploading image => "+ e.getMessage());
		} finally {
			try {
				if (input != null)
					input.close(); 
				if (output != null)
					output.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public List<String> getImage(Integer progId, Integer riskId)  {
		List<String> list = new ArrayList<String>();
		String path= System.getProperty("IafMOD");
		System.out.println("IafMOD path-------------->"+path);
		
		path+= path.endsWith(File.separator) ?"":File.separator;
		path+="docs"+File.separator+"PRA"+File.separator;
		
		System.out.println("Complete folder path-------------->"+path);
		
		path+= "PID-"+progId+File.separator+"RID-"+riskId;
		File riskFolder = new File(path);

		if(riskFolder!= null && riskFolder.listFiles() != null) {
			for(final File file : riskFolder.listFiles()) {
				String encodeBase64= null;
				try {
					String extension = FilenameUtils.getExtension(riskFolder.getName());
					FileInputStream fileInputStream = new FileInputStream(file);
					byte[] bytes = new byte[(int)file.length()];
					fileInputStream.read(bytes);
					encodeBase64= Base64.getEncoder().encodeToString(bytes);
					list.add("data:image/jpeg"+extension+";base64,"+encodeBase64);
					fileInputStream.close();	
				}catch(Exception e) {}
			}
		}
		return list;
	}
	
	
	@Override
	public List<RiskImageData> getImage2(Integer progId, Integer riskId)  {
		// List<String> list = new ArrayList<String>();
		String path= System.getProperty("IafMOD");
		System.out.println("IafMOD path-------------->"+path);
		
		path+= path.endsWith(File.separator) ?"":File.separator;
		path+="docs"+File.separator+"PRA"+File.separator;
		
		System.out.println("Complete folder path-------------->"+path);
		List<RiskImageData> list = new ArrayList<RiskImageData>();
		
		path+= "PID-"+progId+File.separator+"RID-"+riskId;
		File riskFolder = new File(path);

		if(riskFolder!= null && riskFolder.listFiles() != null) {
			for(final File file : riskFolder.listFiles()) {
				String encodeBase64= null;
				try {
					String extension = FilenameUtils.getExtension(riskFolder.getName());
					// String extension = FilenameUtils.getExtension(file.getName());
					FileInputStream fileInputStream = new FileInputStream(file);
					String fileNm = file.getName();
					String prefix = fileNm.substring(0,fileNm.lastIndexOf(".")); //  fileNm.length()
					String [] fileToken= prefix.split("-");
					byte[] bytes = new byte[(int)file.length()];
					System.out.println("fileName-"+fileToken[0]+"......."+fileToken[1]);
					fileInputStream.read(bytes);
					encodeBase64= Base64.getEncoder().encodeToString(bytes);
					list.add(new RiskImageData(Integer.parseInt(fileToken[1]),"data:image/jpeg"+extension+";base64,"+encodeBase64));
					fileInputStream.close();	
				}catch(Exception e) {}
			}
		}
		return list;
	}
	
	@Override
	public Response<String> deleteImage(Integer progId, Integer riskId, Integer imgId) {
		List<RespMessage> errors = new ArrayList<RespMessage>();
			String path= System.getProperty("IafMOD");
			path+= path.endsWith(File.separator) ?"":File.separator;
			path+="docs"+File.separator+"PRA"+File.separator;
			path+= "PID-"+progId+File.separator+"RID-"+riskId;
			String extension =".jpg"; 
			String fileName = "PID" +progId+"_RID" +riskId+"_IID-" +imgId+extension;
			File file = new File(path +  File.separator + fileName);
	        if(file.delete()) { 
	            return new Response<>(Status.SUCCESS,Arrays.asList(new RespMessage("Picture deleted successfully.", Type.SUCCESS)));
	        }else{ 
	        	LOGGER.error("Not able to delete Image");
	            return new Response<>(Status.SUCCESS,Arrays.asList(new RespMessage("Not able to delete picture.", Type.SUCCESS)));
	        } 
		}

	@Override
	@Transactional
	public Response<String> deleteRisk(Integer id) {
		List<RespMessage> errors = new ArrayList<>();
		try {
			riskRepository.delete(id);
		}catch(Exception e) {
			LOGGER.error("Not able to delete risk", e);
			errors.add(new RespMessage("Not able to delete risk.", Type.WARNING));
		}
		
		return new Response<>(Status.SUCCESS, errors.isEmpty() ? null : errors);
	}

	@Override
	public Response<String> sendEmailToMitigationOwner(List<MitigationEmail> mailBody) {
		List<RespMessage> errors = new ArrayList<>();
		try {
			for (MitigationEmail obj : mailBody) {
				createEmailBody(obj);
			}
		} catch (Exception e) {
			LOGGER.error("Error sendEmailToMitigationOwner");
		}	
		return new Response<>(Status.SUCCESS, "Mail send successfully.", errors.isEmpty() ? null : errors );
	}
	
	public void createEmailBody(MitigationEmail mailBody) {
//		List<RespMessage> errors = new ArrayList<>();
		DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");
		Integer progId = mailBody.getProgId();
		String prgName = mailBody.getProgName();
		String subject = "Program #" + progId + "-" + prgName;
		String appURL = programUrl + progId;
		StringBuffer message = new StringBuffer();
		String userId = user.getUserId();
		
		String rskLevel = mailBody.getRskLevel();
		String mtgtnLevel = mailBody.getMtgtnLevel();
		
		String greyBackClor = "#F6F6F6";
		String whiteBackClor = "white";
		
		String tdStyle = "font-size:12px;font-weight:normal;font-family:Verdana, Arial, sans-serif;border-top: 1px solid #bbbbbb;";
		String innerTDStyle = tdStyle + "padding-bottom: 8px;padding-top: 8px;padding-left: 10px;";
		
		String notAvailStyle = "color:#bd2e28;font-size:12px;font-weight:normal;font-family:Verdana, Arial, sans-serif;border-top: 1px solid #bbbbbb;padding-bottom: 8px;padding-top: 8px;padding-left: 10px;";
	
		message.append("<font style='color:blue;font-size:14px;font-weight:bold;font-family:Verdana, Arial, sans-serif'>Message from Sender: '" + mailBody.getMessage() + "'</font><br><br>");
		message.append("Please review below risk details and take action if needed. For more details contact the sender copied in this email.<br><br>");
	
		message.append("<table border='0' width='80%'>");
		
		message.append("<tr>");
		message.append("<td bgcolor='"+greyBackClor+"' style='" + innerTDStyle + "' width:30%;><b>Mitigation Owner</b></td>");
		message.append("<td bgcolor='"+greyBackClor+"' colspan='3' style='word-break: break-word;" + innerTDStyle + "' width:70%;>" + mailBody.getMtgtnOwnerName() + "</td>");
		message.append("</tr>");
		
		message.append("<tr>");
		message.append("<td bgcolor='"+whiteBackClor+"' style='" + innerTDStyle + "' width:30%;><b>Risk Level</b></td>");
		if(mailBody.getRskScore() > 0) {
			if(rskLevel.equalsIgnoreCase("L")) 
				message.append("<td bgcolor='"+whiteBackClor+"' style='text-align: left;font-weight:bold; color:white;background: #367C2B;" + innerTDStyle + "' >"+ "<b style=' display: block;' >" + rskLevel + "</b>" + "</td>" );
			else if(rskLevel.equalsIgnoreCase("M")) 
				message.append("<td bgcolor='"+whiteBackClor+"' style='text-align: left;font-weight:bold; color: black; background: #FFDE00;" + innerTDStyle + "'>"+ "<b style=' display: block;' >" + rskLevel + "</b>" + "</td>" );
			else if(rskLevel.equalsIgnoreCase("H")) 
				message.append("<td bgcolor='"+whiteBackClor+"' style='text-align: left;font-weight:bold; color: white; background: #C21020; " + innerTDStyle + "' >"+ "<b style='display: block;' >" + rskLevel + "</b>" + "</td>" );
		}else 
			message.append("<td bgcolor='"+whiteBackClor+"' style='" + notAvailStyle + "' >" + "N/A" + "</td>");
		
		message.append("<td bgcolor='"+whiteBackClor+"' colspan='2' style='" + innerTDStyle + "' width:60%;></td>");
		
		message.append("</tr>");
		
		message.append("<tr>");
		message.append("<td bgcolor='"+greyBackClor+"' style='" + innerTDStyle + "' width:30%;><b>Mitigated Level</b></td>");
		if( mailBody.getMtgtnScore() > 0) {
			if(mtgtnLevel.equalsIgnoreCase("L"))
				message.append("<td bgcolor='"+greyBackClor+"' style='text-align: left;font-weight:bold; color:white;background: #367C2B; " + innerTDStyle + "' >"+ "<b style='display: block;' >" + mtgtnLevel + "</b>" + "</td>" );
			else if(mtgtnLevel.equalsIgnoreCase("M"))
				message.append("<td bgcolor='"+greyBackClor+"' style='text-align: left;font-weight:bold; color: black; background: #FFDE00; " + innerTDStyle + "'>"+ "<b style='display: block;' >" + mtgtnLevel + "</b>" + "</td>" );
			else if(mtgtnLevel.equalsIgnoreCase("H"))
				message.append("<td bgcolor='"+greyBackClor+"' style='text-align: left;font-weight:bold; color: white; background: #C21020; " + innerTDStyle + "' >"+ "<b style='display: block;' >" + mtgtnLevel + "</b>" + "</td>" );
		}else
			message.append("<td bgcolor='"+greyBackClor+"' style='" + notAvailStyle + "' >" + "N/A" + "</td>");
		
		message.append("<td bgcolor='"+greyBackClor+"' colspan='2' style='" + innerTDStyle + "' width:60%;></td>");
		
		message.append("</tr>");
		
		message.append("<tr>");
		message.append("<td bgcolor='"+whiteBackClor+"' style='" + innerTDStyle + "' width:30%;><b>Risk Title</b></td>");
		message.append("<td bgcolor='"+whiteBackClor+"' colspan='3' style='word-break: break-word;" + innerTDStyle + "' width:70%;>" + mailBody.getRiskTitle() + "</td>");
		message.append("</tr>");
		
		message.append("<tr>");
		message.append("<td bgcolor='"+greyBackClor+"' style='" + innerTDStyle + "' width:30%;><b>If</b></td>");
		message.append("<td bgcolor='"+greyBackClor+"' colspan='3' style='word-break: break-word;" + innerTDStyle + "' width:70%;>" + mailBody.getCauseIf() + "</td>");
		message.append("</tr>");
		
		message.append("<tr>");
		message.append("<td bgcolor='"+whiteBackClor+"' style='" + innerTDStyle + "' width:30%;><b>Then</b></td>");
		message.append("<td bgcolor='"+whiteBackClor+"' colspan='3' style='word-break: break-word;" + innerTDStyle + "' width:70%;>" + mailBody.getEffectThen() + "</td>");
		message.append("</tr>");
		
		message.append("<tr>");
		message.append("<td bgcolor='"+greyBackClor+"' style='" + innerTDStyle + "' width:30%;><b>Mitigation Plan</b></td>");
		message.append("<td bgcolor='"+greyBackClor+"' colspan='3' style='word-break: break-word;" + innerTDStyle + "' width:70%;>" + mailBody.getMtgtnPlan() + "</td>");
		message.append("</tr>");
		
		message.append("<tr>");
		message.append("<td bgcolor='"+whiteBackClor+"' style='" + innerTDStyle + "' width:30%;><b>Target Closure</b></td>");
		message.append("<td bgcolor='"+whiteBackClor+"' colspan='3' style='" + innerTDStyle + "' width:70%;>" + dateFormat.format(mailBody.getTargetClosure()) + "</td>");
		message.append("</tr>");
		
		message.append("<tr>");
		message.append("<td bgcolor='"+greyBackClor+"' style='" + innerTDStyle + "' width:30%;><b>Mitigation Status</b></td>");
		if(mailBody.getMtgtnStatus()!=null && !mailBody.getMtgtnStatus().isEmpty()) {
			message.append("<td bgcolor='"+greyBackClor+"' colspan='3' style='" + innerTDStyle + "' width:70%;>" + mailBody.getMtgtnStatus() + "</td>");
		} else {
			message.append("<td bgcolor='"+greyBackClor+"' colspan='3' style='" + notAvailStyle + "' width:70%;>" + "N/A" + "</td>");
		}
		message.append("</tr>");
		
	
		
		message.append("<tr>");
		message.append("<td bgcolor='"+whiteBackClor+"' style='" + innerTDStyle + "' width:30%;><b>Comments</b></td>");
		if(mailBody.getComments()!=null && !mailBody.getComments().isEmpty()) {
			message.append("<td bgcolor='"+whiteBackClor+"' colspan='3' style='word-break: break-word;" + innerTDStyle + "' width:70%;>" +  mailBody.getComments() + "</td>");
		} else {
			message.append("<td bgcolor='"+whiteBackClor+"' colspan='3' style='" + notAvailStyle + "' width:70%;>" + "N/A" + "</td>");
		}
		
		message.append("</tr>");
				
		message.append("</table><br><hr>");
		message.append("Click <i><a href='" + appURL + "'>here</a></i> to access Program Risk Management Program #" + progId + "-" + prgName + "<br><br>");
		message.append("******************** This is an automated email - DO NOT REPLY ********************");

		try {
			EmailUtility.sendEmail(mailBody.getMtgtnOwner(), userId, subject, message.toString());
		} catch (Exception e) {
			LOGGER.error("Error sendEmailToMitigationOwner");
		}	
	//	return new Response<>(Status.SUCCESS, "Mail send successfully.", errors.isEmpty() ? null : errors );
	}

	@Override
	public PrgRiskDetails getAllPrgRiskCategory(Integer prjId) {
		List<RiskMitigation> r = (List<RiskMitigation>)this.getAllRiskByProjectId(prjId);
		List<SubDesignTeam> subDesignTeam = (List<SubDesignTeam>)teamService.getTeamByPrjId(prjId);
		
		List<SubDesignTeam> subTeamlist = subDesignTeam.stream().filter(team -> team.getType().equals('S')).map(team -> team).collect(Collectors.toList());
		 
		List<SubDesignTeam> designTeamlist = subDesignTeam.stream().filter(team -> team.getType().equals('D')).map(team -> team).collect(Collectors.toList());
		
		List<RiskCategoryData> riskCategoryData = riskCategoryService.getRiskCategoryImpactDesc(prjId);
		
		
		return new PrgRiskDetails(r, subTeamlist, designTeamlist , riskCategoryData);
	}

	@Override
	public byte[] downloadImage(ImageData imageData) {
		String path= System.getProperty("IafMOD");
		path+= path.endsWith(File.separator) ?"":File.separator;
		path+="docs"+File.separator+"PRA"+File.separator;
		path+= "PID-"+imageData.getProjId()+File.separator+"RID-"+imageData.getRiskId();
		
		System.out.println("Complete folder path-------------->"+path);
		String extension =".jpg"; 
		String fileName = "PID" +imageData.getProjId()+"_RID" +imageData.getRiskId()+"_IID-" +imageData.getImgId()+extension;
		File file = new File(path +  File.separator + fileName);
		
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		InputStream in;
		try {
			in = new FileInputStream(file);
			
			byte[] buf = new byte[1024];
			int n = 0;
			while (-1!=(n=in.read(buf)))
			{
			   out.write(buf, 0, n);
			}
			out.close();
			in.close();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		byte[] response = out.toByteArray();
		return response;		
	}

	@Override
	@Transactional(value="prmTransactionManager",readOnly=false,propagation=Propagation.REQUIRED) 
	public void deleteRiskByPrjId(Integer prjId) {
		riskRepository.deleteRiskByPrjId(prjId);
		
	}

	@Override
	@Transactional(value="prmTransactionManager",readOnly=false,propagation=Propagation.REQUIRED) 
	public void deleteMgtnPlanByPrjId(Integer prjId) {
		mtgtnRepository.deleteMgtnPlanByPrjId(prjId);
		
	}	
	
	
	
	
}
