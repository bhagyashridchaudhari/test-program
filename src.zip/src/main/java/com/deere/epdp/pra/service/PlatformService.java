package com.deere.epdp.pra.service;

import java.util.List;

import com.deere.epdp.pra.domain.epdp.Platform;

public interface PlatformService {
	
	void init();
	
	List<Platform> getAllPlatform();

	String getPlatformNameById(Integer id);

}
