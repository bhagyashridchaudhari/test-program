package com.deere.epdp.pra.domain.prm;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "mtgtn_plan")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MitigationPlan implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer mtgtnId;

	@Column(name = "title")
	private String mtgtnTitle;

	@Column(name = "dsc")
	private String mtgtnDesc;
	
	@Column(name = "trgt_closure")
	private Date trgtClosure;

	@Column(name = "nxt_rview")
	private Date nxtReview;
	
	@Column(name = "owner")
	private String mtgtnOwner;

	@Column(name = "owner_subfn")
	private Integer mtgtnSubFunction;
	
	@Column(name = "sub_team")
	private Integer mtgtnSubTeamId;
	
	@Column(name = "design_team")
	private Integer mtgtnDesignTeamId;
	
	@Column(name = "sts_id", nullable = false)
	private Integer mtgtnStatusId;
	
	@Column(name = "prblty_id", nullable = false)
	private Integer  mtgtnPrbltyId;
	
	@Column(name = "impact_id", nullable = false)
	private Integer mtgtnImpactId;
	
	@OneToOne
	@JoinColumn(name = "rsk_id", nullable = false)
	private ProjectRisk risk;
	
	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String mtgtnLastUpdtBy;

	@JsonIgnore
	@Column(name = "last_updt_ts", nullable = false)
	private Timestamp mtgtnLastUpdtTs;
	
	@Column(name = "mtgtn_level")
	private Integer mtgtnLevel;
	
	@Column(name = "mtgtn_score")
	private Integer mtgtnScore;

	public Integer getMtgtnId() {
		return mtgtnId;
	}

	public void setMtgtnId(Integer mtgtnId) {
		this.mtgtnId = mtgtnId;
	}

	public String getMtgtnTitle() {
		return mtgtnTitle;
	}

	public void setMtgtnTitle(String mtgtnTitle) {
		this.mtgtnTitle = mtgtnTitle;
	}

	public String getMtgtnDesc() {
		return mtgtnDesc;
	}

	public void setMtgtnDesc(String mtgtnDesc) {
		this.mtgtnDesc = mtgtnDesc;
	}

	public Date getTrgtClosure() {
		return trgtClosure;
	}

	public void setTrgtClosure(Date trgtClosure) {
		this.trgtClosure = trgtClosure;
	}

	public Date getNxtReview() {
		return nxtReview;
	}

	public void setNxtReview(Date nxtReview) {
		this.nxtReview = nxtReview;
	}

	public String getMtgtnOwner() {
		return mtgtnOwner;
	}

	public void setMtgtnOwner(String mtgtnOwner) {
		this.mtgtnOwner = mtgtnOwner;
	}

	public Integer getMtgtnSubFunction() {
		return mtgtnSubFunction;
	}

	public void setMtgtnSubFunction(Integer mtgtnSubFunction) {
		this.mtgtnSubFunction = mtgtnSubFunction;
	}

	public Integer getMtgtnSubTeamId() {
		return mtgtnSubTeamId;
	}

	public void setMtgtnSubTeamId(Integer mtgtnSubTeamId) {
		this.mtgtnSubTeamId = mtgtnSubTeamId;
	}

	public Integer getMtgtnDesignTeamId() {
		return mtgtnDesignTeamId;
	}

	public void setMtgtnDesignTeamId(Integer mtgtnDesignTeamId) {
		this.mtgtnDesignTeamId = mtgtnDesignTeamId;
	}

	public Integer getMtgtnStatusId() {
		return mtgtnStatusId;
	}

	public void setMtgtnStatusId(Integer mtgtnStatusId) {
		this.mtgtnStatusId = mtgtnStatusId;
	}

	public Integer getMtgtnPrbltyId() {
		return mtgtnPrbltyId;
	}

	public void setMtgtnPrbltyId(Integer mtgtnPrbltyId) {
		this.mtgtnPrbltyId = mtgtnPrbltyId;
	}

	public Integer getMtgtnImpactId() {
		return mtgtnImpactId;
	}

	public void setMtgtnImpactId(Integer mtgtnImpactId) {
		this.mtgtnImpactId = mtgtnImpactId;
	}

	public ProjectRisk getRisk() {
		return risk;
	}

	public void setRisk(ProjectRisk risk) {
		this.risk = risk;
	}

	public String getMtgtnLastUpdtBy() {
		return mtgtnLastUpdtBy;
	}

	public void setMtgtnLastUpdtBy(String mtgtnLastUpdtBy) {
		this.mtgtnLastUpdtBy = mtgtnLastUpdtBy;
	}

	public Timestamp getMtgtnLastUpdtTs() {
		return mtgtnLastUpdtTs;
	}

	public void setMtgtnLastUpdtTs(Timestamp mtgtnLastUpdtTs) {
		this.mtgtnLastUpdtTs = mtgtnLastUpdtTs;
	}

	public Integer getMtgtnLevel() {
		return mtgtnLevel;
	}

	public void setMtgtnLevel(Integer mtgtnLevel) {
		this.mtgtnLevel = mtgtnLevel;
	}

	public Integer getMtgtnScore() {
		return mtgtnScore;
	}

	public void setMtgtnScore(Integer mtgtnScore) {
		this.mtgtnScore = mtgtnScore;
	}

	public MitigationPlan(Integer mtgtnId, String mtgtnTitle, Date trgtClosure, Date nxtReview,
			String mtgtnOwner, Integer mtgtnSubFunction, Integer mtgtnSubTeamId, Integer mtgtnDesignTeamId,
			Integer mtgtnStatusId, Integer mtgtnPrbltyId, Integer mtgtnImpactId, ProjectRisk risk,
			String mtgtnLastUpdtBy, Timestamp mtgtnLastUpdtTs, Integer mtgtnLevel, Integer mtgtnScore) {
		super();
		this.mtgtnId = mtgtnId;
		this.mtgtnTitle = mtgtnTitle;
		this.trgtClosure = trgtClosure;
		this.nxtReview = nxtReview;
		this.mtgtnOwner = mtgtnOwner;
		this.mtgtnSubFunction = mtgtnSubFunction;
		this.mtgtnSubTeamId = mtgtnSubTeamId;
		this.mtgtnDesignTeamId = mtgtnDesignTeamId;
		this.mtgtnStatusId = mtgtnStatusId;
		this.mtgtnPrbltyId = mtgtnPrbltyId;
		this.mtgtnImpactId = mtgtnImpactId;
		this.risk = risk;
		this.mtgtnLastUpdtBy = mtgtnLastUpdtBy;
		this.mtgtnLastUpdtTs = mtgtnLastUpdtTs;
		this.mtgtnLevel = mtgtnLevel;
		this.mtgtnScore = mtgtnScore;
	}

	public MitigationPlan() {
		super();
	}
	
	
	
}
