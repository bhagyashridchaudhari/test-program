package com.deere.epdp.pra.domain.prm;
import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name="preferences")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Preferences implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id 
	@Column(name="id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)  
	private Integer id;
	
	@Column(name="usr_id")
	private String userId ;
	
	@Column(name="prgm_id")
	private Integer progId ;
	
	@Column(name="dflt_prf")
	private char defaultPref ;

	@Column(name="sel_clmns")
	private String selectedColumns;
	
	@Column(name="lst_updt_by") 
	private String lastUpdatedBy;
	
	@Column(name="last_updt_ts")
	private Date lastUpdatedTimestamp;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getSelectedColumns() {
		return selectedColumns;
	}

	public void setSelectedColumns(String selectedColumns) {
		this.selectedColumns = selectedColumns;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Integer getProgId() {
		return progId;
	}

	public void setProgId(Integer progId) {
		this.progId = progId;
	}

	public char getDefaultPref() {
		return defaultPref;
	}

	public void setDefaultPref(char defaultPref) {
		this.defaultPref = defaultPref;
	}

	public Date getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Date lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public Preferences() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Preferences(Integer id, String userId, Integer progId, char defaultPref, String selectedColumns,
			String lastUpdatedBy, Date lastUpdatedTimestamp) {
		super();
		this.id = id;
		this.userId = userId;
		this.progId = progId;
		this.defaultPref = defaultPref;
		this.selectedColumns = selectedColumns;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}
	
	public Preferences(String userId, Integer progId, char defaultPref, String selectedColumns,
			String lastUpdatedBy, Date lastUpdatedTimestamp) {
		super();
		this.userId = userId;
		this.progId = progId;
		this.defaultPref = defaultPref;
		this.selectedColumns = selectedColumns;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}
	
	
	
}