package com.deere.epdp.pra.domain.user;

import java.io.Serializable;
import java.util.function.Function;

import org.apache.solr.client.solrj.beans.Field;
import org.springframework.data.annotation.Id;
import org.springframework.data.solr.core.mapping.SolrDocument;

import com.fasterxml.jackson.annotation.JsonIgnore;

@SolrDocument(solrCoreName = "user")
public class UserSolr implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Field("USER_ID")
	private String userId;

	@JsonIgnore
	@Field("FIRST_NAME")
	private String fName;

	@JsonIgnore
	@Field("LAST_NAME")
	private String lName;

	@JsonIgnore
	@Field("INITIAL1")
	private String mName;

	@JsonIgnore
	@Field("STATUS")
	private String status;

	
	@Field("USER_TITLE")
	private String userTitle;

	@JsonIgnore
	@Field("USER_TYP")
	private String userType;
	
	@JsonIgnore
	@Field("USER_TYP_CD")
	private String userTypeCd;

	@JsonIgnore
	@Field("EMAIL")
	private String email;

	public UserSolr() {
		super();
	}

	public UserSolr(String userId, String fName, String lName) {
		super();
		this.userId = userId;
		this.fName = fName;
		this.lName = lName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getmName() {
		return mName;
	}

	public void setmName(String mName) {
		this.mName = mName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
	public void set(String userTitle) {
		this.userTitle = userTitle;
	}
	
	public String getUserTitle() {
		return this.userTitle != null && !this.userTitle.isEmpty() ? this.userTitle.trim() : this.userType.trim();
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getUserTypeCd() {
		return userTypeCd;
	}

	public void setUserTypeCd(String userTypeCd) {
		this.userTypeCd = userTypeCd;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFullName() {
		return new StringBuilder(this.lName).append(" ").append(this.fName).append(" ").append(this.mName != null ? this.mName : "").toString().trim();
	}

	public <R> R map(Function<UserSolr, R> function) {
		return function.apply(this);
	}

}