package com.deere.epdp.pra.domain.prm;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "prg_std_risk_ctgry_impact")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CustomRiskCategoryImpact implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private CustomRiskCategoryImpactId id;
	
	@Column(name = "impact_dsc")
	private String impactDsc;
	
	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdtBy;
	
	@JsonIgnore
	@Column(name = "last_updt_ts")
	private Timestamp lastUpdtTs;
	
	@Column(name = "active")
    private char active;
	

	public String getImpactDsc() {
		return impactDsc;
	}
	public void setImpactDsc(String impactDsc) {
		this.impactDsc = impactDsc;
	}
	public String getLastUpdtBy() {
		return lastUpdtBy;
	}
	public void setLastUpdtBy(String lastUpdtBy) {
		this.lastUpdtBy = lastUpdtBy;
	}
	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}
	public void setLastUpdtTs(Timestamp lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}

	
	public char getActive() {
		return active;
	}
	public void setActive(char active) {
		this.active = active;
	}
	public CustomRiskCategoryImpact() {}
	public CustomRiskCategoryImpact(CustomRiskCategoryImpactId id, String impactDsc, String lastUpdtBy,
			Timestamp lastUpdtTs,char active) {
		super();
		this.id = id;
		this.impactDsc = impactDsc;
		this.lastUpdtBy = lastUpdtBy;
		this.lastUpdtTs = lastUpdtTs;
		this.active = active;
	}

	public CustomRiskCategoryImpactId getId() {
		return id;
	}
	public void setId(CustomRiskCategoryImpactId id) {
		this.id = id;
	}

	@Embeddable
	public static class CustomRiskCategoryImpactId implements Serializable {
		
		private static final long serialVersionUID = 1L;
		 	
		@Column(name = "risk_cat_id")
		private Integer ctgryId;

		@Column(name="impact_id")
		private Integer impactId;
		
		@Column(name="prgm_id")
		private Integer progId;
		
		public CustomRiskCategoryImpactId(Integer ctgryId, Integer impactId, Integer progId) {
			super();
			this.ctgryId = ctgryId;
			this.impactId = impactId;
			this.progId = progId;
		}

		public CustomRiskCategoryImpactId() { }

		public Integer getCtgryId() {
			return ctgryId;
		}

		public void setCtgryId(Integer ctgryId) {
			this.ctgryId = ctgryId;
		}

		public Integer getImpactId() {
			return impactId;
		}

		public void setImpactId(Integer impactId) {
			this.impactId = impactId;
		}

		public Integer getProgId() {
			return progId;
		}

		public void setProgId(Integer progId) {
			this.progId = progId;
		}

		public static long getSerialversionuid() {
			return serialVersionUID;
		}
	}
	

}
