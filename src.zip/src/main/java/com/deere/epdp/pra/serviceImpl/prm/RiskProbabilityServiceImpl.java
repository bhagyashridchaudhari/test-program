package com.deere.epdp.pra.serviceImpl.prm;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deere.epdp.pra.domain.prm.RiskProbability;
import com.deere.epdp.pra.repo.prm.RiskProbabilityRepository;
import com.deere.epdp.pra.service.prm.RiskProbabilityService;

@Service
public class RiskProbabilityServiceImpl implements RiskProbabilityService{

	@Autowired
	private RiskProbabilityRepository probabilityRepository;
	
	private Map<Integer, RiskProbability> probabilityMap;
	
	@PostConstruct
	public void init() {
		probabilityMap = StreamSupport.stream(probabilityRepository.findAll().spliterator(), false)
				.collect(Collectors.toMap(RiskProbability::getPrbltyId, Function.identity()));
	}

	@Override
	public List<RiskProbability> getAllRiskProbability() {
		return probabilityMap.values().stream().sorted(Comparator.comparing(RiskProbability::getPrbltyName)).collect(Collectors.toList());
	}

	@Override
	public String getRiskProbabilityById(Integer id) {
		RiskProbability probability = probabilityMap.get(id);
		return probability != null ? probability.getPrbltyName() : null;
	}

}
