package com.deere.epdp.pra.service;

import java.util.List;

import com.deere.epdp.pra.domain.epdp.SubProcess;

public interface SubProcessService {
	void init();

	List<SubProcess> getAllSubProcess();

	SubProcess getSubProcessById(Integer id);
}
