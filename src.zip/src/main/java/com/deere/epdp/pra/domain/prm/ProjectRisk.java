package com.deere.epdp.pra.domain.prm;

import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "risk")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProjectRisk {
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer riskId;
	
	@Column(name = "title", length = 50, nullable = false)
	private String title;
	
	@Column(name="dsc_if", length = 250)
	private String dscCause;
	
	@Column(name="effect_thn", length = 250)
	private String dscEffect;
	
	@Column(name = "prgm_id", nullable = false)
	private Integer prgmId;

	@Column(name = "rsk_ctgry_id", nullable = false)
	private Integer rskCtgryId;
	
	@Column(name = "prblty_id", nullable = false)
	private Integer prbltyId;
	
	@Column(name = "impact_id", nullable = false)
	private Integer impactId;
	
	@Column(name = "rs_strtrgy_id")
	private Integer rsStrtrgyId;
	
	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdtBy;
	
	@JsonIgnore
	@Column(name = "last_updt_ts")
	private Timestamp lastUpdtTs;
	
	@Column(name = "created_by", nullable = false, updatable = false)
	private String createdBy;

	@Column(name = "created_ts", nullable = false, updatable = false)
	private Timestamp createdTs;
	
	@OneToOne(fetch = FetchType.LAZY, cascade =  CascadeType.ALL, mappedBy = "risk")
	private MitigationPlan mitigationPlan;
	
	@Column(name = "rsk_level")
	private Integer rskLevel;
	
	@Column(name = "rsk_score")
	private Integer rskScore;
	
	@Column(name = "comment")
	private String comment;
	
/*	@Transient
	private String rskCtgryName;
	
	@Transient
	private String prbltyName;
	
	@Transient
	private String impactName;
	
	@Transient
	private String rsStrtrgyName;
	
	**/
	@Column(name = "rsk_ctgry_src")
	private Integer categorySource;
	
	public ProjectRisk(Integer riskId, String title, String dscCause, String dscEffect, Integer prgmId, Integer rskCtgryId, Integer prbltyId,
			Integer impactId, Integer rsStrtrgyId, String lastUpdtBy, Timestamp lastUpdtTs, Integer rskLevel, Integer rskScore,
			String comment,Integer categorySource
		// String rskCtgryName, String prbltyName,	String impactName, String rsStrtrgyName,
		// MitigationPlan mitigationPlan
			) {
		super();
		this.riskId = riskId;
		this.title = title;
		this.dscCause = dscCause;
		this.dscEffect = dscEffect;
		this.prgmId = prgmId;
		this.rskCtgryId = rskCtgryId;
		this.prbltyId = prbltyId;
		this.impactId = impactId;
		this.rsStrtrgyId = rsStrtrgyId;
		this.lastUpdtBy = lastUpdtBy;
		this.lastUpdtTs = lastUpdtTs;
		this.rskLevel = rskLevel;
		this.rskScore = rskScore;
		this.comment = comment;
	//	this.rskCtgryName = rskCtgryName;
	//	this.prbltyName = prbltyName;
	//	this.impactName = impactName;
	//	this.rsStrtrgyName = rsStrtrgyName;
	//	this.mitigationPlan = mitigationPlan;
		this.categorySource = categorySource;
	}

	public Integer getRiskId() {
		return riskId;
	}

	public void setRiskId(Integer riskId) {
		this.riskId = riskId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDscCause() {
		return dscCause;
	}

	public void setDscCause(String dscCause) {
		this.dscCause = dscCause;
	}

	public String getDscEffect() {
		return dscEffect;
	}

	public void setDscEffect(String dscEffect) {
		this.dscEffect = dscEffect;
	}

	public Integer getPrgmId() {
		return prgmId;
	}

	public void setPrgmId(Integer prgmId) {
		this.prgmId = prgmId;
	}

	public Integer getRskCtgryId() {
		return rskCtgryId;
	}

	public void setRskCtgryId(Integer rskCtgryId) {
		this.rskCtgryId = rskCtgryId;
	}

	public Integer getPrbltyId() {
		return prbltyId;
	}

	public void setPrbltyId(Integer prbltyId) {
		this.prbltyId = prbltyId;
	}

	public Integer getImpactId() {
		return impactId;
	}

	public void setImpactId(Integer impactId) {
		this.impactId = impactId;
	}

	public Integer getRsStrtrgyId() {
		return rsStrtrgyId;
	}

	public void setRsStrtrgyId(Integer rsStrtrgyId) {
		this.rsStrtrgyId = rsStrtrgyId;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public void setLastUpdtBy(String lastUpdtBy) {
		this.lastUpdtBy = lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}

	public void setLastUpdtTs(Timestamp lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedTs() {
		return createdTs;
	}

	public void setCreatedTs(Timestamp createdTs) {
		this.createdTs = createdTs;
	}

	public MitigationPlan getMitigationPlan() {
		return mitigationPlan;
	}

	public void setMitigationPlan(MitigationPlan mitigationPlan) {
		this.mitigationPlan = mitigationPlan;
	}

	public Integer getRskLevel() {
		return rskLevel;
	}

	public void setRskLevel(Integer rskLevel) {
		this.rskLevel = rskLevel;
	}

	public Integer getRskScore() {
		return rskScore;
	}

	public void setRskScore(Integer rskScore) {
		this.rskScore = rskScore;
	}
	
	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	
	
	public Integer getCategorySource() {
		return categorySource;
	}

	public void setCategorySource(Integer categorySource) {
		this.categorySource = categorySource;
	}

	public ProjectRisk() {
		super();
	}
	
	
}
