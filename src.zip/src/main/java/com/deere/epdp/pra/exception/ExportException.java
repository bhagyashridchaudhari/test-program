package com.deere.epdp.pra.exception;

/**
 * @author RM43492
 * @version 1.0
 * @since 2017-05-29
 */
public class ExportException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public ExportException(String message, Throwable cause) {
		super(message, cause);
	}

	public ExportException(String message) {
		super(message);
	}
}
