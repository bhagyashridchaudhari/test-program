package com.deere.epdp.pra.domain.epdp;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "product_family")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductFamily implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "prdfmy_id")
	private Integer prdfmyId;

	@Column(name = "prdfmy_nm", nullable = false)
	private String prdfmyNm;

	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdtBy;

	@JsonIgnore
	@Column(name = "last_updt_ts")
	private Timestamp lastUpdtTs;

	public Integer getPrdfmyId() {
		return prdfmyId;
	}

	public void setPrdfmyId(Integer prdfmyId) {
		this.prdfmyId = prdfmyId;
	}

	public String getPrdfmyNm() {
		return prdfmyNm;
	}

	public void setPrdfmyNm(String prdfmyNm) {
		this.prdfmyNm = prdfmyNm;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public void setLastUpdtBy(String lastUpdtBy) {
		this.lastUpdtBy = lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}

	public void setLastUpdtTs(Timestamp lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}
}