package com.deere.epdp.pra.service.prm;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.deere.epdp.pra.model.ImageData;
import com.deere.epdp.pra.model.MitigationEmail;
import com.deere.epdp.pra.model.PrgRiskDetails;
import com.deere.epdp.pra.model.Response;
import com.deere.epdp.pra.model.RiskImageData;
import com.deere.epdp.pra.model.RiskMitigation;


public interface  ProjectRiskService {

	Response<RiskMitigation> saveRisk(RiskMitigation rskMtgtn);

	RiskMitigation getRiskById(Integer id);

	Iterable<RiskMitigation> getAllRiskByProjectId(Integer prjId);

	Response<String> deleteRisk(Integer id);
	
	Response<String> sendEmailToMitigationOwner(List<MitigationEmail> mailBody);
	
	public void uploadImages(MultipartFile mFile, Integer progId, Integer riskId, Integer imgId);
	
	public List<String>  getImage(Integer progId, Integer riskId);
	
	public List<RiskImageData>  getImage2(Integer progId, Integer riskId);

	Response<String> deleteImage(Integer progId, Integer riskId, Integer imgId);

	PrgRiskDetails getAllPrgRiskCategory(Integer prjId);

	byte[] downloadImage(ImageData imageData);
	
	public void deleteRiskByPrjId(Integer prjId);
	
    public void deleteMgtnPlanByPrjId(Integer prjId);
	
}