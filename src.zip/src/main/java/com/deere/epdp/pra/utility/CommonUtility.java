package com.deere.epdp.pra.utility;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.servlet.http.HttpServletRequest;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.http.HttpHeaders;
import org.springframework.util.Assert;

import com.deere.dsfj.utility.ServletUtility;
import com.deere.epdp.pra.domain.epdp.ProjectStatus;
import com.deere.epdp.pra.literals.PRALiterals;
import com.deere.epdp.pra.model.ExcelData.Style;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CommonUtility {
	
	private CommonUtility() {
		super();
	}

	public static Date getDate() {
		return new Date();
	}

	public static Date getDateWithoutTime() {
		Calendar calendar = Calendar.getInstance();
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		return calendar.getTime();
	}

	public static Timestamp getCurrentTime() {
		return new Timestamp(System.currentTimeMillis());
	}

	public static String convertToString(final Date date) {
		return date != null ? new SimpleDateFormat("dd-MMM-yyyy").format(date) : null;
	}

	public static String getAuthorisation(final String userName, final String password) {
		String plainCreds = userName + ":" + password;
		byte[] plainCredsBytes = plainCreds.getBytes();
		byte[] base64CredsBytes = Base64.encodeBase64(plainCredsBytes);
		String base64Creds = new String(base64CredsBytes);
		return "Basic " + base64Creds;
	}

	public static HttpHeaders getAuthorisationHeader(final String userName, final String password) {
		HttpHeaders headers = new HttpHeaders();
		headers.add("Authorization", getAuthorisation(userName, password));
		return headers;
	}

	public static double similarity(String s1, String s2) {
		if (s1 == null || s2 == null)
			return 0;
		String longer = s1;
		String shorter = s2;
		if (s1.length() < s2.length()) {
			longer = s2;
			shorter = s1;
		}
		int longerLength = longer.length();
		if (longerLength == 0) {
			return 1.0;
		}
		return (longerLength - editDistance(longer, shorter)) / (double) longerLength;

	}

	// Example implementation of the Levenshtein Edit Distance See
	private static int editDistance(String s1, String s2) {
		s1 = s1.toLowerCase();
		s2 = s2.toLowerCase();

		int[] costs = new int[s2.length() + 1];
		for (int i = 0; i <= s1.length(); i++) {
			int lastValue = i;
			for (int j = 0; j <= s2.length(); j++) {
				if (i == 0)
					costs[j] = j;
				else {
					if (j > 0) {
						int newValue = costs[j - 1];
						if (s1.charAt(i - 1) != s2.charAt(j - 1))
							newValue = Math.min(Math.min(newValue, lastValue), costs[j]) + 1;
						costs[j - 1] = lastValue;
						lastValue = newValue;
					}
				}
			}
			if (i > 0)
				costs[s2.length()] = lastValue;
		}
		return costs[s2.length()];
	}
	
	public static <T> List<T> toList(final Iterable<T> iterable) {
		return StreamSupport.stream(iterable.spliterator(), false).collect(Collectors.toList());
	}
 
	public static CellStyle getCellStyle(Workbook workbook, Style style) {
		Assert.notNull(workbook, "Workbook should not be null");
		CellStyle s = null;
		if (style != null) {
			Font f = null;
			if (style.getBold() != null) {
				f = workbook.createFont();
				f.setBold(style.getBold());
			}
			if (style.getSize() != null) {
				f = f == null ? workbook.createFont() : f;
				f.setFontHeightInPoints(style.getSize());
			}
			if (style.getColor() != null) {
				f = f == null ? workbook.createFont() : f;
				f.setColor(style.getColor().getIndex());
			}
			if (style.getColor() != null) {
				f = f == null ? workbook.createFont() : f;
				f.setColor(style.getColor().getIndex());
			}
			if (f != null) {
				s = workbook.createCellStyle();
				s.setFont(f);
			}
			if(style.getWrap() != null) {
				s = s == null ? workbook.createCellStyle() : s;
				s.setWrapText(style.getWrap());
			}
			if (style.getBorder() != null) {
				s = s == null ? workbook.createCellStyle() : s;
				s.setBorderBottom(HSSFCellStyle.BORDER_THIN);
				s.setBorderTop(HSSFCellStyle.BORDER_THIN);
				s.setBorderRight(HSSFCellStyle.BORDER_THIN);
				s.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			}
			if (style.getBgcolor() != null) {
				s = s == null ? workbook.createCellStyle() : s;
				s.setFillForegroundColor(style.getBgcolor().getIndex());
				s.setFillPattern(CellStyle.SOLID_FOREGROUND);
			}
			
			if (style.getAlign() != null) {
				s = s == null ? workbook.createCellStyle() : s;
				s.setAlignment(style.getAlign().getValue());
				s.setVerticalAlignment(CellStyle.VERTICAL_TOP);
			}
		}
		return s;
	}

	public static boolean changeStyle(Style style, Style parentStyle) {
		if (style == null) {
			return false;
		}
		else if (parentStyle == null) {
			return true;
		} else {
			boolean change = false;

			if (style.getBold() != null)
				change = true;
			else
				style.setBold(parentStyle.getBold());

			if (style.getSize() != null)
				change = true;
			else
				style.setSize(parentStyle.getSize());

			if (style.getColor() != null)
				change = true;
			else
				style.setColor(parentStyle.getColor());

			if (style.getWrap() != null)
				change = true;
			else
				style.setWrap(parentStyle.getWrap());

			if (style.getBorder() != null)
				change = true;
			else
				style.setBorder(parentStyle.getBorder());

			if (style.getBgcolor() != null)
				change = true;
			else
				style.setBgcolor(parentStyle.getBgcolor());

			if (style.getAlign()!= null)
				change = true;
			else
				style.setAlign(parentStyle.getAlign());
			
			return change;
		}
	}

	public static final <T> T convert(Object fromValue, Class<T> clz) {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		return objectMapper.convertValue(fromValue, clz);
	}

	public static final String getUserId(HttpServletRequest request) {
		String smUserId = request.getSession() != null
				? (String) request.getSession().getAttribute(ServletUtility.getUserIdHeaderKey()) : null;
		smUserId = smUserId != null && !smUserId.isEmpty() ? smUserId : ServletUtility.getUserID(request);
		return smUserId == null ? null : smUserId.toUpperCase();
	}
	
	public static ProjectStatus setMappedStatusId(final ProjectStatus status) {
		status.setMappedIds(PRALiterals.STATUS_ID_MAP.get(status.getStatusId()));
		return status;
	}
}
