package com.deere.epdp.pra.domain.epdp;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "proj_build_dates")
public class ProjectBuildDate implements Serializable {

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private ProjectBuildDateId id;

	@Column(name = "start_dt")
	private Date startDt;

	@Column(name = "actual_dt")
	private Date actualDt;

	@JsonIgnore
	@Column(name = "created_by", nullable = false, updatable = false)
	private String createdBy;

	@JsonIgnore
	@Column(name = "created_ts", updatable = false)
	private Timestamp createdTs;

	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdtBy;

	@JsonIgnore
	@Column(name = "last_updt_ts")
	private Timestamp lastUpdtTs;

	public ProjectBuildDate() {
		super();
	}

	public ProjectBuildDate(ProjectBuildDateId id, Date startDt, Date actualDt) {
		super();
		this.id = id;
		this.startDt = startDt;
		this.actualDt = actualDt;
	}

	public ProjectBuildDateId getId() {
		return id;
	}

	public void setId(ProjectBuildDateId id) {
		this.id = id;
	}

	public Date getStartDt() {
		return startDt;
	}

	public void setStartDt(Date startDt) {
		this.startDt = startDt;
	}

	public Date getActualDt() {
		return actualDt;
	}

	public void setActualDt(Date actualDt) {
		this.actualDt = actualDt;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedTs() {
		return createdTs;
	}

	public void setCreatedTs(Timestamp createdTs) {
		this.createdTs = createdTs;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public void setLastUpdtBy(String lastUpdtBy) {
		this.lastUpdtBy = lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}

	public void setLastUpdtTs(Timestamp lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}

	@Embeddable
	public static class ProjectBuildDateId implements Serializable {

		private static final long serialVersionUID = 1L;

		@Column(name = "proj_id")
		private Integer projId;

		@Column(name = "date_id")
		private Integer dateId;

		public ProjectBuildDateId() {
			super();
		}

		public ProjectBuildDateId(Integer projId, Integer dateId) {
			super();
			this.projId = projId;
			this.dateId = dateId;
		}

		public Integer getProjId() {
			return projId;
		}

		public void setProjId(Integer projId) {
			this.projId = projId;
		}

		public Integer getDateId() {
			return dateId;
		}

		public void setDateId(Integer dateId) {
			this.dateId = dateId;
		}
	}
}
