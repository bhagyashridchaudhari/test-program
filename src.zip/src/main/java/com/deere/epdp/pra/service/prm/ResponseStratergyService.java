package com.deere.epdp.pra.service.prm;

import java.util.List;

import com.deere.epdp.pra.domain.prm.ResponseStratergy;

public interface ResponseStratergyService {
	void init();

	List<ResponseStratergy> getAllResponseStratergy();

	String getResponseStratergyById(Integer id);

}
