package com.deere.epdp.pra.domain.user;

import java.util.List;
import java.util.Map;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonInclude;
@Component
@Scope(value = "session", proxyMode = ScopedProxyMode.TARGET_CLASS)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class User {

	private String userId;

	private String name;

	private String userType;

	private String jobTitle;

	private String email;

	private boolean admin = false;

	private boolean itSupport = false;

	private boolean appAccess = false;

	private boolean createAccess = false;

	private boolean simulated = false;

	private Map<Integer, Integer> progAccessMap;

	private List<String> groups;

	public User() {
		super();
	}

	public User(String userId, String name, String userType, String email) {
		super();
		this.userId = userId;
		this.name = name;
		this.userType = userType;
		this.email = email;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getJobTitle() {
		return jobTitle;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isAdmin() {
		return admin;
	}

	public void setAdmin(boolean admin) {
		this.admin = admin;
	}

	public boolean isItSupport() {
		return itSupport;
	}

	public void setItSupport(boolean itSupport) {
		this.itSupport = itSupport;
	}

	public boolean isAppAccess() {
		return appAccess;
	}

	public void setAppAccess(boolean appAccess) {
		this.appAccess = appAccess;
	}

	public boolean isCreateAccess() {
		return createAccess;
	}

	public void setCreateAccess(boolean createAccess) {
		this.createAccess = createAccess;
	}

	public boolean isSimulated() {
		return simulated;
	}

	public void setSimulated(boolean simulated) {
		this.simulated = simulated;
	}

	public Map<Integer, Integer> getProgAccessMap() {
		return progAccessMap;
	}

	public void setProgAccessMap(Map<Integer, Integer> progAccessMap) {
		this.progAccessMap = progAccessMap;
	}

	public List<String> getGroups() {
		return groups;
	}

	public void setGroups(List<String> groups) {
		this.groups = groups;
	}

	public Integer getRole(Integer prjId) {
		return (progAccessMap != null && progAccessMap.get(prjId) != null) ? progAccessMap.get(prjId) : 0;
	}

	public void consume(User user) {
		this.userId = user.userId;
		this.name = user.name;
		this.userType = user.userType;
		this.jobTitle = user.jobTitle;
		this.email = user.email !=null ? user.email.trim() : null;
		this.admin = user.admin;
		this.itSupport = user.itSupport;
		this.appAccess = user.appAccess;
		this.createAccess = user.createAccess;
		this.groups = user.groups;
	}

	public User produce() {
		User u = new User();
		u.userId = userId;
		u.name = name;
		u.userType = userType;
		u.jobTitle = jobTitle;
		u.email = email;
		u.admin = admin;
		u.itSupport = itSupport;
		u.appAccess = appAccess;
		u.createAccess = createAccess;
		u.simulated = simulated;
		u.progAccessMap = progAccessMap;
		return u;
	}

}