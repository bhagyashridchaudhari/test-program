package com.deere.epdp.pra.serviceImpl.prm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.StreamSupport;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.deere.epdp.pra.domain.prm.CustomRiskCategoryImpact;
import com.deere.epdp.pra.domain.prm.CustomRiskCategoryImpact.CustomRiskCategoryImpactId;
import com.deere.epdp.pra.domain.prm.ProgRiskCategoryImpact;
import com.deere.epdp.pra.domain.prm.ProgRiskCategoryImpact.ProgRiskCategoryImpactId;
import com.deere.epdp.pra.domain.prm.ProgramRiskCateory;
import com.deere.epdp.pra.domain.prm.RiskCategory;
import com.deere.epdp.pra.domain.prm.RiskCategoryImpact;
import com.deere.epdp.pra.domain.user.User;
import com.deere.epdp.pra.model.MitigationPlanOwner;
import com.deere.epdp.pra.model.Response;
import com.deere.epdp.pra.model.Response.RespMessage;
import com.deere.epdp.pra.model.Response.RespMessage.Type;
import com.deere.epdp.pra.model.Response.Status;
import com.deere.epdp.pra.model.RiskCategoryData;
import com.deere.epdp.pra.repo.prm.CustomRiskCategoryImpactRepository;
import com.deere.epdp.pra.repo.prm.MitigationPlanRepository;
import com.deere.epdp.pra.repo.prm.ProgRiskCategoryImpactRepository;
import com.deere.epdp.pra.repo.prm.ProgramCategoryRepository;
import com.deere.epdp.pra.repo.prm.RiskCategoryImpactRepository;
import com.deere.epdp.pra.repo.prm.RiskCategoryRepository;
import com.deere.epdp.pra.service.prm.RiskCategoryImpactService;
import com.deere.epdp.pra.service.prm.RiskCategoryService;
import com.deere.epdp.pra.utility.CommonUtility;

@Service
public class RiskCategoryServiceImpl implements RiskCategoryService {
	
	@Autowired
	private RiskCategoryRepository categoryRepository;
 
	@Autowired
	private RiskCategoryRepository catagoryRepo;

	@Autowired
	private  RiskCategoryImpactRepository categoryImpactRepo;

	@Autowired
	private ProgramCategoryRepository progCatagoryRepo;

	@Autowired
	private ProgRiskCategoryImpactRepository progCategoryImpactRepo;
	
	@Autowired
	private CustomRiskCategoryImpactRepository customRiskCatImpactRepo;
	
	private Map<Integer, RiskCategory> categoryMap;
	
	@Autowired
	private User user;
	
	@Autowired
	private MitigationPlanRepository mitigationPlanRepository;

	
	@Autowired
	private RiskCategoryImpactService  riskCategoryImpactService;
	 
	@PostConstruct
	public void init() {
		categoryMap = StreamSupport.stream(categoryRepository.findAll().spliterator(), false)
				.collect(Collectors.toMap(RiskCategory::getCatgryId, Function.identity()));
	}

	@Override
	public List<RiskCategory> getAllRiskCategory() { // all default category for cache 
		return categoryMap.values().stream().sorted(Comparator.comparing(RiskCategory::getCatgryName)).collect(Collectors.toList());
	}

	@Override
	public List<RiskCategoryData> getRiskCategoryImpactDesc(Integer progId) {
		List<RiskCategoryData> catData= new ArrayList<>();
		List<RiskCategory>  riskCatList = (List<RiskCategory>) catagoryRepo.findAll(); // default 
		List<RiskCategoryImpact>  riskCatImpList = (List<RiskCategoryImpact>) categoryImpactRepo.findAll(); // default impact 
		List<CustomRiskCategoryImpact> customImpact=customRiskCatImpactRepo.findCustomRiskCategoryImpact(progId);

		if(riskCatList !=null && riskCatList!=null) {
			riskCatList.forEach(p->{
				List<CustomRiskCategoryImpact> customImpactFiltered = customImpact.stream().filter(m-> p.getCatgryId().intValue()== m.getId().getCtgryId().intValue()).collect(Collectors.toList());
				if(customImpactFiltered.size() > 0) {
					RiskCategoryData riskCatData = new RiskCategoryData(p.getCatgryId(),progId,p.getCatgryName(),customImpact.stream().filter(m-> m.getId().getCtgryId().intValue()==p.getCatgryId().intValue()).map(m-> m.getImpactDsc()).collect(Collectors.toList()),"Edited",customImpactFiltered.stream().anyMatch(m-> m.getActive()=='Y') ? 'Y' :'N', !p.getCatgryAcronym().isEmpty() ? p.getCatgryAcronym().trim() : "");
					catData.add(riskCatData);
				}else {
					RiskCategoryData riskCatData = new RiskCategoryData(p.getCatgryId(),progId,p.getCatgryName(),riskCatImpList.stream().filter(m-> m.getId().getCtgryId().intValue()==p.getCatgryId().intValue()).map(m-> m.getImpactDsc()).collect(Collectors.toList()),"default",'Y', !p.getCatgryAcronym().isEmpty() ? p.getCatgryAcronym().trim() : "");
					catData.add(riskCatData);
				}
			}); 
		}

		List<ProgramRiskCateory> prgRiskList = (List<ProgramRiskCateory>) progCatagoryRepo.findProrgamRiskCateoryByProgId(progId);
		List<ProgRiskCategoryImpact> prgRiskcCtList = (List<ProgRiskCategoryImpact>) progCategoryImpactRepo.findProgRiskCategoryImpactByProgId(progId);

		if(prgRiskList!=null && prgRiskcCtList!=null) {
			prgRiskList.forEach(p->{
				List<ProgRiskCategoryImpact> progRiskCatImpactFiltered = prgRiskcCtList.stream().filter(m-> p.getCatgryId().intValue()== m.getId().getCtgryId().intValue()).collect(Collectors.toList());
				if(progRiskCatImpactFiltered.size() > 0) {
					RiskCategoryData prgriskData = new RiskCategoryData(p.getCatgryId(),progId,p.getCatgryName(),prgRiskcCtList.stream().filter(m-> m.getId().getCtgryId().intValue() == p.getCatgryId().intValue()).map(m-> m.getImpactDsc()).collect(Collectors.toList()),"Program",progRiskCatImpactFiltered.stream().anyMatch(m-> m.getActive()=='Y') ? 'Y' :'N' , p.getCatgryName().trim());
					catData.add(prgriskData);
				}
			});
		}
		return catData;
	}

	
	
	@Override
	@Transactional(value="prmTransactionManager",readOnly=false,propagation=Propagation.REQUIRED) 
	public Response<RiskCategoryData> saveProgRiskCategory(RiskCategoryData data) {  // display perpose on risk screen 
		List<RespMessage> message = new ArrayList<>();
		data.setActive('Y');
		if("Program".equalsIgnoreCase(data.getCatgryType())) {
			if(data.getCatgryId() ==null) { // create  Program Sp
				
				ProgramRiskCateory obj = progCatagoryRepo.save(new ProgramRiskCateory(data.getCatgryName(), data.getProgId(), user.getUserId(), CommonUtility.getCurrentTime()));
				IntStream.range(0, data.getImpactDesc().size()).forEach(idx -> {
					progCategoryImpactRepo.save(new ProgRiskCategoryImpact(new ProgRiskCategoryImpactId(obj.getCatgryId(),(idx + 1),data.getProgId() ),data.getImpactDesc().get(idx), user.getUserId(), CommonUtility.getCurrentTime(),data.getActive()));
				});
				message.add(new RespMessage("Category added successfully"));
			}else { //  Update Program Sp
				progCatagoryRepo.update(data.getCatgryId(),data.getCatgryName(),data.getProgId(),user.getUserId(), CommonUtility.getCurrentTime());
				IntStream.range(0, data.getImpactDesc().size()).forEach(idx -> { 
					progCategoryImpactRepo.update(data.getCatgryId(),data.getProgId(),(idx + 1), data.getImpactDesc().get(idx), user.getUserId(), CommonUtility.getCurrentTime(),data.getActive());
				});
				message.add(new RespMessage("Category updated successfully"));
			} 
		}else {
			if("Edited".equalsIgnoreCase(data.getCatgryType())) {
				IntStream.range(0, data.getImpactDesc().size()).forEach(idx -> { 
					customRiskCatImpactRepo.update(data.getCatgryId(),data.getProgId(),(idx + 1), data.getImpactDesc().get(idx), user.getUserId(), CommonUtility.getCurrentTime(),data.getActive());
				});
				message.add(new RespMessage("Category updated successfully"));
			}else {
				IntStream.range(0, data.getImpactDesc().size()).forEach(idx -> {
				 customRiskCatImpactRepo.save(new CustomRiskCategoryImpact(new CustomRiskCategoryImpactId(data.getCatgryId(),(idx + 1),data.getProgId()), data.getImpactDesc().get(idx), user.getUserId(), CommonUtility.getCurrentTime(),data.getActive()));
				});
				message.add(new RespMessage("Category added successfully"));		
			}	
		}
		return new Response<RiskCategoryData>(Status.SUCCESS, data, message.isEmpty() ? null : message);
	}

	@Override
	public List<MitigationPlanOwner> getDistinctOwner(Integer progId) {
		List<MitigationPlanOwner> mgtOwnerList = new ArrayList<>();
		List<String>  mtgnOwnerList = ((List<String>) mitigationPlanRepository.getDistinctOwner(progId)).stream().collect(Collectors.toList());
		for( String owner :mtgnOwnerList) {
			MitigationPlanOwner mpoObj =   new MitigationPlanOwner(owner,null,progId);
			mgtOwnerList.add(mpoObj);
		}
		return mgtOwnerList;
	}

	@Override
	@Transactional(value="prmTransactionManager",readOnly=false,propagation=Propagation.REQUIRED) 
	public Response<MitigationPlanOwner> updateOwners(MitigationPlanOwner mo) {
		List<RespMessage> errors = new ArrayList<>();
		mitigationPlanRepository.update(mo.getFutureOwner(),mo.getMtgtnOwner(),mo.getProgId());
		return new Response<>(Status.SUCCESS, mo, errors.isEmpty() ? null : errors );
	}
	
	@Override
	@Transactional(value="prmTransactionManager",readOnly=false,propagation=Propagation.REQUIRED) 
	public Response<RiskCategoryData>  cloneRiskCategory(List<RiskCategoryData> riskCategoryData) {
		List<ProgramRiskCateory> prgRiskList = (List<ProgramRiskCateory>) progCatagoryRepo.findProrgamRiskCateoryByProgId(riskCategoryData.get(0).getProgId());
		List<ProgRiskCategoryImpact> prgRiskcCtList = (List<ProgRiskCategoryImpact>) progCategoryImpactRepo.findProgRiskCategoryImpactByProgId(riskCategoryData.get(0).getProgId());
		if(prgRiskcCtList != null && ! prgRiskcCtList.isEmpty()) {
			progCategoryImpactRepo.delete(prgRiskcCtList);
		}
		if(prgRiskList != null && !prgRiskList.isEmpty()) {
			progCatagoryRepo.delete(prgRiskList);
		}
		List<CustomRiskCategoryImpact> customImpact=customRiskCatImpactRepo.findCustomRiskCategoryImpact(riskCategoryData.get(0).getProgId());
		if(customImpact!=null  && !customImpact.isEmpty()) {
			customRiskCatImpactRepo.delete(customImpact);
		}
		for(RiskCategoryData data:riskCategoryData) {
			if("Program".equalsIgnoreCase(data.getCatgryType())) {
				ProgramRiskCateory obj = progCatagoryRepo.save(new ProgramRiskCateory(data.getCatgryName(), data.getProgId(), user.getUserId(), CommonUtility.getCurrentTime()));
				IntStream.range(0, data.getImpactDesc().size()).forEach(idx -> {
					progCategoryImpactRepo.save(new ProgRiskCategoryImpact(new ProgRiskCategoryImpactId(obj.getCatgryId(),(idx + 1),data.getProgId() ),data.getImpactDesc().get(idx), user.getUserId(), CommonUtility.getCurrentTime(),data.getActive()));
				});
			} else if("Edited".equalsIgnoreCase(data.getCatgryType())) {
				IntStream.range(0, data.getImpactDesc().size()).forEach(idx -> {
					customRiskCatImpactRepo.save(new CustomRiskCategoryImpact(new CustomRiskCategoryImpactId(data.getCatgryId(),(idx + 1),data.getProgId()), data.getImpactDesc().get(idx), user.getUserId(), CommonUtility.getCurrentTime(),data.getActive()));
				});
			}
		}
		return new Response<RiskCategoryData>(Status.SUCCESS,
				Arrays.asList(new RespMessage("Successfully cloned  Category(s).", Type.SUCCESS)));
	}

	@Override
	@Transactional(value="prmTransactionManager",readOnly=false,propagation=Propagation.REQUIRED) 
	public Response<RiskCategoryData> updateCategory(List<RiskCategoryData> riskCategoryData) {
		try {
			for(RiskCategoryData data: riskCategoryData) {
				if("Edited".equalsIgnoreCase(data.getCatgryType())) {
					customRiskCatImpactRepo.updateCustomRiskCategory(data.getActive(), data.getCatgryId(), data.getProgId(),user.getUserId(), CommonUtility.getCurrentTime());
				}
				else if("Program".equalsIgnoreCase(data.getCatgryType())) {
					progCategoryImpactRepo.updateProgramRiskCategory(data.getActive(), data.getCatgryId(), data.getProgId(),user.getUserId(), CommonUtility.getCurrentTime());

				} 
				else if("default".equalsIgnoreCase(data.getCatgryType()) && data.getActive() =='N') {
					List<RiskCategoryImpact> riskCategoryImpact = 	riskCategoryImpactService.findImpactByCategory(data.getCatgryId());
					for(RiskCategoryImpact obj :riskCategoryImpact) {
						CustomRiskCategoryImpactId  customRiskCategoryImpactId = new CustomRiskCategoryImpactId(obj.getId().getCtgryId(),obj.getId().getImpactId(),data.getProgId());
						CustomRiskCategoryImpact customRiskCategoryImpact =  new CustomRiskCategoryImpact(customRiskCategoryImpactId,obj.getImpactDsc(), user.getUserId(),CommonUtility.getCurrentTime(),data.getActive());
						customRiskCatImpactRepo.save(customRiskCategoryImpact);
					}
				}
			}
			return new Response<RiskCategoryData>(Status.SUCCESS,
					Arrays.asList(new RespMessage("Successfully updated  Category(s).", Type.SUCCESS)));
		}catch (Exception e) {
			return new Response<RiskCategoryData>(Status.ERROR,
					Arrays.asList(new RespMessage("Error! Not able  update  Category(s).")));
		}

	}

	


	
}
