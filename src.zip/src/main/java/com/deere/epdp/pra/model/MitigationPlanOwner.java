package com.deere.epdp.pra.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MitigationPlanOwner {

	private String mtgtnOwner;
	private String  futureOwner;
	private Integer progId;
	private String mtgtnOwnerName;
	
	public MitigationPlanOwner(String mtgtnOwner, String futureOwner,Integer progId) {
		super();
		this.mtgtnOwner = mtgtnOwner;
		this.futureOwner = futureOwner;
		this.progId = progId;
	}

	public MitigationPlanOwner() {}

	public String getMtgtnOwner() {
		return mtgtnOwner;
	}

	public void setMtgtnOwner(String mtgtnOwner) {
		this.mtgtnOwner = mtgtnOwner;
	}

	public String getFutureOwner() {
		return futureOwner;
	}

	public void setFutureOwner(String futureOwner) {
		this.futureOwner = futureOwner;
	}
	
	public Integer getProgId() {
		return progId;
	}

	public void setProgId(Integer progId) {
		this.progId = progId;
	}

	public String getMtgtnOwnerName() {
		return mtgtnOwnerName;
	}

	public void setMtgtnOwnerName(String mtgtnOwnerName) {
		this.mtgtnOwnerName = mtgtnOwnerName;
	}




}
