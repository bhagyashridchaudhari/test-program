package com.deere.epdp.pra.repo.prm;

import org.springframework.data.repository.CrudRepository;

import com.deere.epdp.pra.domain.prm.RiskProbability;

public interface RiskProbabilityRepository extends CrudRepository<RiskProbability, Integer> {}
