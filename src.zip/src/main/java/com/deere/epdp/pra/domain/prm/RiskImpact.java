package com.deere.epdp.pra.domain.prm;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "impact")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RiskImpact {
	
private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "id")
	private Integer impactId;

//	@Column(name = "name", nullable = false)
//	private String impactName;

	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdtBy;
	
	@JsonIgnore
	@Column(name = "last_updt_ts")
	private Timestamp lastUpdtTs;

	public Integer getImpactId() {
		return impactId;
	}

	public void setImpactId(Integer impactId) {
		this.impactId = impactId;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public void setLastUpdtBy(String lastUpdtBy) {
		this.lastUpdtBy = lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}

	public void setLastUpdtTs(Timestamp lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}

	
	
}
