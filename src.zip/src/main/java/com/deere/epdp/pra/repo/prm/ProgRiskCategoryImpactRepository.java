package com.deere.epdp.pra.repo.prm;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.deere.epdp.pra.domain.prm.ProgRiskCategoryImpact;


public interface ProgRiskCategoryImpactRepository  extends CrudRepository<ProgRiskCategoryImpact, Serializable>{

	@Query("Select prci from ProgRiskCategoryImpact prci where prci.id.ctgryId=?1")
	List<ProgRiskCategoryImpact> findImpactByCategory(Integer id);

	@Modifying
	@Query("update ProgRiskCategoryImpact prc set prc.impactDsc=?4, prc.lastUpdtBy=?5, prc.lastUpdtTs=?6 ,prc.active =?7 where prc.id.ctgryId = ?1 and prc.id.progId=?2 and prc.id.impactId =?3" )
	void update(Integer catgryId, Integer progId, int idx, String impactDsc, String userId, Timestamp currentTime,char active);

	@Query("Select prci from ProgRiskCategoryImpact prci where prci.id.progId=?1 ")
	List<ProgRiskCategoryImpact> findProgRiskCategoryImpactByProgId(Integer progId);
	

	@Modifying
	@Query("update ProgRiskCategoryImpact prc set prc.active=?1, prc.lastUpdtBy=?4, prc.lastUpdtTs=?5 where prc.id.ctgryId = ?2 and prc.id.progId=?3" )
	void updateProgramRiskCategory(char isActive,Integer catgryId, Integer progId, String userId, Timestamp currentTime);
}
