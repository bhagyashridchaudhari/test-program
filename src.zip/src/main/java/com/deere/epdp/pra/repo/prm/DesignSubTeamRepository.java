package com.deere.epdp.pra.repo.prm;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;


import com.deere.epdp.pra.domain.prm.DesignSubTeam;

public interface DesignSubTeamRepository extends CrudRepository<DesignSubTeam, Integer>{
	
	@Modifying
    @Query("delete from DesignSubTeam team where team.prgmId=?1")
    void deleteDesignSubTeamByProgram(Integer prjId);

}

