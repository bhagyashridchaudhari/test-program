package com.deere.epdp.pra.service;

import java.util.List;

import com.deere.epdp.pra.domain.epdp.Milestone;

public interface MilestoneService {
	
	void init();

	List<Milestone> getAllMilestone();

	Milestone getMilestoneById(Integer id);

}
