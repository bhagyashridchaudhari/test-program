package com.deere.epdp.pra.domain.epdp;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "product_line")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductLine implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "prdln_id")
	private Integer prdlnId;

	@Column(name = "prdln_nm", nullable = false)
	private String prdlnNm;

	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdtBy;

	@JsonIgnore
	@Column(name = "last_updt_ts")
	private Timestamp lastUpdtTs;

	public Integer getPrdlnId() {
		return prdlnId;
	}

	public void setPrdlnId(Integer prdlnId) {
		this.prdlnId = prdlnId;
	}

	public String getPrdlnNm() {
		return prdlnNm;
	}

	public void setPrdlnNm(String prdlnNm) {
		this.prdlnNm = prdlnNm;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public void setLastUpdtBy(String lastUpdtBy) {
		this.lastUpdtBy = lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}

	public void setLastUpdtTs(Timestamp lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}
}