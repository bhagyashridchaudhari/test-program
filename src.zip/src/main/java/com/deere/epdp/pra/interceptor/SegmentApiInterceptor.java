package com.deere.epdp.pra.interceptor;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.deere.epdp.pra.exception.AuthenticationException;
import com.deere.epdp.pra.utility.CommonUtility;


/**
 * This interceptor will intercept all segmentation API request and authenticate users.
 * 
 * @author RM43492
 * @version 1.0
 * @since 2017-05-21
 */
@Component(value = "segmentApiInterceptor")
public class SegmentApiInterceptor extends HandlerInterceptorAdapter {

	@Value("${security.oauth2.okta.enable:false}")
	private boolean okatEnable;

	private static final List<String> AUTH_LIST = Collections.unmodifiableList(Arrays.asList("APU1983", "APU6563", "A907115", "APU6564", "RM43492"));

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
		if (okatEnable)
			return true;

		String userId = CommonUtility.getUserId(request);

		if (userId == null || !AUTH_LIST.contains(userId.toUpperCase()))
			throw new AuthenticationException("User not authorize to acces this API");
		return true;
	}
}