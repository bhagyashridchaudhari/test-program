package com.deere.epdp.pra.repo.prm;

import org.springframework.data.repository.CrudRepository;

import com.deere.epdp.pra.domain.prm.RiskCategory;

public interface RiskCategoryRepository extends CrudRepository<RiskCategory, Integer> {}
