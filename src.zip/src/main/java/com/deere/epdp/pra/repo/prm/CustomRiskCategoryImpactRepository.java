package com.deere.epdp.pra.repo.prm;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.deere.epdp.pra.domain.prm.CustomRiskCategoryImpact;

public interface CustomRiskCategoryImpactRepository  extends CrudRepository<CustomRiskCategoryImpact, Serializable>{
	
	
	@Query("Select psrci from CustomRiskCategoryImpact  psrci where psrci.id.progId = ?1")
	List<CustomRiskCategoryImpact> findCustomRiskCategoryImpact(Integer progId);
	
	
	@Query("Select psrci from CustomRiskCategoryImpact  psrci where psrci.id.ctgryId=?1 and psrci.id.progId = ?2")
	List<CustomRiskCategoryImpact> findCustomRiskCategoryImpact(Integer custId,Integer progId);
	
	@Modifying
	@Query("update CustomRiskCategoryImpact crc set crc.impactDsc=?4, crc.lastUpdtBy=?5, crc.lastUpdtTs=?6,crc.active = ?7 where crc.id.ctgryId = ?1 and crc.id.progId=?2 and crc.id.impactId =?3" )
	void update(Integer catgryId, Integer progId, int idx, String impactDsc, String userId, Timestamp currentTime,char active);
	
	
	@Modifying
	@Query("update CustomRiskCategoryImpact crc set crc.active=?1, crc.lastUpdtBy=?4, crc.lastUpdtTs=?5 where crc.id.ctgryId = ?2 and crc.id.progId=?3" )
	void updateCustomRiskCategory(char isActive,Integer catgryId, Integer progId, String userId, Timestamp currentTime);
	
	
	
	 @Modifying
	 @Query("delete from  CustomRiskCategoryImpact crc where  crc.id.progId=?1")
	 public void deleteMgtnPlanByPrjId(Integer prjId);
	
	
}
