package com.deere.epdp.pra.service.prm;

import com.deere.epdp.pra.model.Response;
import com.deere.epdp.pra.model.SubDesignTeam;

public interface DesignSubTeamService {

	Iterable<SubDesignTeam> getTeamByPrjId(Integer prjId);

	Response<SubDesignTeam> saveTeam(SubDesignTeam team);

	Response<SubDesignTeam> deleteProjectTeam(Integer id);
	
	  void deleteDesignSubTeamByProgram(Integer prjId);

}
