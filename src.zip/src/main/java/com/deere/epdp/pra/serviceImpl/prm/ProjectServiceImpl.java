package com.deere.epdp.pra.serviceImpl.prm;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.deere.epdp.pra.domain.prm.Project;
import com.deere.epdp.pra.domain.prm.ProjectTeam;
import com.deere.epdp.pra.domain.prm.ProjectTeam.ProjectTeamId;
import com.deere.epdp.pra.domain.user.User;
import com.deere.epdp.pra.literals.PRALiterals;
import com.deere.epdp.pra.model.MitigationPlanOwner;
import com.deere.epdp.pra.model.ProjectFilter;
import com.deere.epdp.pra.model.Response;
import com.deere.epdp.pra.model.Response.RespMessage;
import com.deere.epdp.pra.model.Response.Status;
import com.deere.epdp.pra.repo.prm.ProjectRepository;
import com.deere.epdp.pra.service.prm.ProjectService;
import com.deere.epdp.pra.service.prm.ProjectTeamService;
import com.deere.epdp.pra.utility.CommonUtility;
import com.deere.epdp.pra.utility.ProjectSpecifications;

@Service
public class ProjectServiceImpl implements ProjectService {

	@Autowired
	private ProjectRepository projectRepository;

	@Autowired
	private ProjectTeamService projectTeamService;

	@Autowired
	private User user;

	@Override
	@Transactional(readOnly = true)
	public boolean isValid(Project p) {
		Integer id = p.getPrjId() == null ? 0 : p.getPrjId();
		return projectRepository.isPresent(id, p.getPrjOwner(), p.getPrjName(), p.getPrjTypeId(), p.getDivId(), p.getPltfmId(), p.getPrdlnId(), p.getPrdfmlyId(), p.getUnitId()) == 0;
	}

	@Override
	@Transactional(readOnly = true)
	public boolean isProjectExist(Integer prjId) {
		return projectRepository.exists(prjId);
	}

	@Override
	@Transactional
	public Project saveProject(Project project, List<ProjectTeam> added, List<ProjectTeamId> removed) {
		Set<String> oldMember;
		if (project.getPrjId() != null) {
			Project projectOld = projectRepository.findOne(project.getPrjId());
			project.setCreatedBy(projectOld.getCreatedBy());
			if (project.getPrjStatusId() == 4 && projectOld.getPrjCmpltDt() == null) {
				project.setPrjCmpltDt(CommonUtility.getDate());
				projectRepository.setCompleted(project.getPrjId(), CommonUtility.getDate());
			}
			oldMember = new HashSet<>(Arrays.asList(projectOld.getPrjManager(), projectOld.getPrjDirector(), projectOld.getPrjMrktDirctor(), projectOld.getPrjEngrDirctor(), projectOld.getCreatedBy()));
			oldMember.remove(projectOld.getPrjOwner());
		} else {
			oldMember = Collections.emptySet();
			project.setCreatedBy(user.getUserId());
			project.setCreatedTs(CommonUtility.getCurrentTime());
		}
		project.setLastUpdtBy(user.getUserId());
		project.setLastUpdtTs(CommonUtility.getCurrentTime());
		projectRepository.save(project);

		Set<String> member = new HashSet<>(Arrays.asList(project.getPrjManager(), project.getPrjDirector(), project.getPrjMrktDirctor(), project.getPrjEngrDirctor(), project.getCreatedBy()));
		member.remove(project.getPrjOwner());

		added.addAll(member.stream().filter(memId -> !oldMember.contains(memId)).map(memId -> new ProjectTeam(new ProjectTeamId(project.getPrjId(), memId), ProjectTeam.MemberType.I,
				 memId.equals(project.getCreatedBy()) ? PRALiterals.FULL_ACCESS_ROLE : PRALiterals.VIEW_ROLE,project.getLastUpdtBy(), project.getLastUpdtTs())).collect(Collectors.toList()));

		removed.addAll(oldMember.stream().filter(memId -> !member.contains(memId)).map(memId -> new ProjectTeamId(project.getPrjId(), memId)).collect(Collectors.toList()));

		projectTeamService.deleteProjectTeams(removed);
		projectTeamService.saveProjectTeams(added);

		return project;
	}

	@Override
	@Transactional
	public void transferProjects(List<Project> projects) {
		Map<Integer, String> projeectMap = projectRepository.findPrjIdOwnerByPrjIds(projects.stream().map(Project::getPrjId).collect(Collectors.toList())).stream().collect(Collectors.toMap(p -> (Integer) p[0], p -> (String) p[1]));
		projects.forEach(p -> {
			if (p.getPrjOwner() == null || p.getPrjOwner().equals(projeectMap.get(p.getPrjId())))
			try {
				throw new Exception("New owner must be different from existing owner for program #" + p.getPrjId() + ".");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
		projects.forEach(p -> {
			p.setLastUpdtBy(user.getUserId());
			p.setLastUpdtTs(CommonUtility.getCurrentTime());
			projectRepository.updateOwner(p.getPrjOwner(), p.getPrjId(), p.getLastUpdtBy(), p.getLastUpdtTs());
			projectTeamService.deleteProjectTeam(new ProjectTeamId(p.getPrjId(), p.getPrjOwner()));
			if (p.getPrjManager() != null)
				projectTeamService.saveProjectTeam(new ProjectTeam(new ProjectTeamId(p.getPrjId(), p.getPrjManager()), ProjectTeam.MemberType.I,
						p.getPrjManager().equals(p.getCreatedBy()) ? PRALiterals.FULL_ACCESS_ROLE : PRALiterals.VIEW_ROLE, p.getLastUpdtBy(), p.getLastUpdtTs()));
		});
	}

	@Override
	@Transactional
	public void updateProjectStatus(List<Project> projects) {
		projects.forEach(p -> {
			p.setLastUpdtBy(user.getUserId());
			p.setLastUpdtTs(CommonUtility.getCurrentTime());
			if (p.getPrjStatusId() != 4 || projectRepository.isCompleted(p.getPrjId()) > 0)
				projectRepository.updateStatus(p.getPrjId(), p.getPrjStatusId(), p.getLastUpdtBy(), p.getLastUpdtTs());
			else
				projectRepository.updateStatus(p.getPrjId(), p.getPrjStatusId(), CommonUtility.getDate(), p.getLastUpdtBy(), p.getLastUpdtTs());
		});
	}

	@Override
	@Transactional(readOnly = true)
	public Project getProjectById(Integer prjId) {
		Project p = projectRepository.findOne(prjId);
		return p;
	}

	@Override
	@Transactional(readOnly = true)
	public List<Project> getAllProjects() {
		List<Project> projects = user.getProgAccessMap() != null && !user.getProgAccessMap().keySet().isEmpty() ? projectRepository.findByPrjIdIn(user.getProgAccessMap().keySet()) : Collections.emptyList();
		if (!projects.isEmpty()) {
			List<Integer> prjIds = projects.stream().map(Project::getPrjId).collect(Collectors.toList());
		}
		return projects;
	}

	@Override
	@Transactional(readOnly = true)
	public List<Project> getAllProjects(ProjectFilter projectFilter) {
		List<Project> projects = projectRepository.findAll(ProjectSpecifications.build(projectFilter, user.isAdmin() ? Collections.emptySet() : user.getProgAccessMap().keySet()));
		return projects;
	}
	
	
	@Override
	@Transactional(readOnly = true)
	public List<Integer> getAllProjectIdsByOwner(String owner) {
		return projectRepository.findPrjIdByPrjOwner(owner);
	}
	
	@Override
	@Transactional
	public void deleteProject(Integer prjId) {
		projectRepository.delete(prjId);
	}

	@Override
	@Transactional(readOnly = true)
	public Project sortProjectDetail(Integer prjId) {
		return projectRepository.findOne(prjId);
	}

	@Override
	public List<Project> searchProjects(Project project) {
		List<Project> projects = projectRepository.findAll(ProjectSpecifications.build(project));
		return projects;
	}

	@Override
	@Transactional(readOnly = true)
	public Set<String> getAllProjectOwnerUserId() {
		return projectRepository.getAllOwnerUserId();
	}

	@Override
	@Transactional(readOnly = true)
	public String getOwner(Integer prjId) {
		return projectRepository.getPrjOwnerByPrjId(prjId);
	}

	@Override
	@Transactional(value="prmTransactionManager",readOnly=false,propagation=Propagation.REQUIRED) 
	public Response updateProjLastModDate(Integer prjId, Timestamp lastUpdtTs) {
		List<RespMessage> errors = new ArrayList<>();
		projectRepository.updateProjLastModDate(prjId, CommonUtility.getCurrentTime());
		return new Response<>(Status.SUCCESS, errors.isEmpty() ? null : errors);

	}
		
	

}
