package com.deere.epdp.pra.domain.epdp;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "country")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Country implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "cntry_id")
	private Integer cntryId;

	@Column(name = "cntry_nm", length = 100, nullable = false)
	private String cntryNm;

	@Column(name = "cntry_cd", length = 4)
	private String cntryCd;

	@Column(name = "currency", length = 20)
	private String currency;

	@Column(name = "iso_no")
	private Integer isoNo;

	@JsonIgnore
	@Column(name = "last_updt_by", length = 7, nullable = false)
	private String lastUpdtBy;

	@JsonIgnore
	@Column(name = "last_updt_ts", nullable = false)
	private Timestamp lastUpdtTs;

	public Country() {
		super();
	}

	public Country(Integer cntryId, String cntryNm, String cntryCd, String lastUpdtBy, Timestamp lastUpdtTs) {
		super();
		this.cntryId = cntryId;
		this.cntryNm = cntryNm;
		this.cntryCd = cntryCd;
		this.lastUpdtBy = lastUpdtBy;
		this.lastUpdtTs = lastUpdtTs;
	}

	public Integer getCntryId() {
		return cntryId;
	}

	public String getCntryNm() {
		return cntryNm;
	}

	public String getCntryCd() {
		return cntryCd;
	}

	public String getCurrency() {
		return currency;
	}

	public Integer getIsoNo() {
		return isoNo;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}
}