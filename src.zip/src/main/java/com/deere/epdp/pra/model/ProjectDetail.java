package com.deere.epdp.pra.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProjectDetail {

	private Integer prjId;

	private String prjName;

	private String prjType;

	private String prjStatus;

	private String div;

	private String pltfm;

	private String prdln;

	private String prdfmly;

	private String unit;

	private String prjOwner;

	private String prjManager;

	private String prjDirector;
	
	private String prjMrktDirctor;
	
	private String prjEngrDirctor;

	private String currency;

	private String prjStartDate;

	private String prjLastAprvl;

	private String prjCmpltDt;

	private String prjEndDt;

	private String afeNo;

	private Integer totalPartCount;

	private Integer newPartCount;

	private Integer role;

	private List<ProjectMapDetail> projectMap;

	private List<ProjectTeamDetail> projectTeams;
	
	public ProjectDetail(Integer prjId, String prjName, String prjType, String prjStatus, String div, String pltfm,
			String prdln, String prdfmly, String unit, String prjOwner, String prjManager, String prjDirector,
			String prjMrktDirctor, String prjEngrDirctor, String currency, String prjStartDate, String prjLastAprvl,
			String prjCmpltDt, String prjEndDt, String afeNo, Integer totalPartCount, Integer newPartCount,
			Integer role, List<ProjectMapDetail> projectMap, List<ProjectTeamDetail> projectTeams) {
		super();
		this.prjId = prjId;
		this.prjName = prjName;
		this.prjType = prjType;
		this.prjStatus = prjStatus;
		this.div = div;
		this.pltfm = pltfm;
		this.prdln = prdln;
		this.prdfmly = prdfmly;
		this.unit = unit;
		this.prjOwner = prjOwner;
		this.prjManager = prjManager;
		this.prjDirector = prjDirector;
		this.prjMrktDirctor = prjMrktDirctor;
		this.prjEngrDirctor = prjEngrDirctor;
		this.currency = currency;
		this.prjStartDate = prjStartDate;
		this.prjLastAprvl = prjLastAprvl;
		this.prjCmpltDt = prjCmpltDt;
		this.prjEndDt = prjEndDt;
		this.afeNo = afeNo;
		this.totalPartCount = totalPartCount;
		this.newPartCount = newPartCount;
		this.role = role;
		this.projectMap = projectMap;
		this.projectTeams = projectTeams;
	}

	public Integer getPrjId() {
		return prjId;
	}

	public String getPrjName() {
		return prjName;
	}

	public String getPrjType() {
		return prjType;
	}

	public String getPrjStatus() {
		return prjStatus;
	}

	public String getDiv() {
		return div;
	}

	public String getPltfm() {
		return pltfm;
	}

	public String getPrdln() {
		return prdln;
	}

	public String getPrdfmly() {
		return prdfmly;
	}

	public String getUnit() {
		return unit;
	}

	public String getPrjOwner() {
		return prjOwner;
	}

	public String getPrjManager() {
		return prjManager;
	}

	public String getPrjDirector() {
		return prjDirector;
	}

	public String getPrjMrktDirctor() {
		return prjMrktDirctor;
	}

	public String getPrjEngrDirctor() {
		return prjEngrDirctor;
	}

	public String getCurrency() {
		return currency;
	}

	public String getPrjStartDate() {
		return prjStartDate;
	}

	public String getPrjLastAprvl() {
		return prjLastAprvl;
	}

	public String getPrjCmpltDt() {
		return prjCmpltDt;
	}

	public String getPrjEndDt() {
		return prjEndDt;
	}

	public String getAfeNo() {
		return afeNo;
	}

	public Integer getTotalPartCount() {
		return totalPartCount;
	}

	public Integer getNewPartCount() {
		return newPartCount;
	}

	public Integer getRole() {
		return role;
	}

	public List<ProjectMapDetail> getProjectMap() {
		return projectMap;
	}

	public List<ProjectTeamDetail> getProjectTeams() {
		return projectTeams;
	}
	
	public static class ProjectMapDetail {
		
		private Integer appId;
		
		private Integer mappedId;

		public ProjectMapDetail(Integer appId, Integer mappedId) {
			super();
			this.appId = appId;
			this.mappedId = mappedId;
		}

		public Integer getAppId() {
			return appId;
		}

		public Integer getMappedId() {
			return mappedId;
		}	
	}
	
	public static class ProjectTeamDetail {

		private String memberId;
		
		private String memberType;

		private Integer roleId;

		private String nestedADGroups;
		
		private Integer nestedADGroupCnt;
		
		public ProjectTeamDetail() {
			super();
		}

		public ProjectTeamDetail(String memberId, String memberType, Integer roleId) {
			super();
			this.memberId = memberId;
			this.memberType = memberType;
			this.roleId = roleId;
		}

		public String getMemberId() {
			return memberId;
		}

		public void setMemberId(String memberId) {
			this.memberId = memberId;
		}

		public String getMemberType() {
			return memberType;
		}

		public void setMemberType(String memberType) {
			this.memberType = memberType;
		}

		public Integer getRoleId() {
			return roleId;
		}

		public void setRoleId(Integer roleId) {
			this.roleId = roleId;
		}

		public String getNestedADGroups() {
			return nestedADGroups;
		}

		public void setNestedADGroups(String nestedADGroups) {
			this.nestedADGroups = nestedADGroups;
		}

		public Integer getNestedADGroupCnt() {
			return nestedADGroupCnt;
		}

		public void setNestedADGroupCnt(Integer nestedADGroupCnt) {
			this.nestedADGroupCnt = nestedADGroupCnt;
		}

		public ProjectTeamDetail(String memberId, String memberType, Integer roleId, String nestedADGroups,
				Integer nestedADGroupCnt) {
			super();
			this.memberId = memberId;
			this.memberType = memberType;
			this.roleId = roleId;
			this.nestedADGroups = nestedADGroups;
			this.nestedADGroupCnt = nestedADGroupCnt;
		}
		
	}

}
