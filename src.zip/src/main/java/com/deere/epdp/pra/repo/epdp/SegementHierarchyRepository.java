package com.deere.epdp.pra.repo.epdp;
import org.springframework.data.repository.CrudRepository;

import com.deere.epdp.pra.domain.epdp.SegementHierarchy;
import com.deere.epdp.pra.domain.epdp.SegementHierarchy.SegementHierarchyId;

public interface SegementHierarchyRepository extends CrudRepository<SegementHierarchy, SegementHierarchyId> {}
