package com.deere.epdp.pra.repo.prm;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.deere.epdp.pra.domain.prm.Project;
import com.deere.epdp.pra.repo.CustomCrudRepository;

public interface ProjectRepository extends CustomCrudRepository<Project, Integer> {

	// @Query("select p from Project p where p.prjId in :ids")
	List<Project> findByPrjIdIn(Iterable<Integer> prjIds);

	@Query("select count(1) from Project p where p.prjId<>?1 and p.prjOwner=?2 and p.prjName=?3 and p.prjTypeId=?4 and p.divId=?5 and p.pltfmId=?6 and p.prdlnId=?7 and p.prdfmlyId=?8 and p.unitId=?9")
	long isPresent(Integer id, String owner, String name, Integer typeId, Integer divId, Integer pfmId, Integer plnId, Integer pfmlyId, Integer unitId);

	@Query("select p.prjId from Project p where p.prjOwner=?1")
	List<Integer> findPrjIdByPrjOwner(String owner);

	@Query("select distinct(p.prjOwner) from Project p")
	Set<String> getAllOwnerUserId();

	@Query("select p.prjOwner from Project p where p.prjId=?1")
	String getPrjOwnerByPrjId(Integer prjId);

	@Query("select p.prjId, p.prjName, p.prjOwner, p.prjTypeId, p.prjStatusId, p.divId, p.pltfmId, p.prdlnId, p.prdfmlyId, p.unitId, p.createdTs from Project p order by p.prjId")
	List<Object[]> getAll();

	@Query("select p.prjId, p.prjOwner from Project p where p.prjId in :ids")
	List<Object[]> findPrjIdOwnerByPrjIds(@Param("ids") Iterable<Integer> prjIds);
	

	@Query("select count(1) from Project p where p.prjId=?1 and p.prjCmpltDt is not null")
	long isCompleted(Integer prjId);

	@Modifying
	@Transactional
	@Query("update Project p set p.prjStatusId=?2, p.lastUpdtBy=?3, p.lastUpdtTs=?4 where p.prjId=?1")
	void updateStatus(Integer prjId, Integer statusId, String lastUpdtBy, Timestamp lastUpdtTs);

	@Modifying
	@Transactional
	@Query("update Project p set p.prjStatusId=?2, p.prjCmpltDt=?3, p.lastUpdtBy=?4, p.lastUpdtTs=?5 where p.prjId=?1")
	void updateStatus(Integer prjId, Integer statusId, Date prjCmpltDt, String lastUpdtBy, Timestamp lastUpdtTs);
	
	@Modifying
	@Transactional
	@Query("update Project p set p.prjCmpltDt=?2 where p.prjId=?1")
	void setCompleted(Integer prjId, Date prjCmpltDt);

	@Modifying
	@Transactional
	@Query("update Project p set p.prjOwner=?1, p.lastUpdtBy=?3, p.lastUpdtTs=?4 where p.prjId=?2")
	void updateOwner(String ownerId, Integer prjId, String lastUpdtBy, Timestamp lastUpdtTs);
	
	@Modifying
	@Transactional
	@Query("update Project p set p.lastUpdtTs=?2 where p.prjId=?1")
	void updateProjLastModDate(Integer prjId,Timestamp lastUpdtTs);


}
