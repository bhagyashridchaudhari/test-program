package com.deere.epdp.pra.serviceImpl.prm;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deere.epdp.pra.domain.prm.MitigationStatus;
import com.deere.epdp.pra.repo.prm.MitigationStatusRepository;
import com.deere.epdp.pra.service.prm.MitigationStatusService;

@Service
public class MitigationStatusServiceImpl implements MitigationStatusService {

	@Autowired
	private MitigationStatusRepository mitigationStatusRepository;
	private List<MitigationStatus> mitigationStatus;
	
	@PostConstruct
	public void init() {
		mitigationStatus = StreamSupport.stream(mitigationStatusRepository.findAll().spliterator(), false)
				.collect(Collectors.toList());
	}

	@Override
	public List<MitigationStatus> getAllMitigationStatus() {
		return mitigationStatus;
	} 
}

