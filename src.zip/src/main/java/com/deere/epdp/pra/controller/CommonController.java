package com.deere.epdp.pra.controller;


import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.deere.dsfj.utility.ServletUtility;
import com.deere.epdp.pra.domain.user.User;
import com.deere.epdp.pra.model.CommonData;
import com.deere.epdp.pra.model.Response;
import com.deere.epdp.pra.model.Response.Status;
import com.deere.epdp.pra.service.CommonService;
import com.deere.epdp.pra.service.UserService;

@RestController
@RequestMapping("/api")
public class CommonController {
	
	@Autowired
	private CommonService commonService;
	
	@Autowired
	private UserService userService;

	@Autowired
	private User user;
	
	@GetMapping("/test")
	public String Test1() {
		return "Test success...!!";
	}
	
	@GetMapping("/common-data")
	public CommonData getCommonData() {
		return commonService.getCommonData();
	}

	@GetMapping(value = "/common-data", params = "reload=true")
	public CommonData reloadCommonData() {
		return commonService.reloadCommonData();
	}

	@GetMapping("/logged-user")
	public User getCurrentUser() {
		user.setProgAccessMap(userService.getProjAccessMap(user));
		return user.produce();
	}
	
	@PostMapping("/simulate")
	public Response<String> simulateUser(@RequestBody String id, HttpServletRequest request) {
		if (id != null && (user.isAdmin() || user.isItSupport())) {
			request.getSession().setAttribute(ServletUtility.getUserIdHeaderKey(), id);
			user.consume(new User());
			return new Response<>(Status.SUCCESS);
		}
		return new Response<>(Status.ERROR);
	}

	@GetMapping("/logout")
	public Response<String> logoutUser(HttpServletRequest request) {
		request.getSession().removeAttribute(ServletUtility.getUserIdHeaderKey());
		user.consume(new User());
		return new Response<>(Status.SUCCESS);
	}	
}
