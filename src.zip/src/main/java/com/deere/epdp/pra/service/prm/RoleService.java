package com.deere.epdp.pra.service.prm;

import java.util.List;

import com.deere.epdp.pra.domain.prm.Role;

public interface RoleService {
	
	void init();

	List<Role> getAllRole();

	Role getRoleById(Integer id);

}