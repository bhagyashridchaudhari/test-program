package com.deere.epdp.pra.utility;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.deere.epdp.pra.literals.PRALiterals;

public class EmailUtility {
	
	//Program Specific alteration
	public static void sendEmail(String to, String cc, String subject, String body){
		// Get system properties
		Properties properties = System.getProperties();
		// Setup mail server
		properties.setProperty(PRALiterals.SMTP_HOST, PRALiterals.HOST);
		// Get the default Session object.
		Session session = Session.getDefaultInstance(properties);
		
		String env = System.getProperty("IafConfigSuffix");
		try{
			MimeMessage message = null;

			// Create a default MimeMessage object.
			message = new MimeMessage(session);
			// Set From: header field of the header.
			message.setFrom(new InternetAddress(PRALiterals.EMAIL_FROM));
			// Set Subject: header field
			if(!env.equalsIgnoreCase("Prod"))
				message.setSubject("**TEST MAIL ** " +System.getProperty("IafConfigSuffix") +" :: " +subject);
			else
				message.setSubject(subject);
			//mail in HTML format
			message.setText(body, "UTF-8", "html");
			
			if(env.equalsIgnoreCase("Local"))
				to = cc;

			message.addRecipient(Message.RecipientType.TO,new InternetAddress(to+"@deere.com"));
			message.addRecipient(Message.RecipientType.CC,new InternetAddress(cc+"@deere.com"));
		//	message.addRecipient(Message.RecipientType.CC,new InternetAddress("AS22820"+"@deere.com"));
			
			if(!env.equalsIgnoreCase("Local"))
				message.addRecipient(Message.RecipientType.BCC,new InternetAddress("bc04761@deere.com"));

			//Send message
			Transport.send(message);
		}catch (MessagingException mex){
			mex.printStackTrace();
		}
	}
	
	
}