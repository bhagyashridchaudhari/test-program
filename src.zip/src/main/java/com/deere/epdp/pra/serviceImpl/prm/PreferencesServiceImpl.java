package com.deere.epdp.pra.serviceImpl.prm;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.deere.epdp.pra.domain.prm.Preferences;
import com.deere.epdp.pra.domain.user.User;
import com.deere.epdp.pra.model.Preference;
import com.deere.epdp.pra.model.Response;
import com.deere.epdp.pra.model.Response.RespMessage;
import com.deere.epdp.pra.model.Response.Status;
import com.deere.epdp.pra.repo.prm.PreferencesRepository;
import com.deere.epdp.pra.service.prm.PreferencesService;
import com.deere.epdp.pra.utility.CommonUtility;
import com.deere.epdp.pra.utility.Converter;

@Service
public class PreferencesServiceImpl implements PreferencesService{
	
	@Autowired
	private PreferencesRepository prefRepository;
	
	@Autowired
	private User user;

	@Override
	@Transactional
	public Response<Preference> getPrgmPreference(Integer prjId) {
		String userId = user.getUserId();
		List<RespMessage> errors = new ArrayList<>();
		List<Preferences> list = (List<Preferences>) prefRepository.findAll();
		Preferences pref =list.stream().filter(p -> p.getUserId().equalsIgnoreCase(userId) && p.getProgId() == prjId && p.getDefaultPref() == 'N').findFirst().orElse(null);
		if(pref == null) {
			pref = list.stream().filter(p -> p.getUserId().equalsIgnoreCase(userId) && p.getDefaultPref() == 'Y').findFirst().orElse(null);
		}
		Preference preference = Converter.convertToPreference(pref);
		return new Response<>(Status.SUCCESS, preference, errors.isEmpty() ? null : errors );
	}

	@Override
	@Transactional
	public Response<Preferences> savePreference(Preference pref) {
		List<RespMessage> errors = new ArrayList<>();
		Preferences preference = new Preferences();
		Timestamp currntTime = CommonUtility.getCurrentTime();
		String userId = user.getUserId();
		
		if (isPreferenceExist(pref.getUserId(), pref.getProgId())) {
			preference = (pref == null ? null : Converter.convertToPreferences(pref, userId, currntTime));				
		} else {
			preference = (pref == null ? null : new Preferences(userId,pref.getProgId(),
					pref.getProgId() != 0 ? 'N' : 'Y',pref.getSelectedColumns(),userId,currntTime));	
		}
		prefRepository.save(preference);
		
		return new Response<>(Status.SUCCESS, preference, errors.isEmpty() ? null : errors );
	}
	
	@Override
	@Transactional
	public Response<Preference> getUserPreference() {
		String userId = user.getUserId();
		List<RespMessage> errors = new ArrayList<>();
        Preference obj = (Preference) ((Collection<Preferences>) prefRepository.findAll()).stream().filter(p -> p.getUserId().equalsIgnoreCase(userId) && p.getDefaultPref() == 'Y').map(Converter::convertToPreference);
		return new Response<>(Status.SUCCESS, obj, errors.isEmpty() ? null : errors );
	}
	
	public boolean isPreferenceExist(String userId, Integer progId) {
		if (progId != 0) {
			List<Preferences> list =  ((Collection<Preferences>) prefRepository.findAll()).stream().filter(p -> p.getUserId().equalsIgnoreCase(userId) && p.getProgId() == progId && p.getDefaultPref() == 'N').collect(Collectors.toList()); 
			return list.size() > 0;
		}
		else {
			List<Preferences> list =  ((Collection<Preferences>) prefRepository.findAll()).stream().filter(p -> p.getUserId().equalsIgnoreCase(userId) && p.getDefaultPref() == 'Y').collect(Collectors.toList()); 
			return list.size() > 0;
		}
	}
}
