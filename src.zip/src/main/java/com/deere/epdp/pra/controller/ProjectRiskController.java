package com.deere.epdp.pra.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.deere.epdp.pra.domain.user.User;
import com.deere.epdp.pra.model.ImageData;
import com.deere.epdp.pra.model.MitigationEmail;
import com.deere.epdp.pra.model.MitigationPlanOwner;
import com.deere.epdp.pra.model.PrgRiskDetails;
import com.deere.epdp.pra.model.Response;
import com.deere.epdp.pra.model.Response.RespMessage;
import com.deere.epdp.pra.model.Response.RespMessage.Type;
import com.deere.epdp.pra.model.Response.Status;
import com.deere.epdp.pra.model.RiskCategoryData;
import com.deere.epdp.pra.model.RiskImageData;
import com.deere.epdp.pra.model.RiskMitigation;
import com.deere.epdp.pra.repo.prm.CustomRiskCategoryImpactRepository;
import com.deere.epdp.pra.service.prm.ProjectRiskService;
import com.deere.epdp.pra.service.prm.RiskCategoryImpactService;
import com.deere.epdp.pra.service.prm.RiskCategoryService;

@RestController
@RequestMapping("/api/risk")
public class  ProjectRiskController {
	
	@Autowired
	private  ProjectRiskService riskService;
	
	@Autowired	
	private RiskCategoryService riskCategoryService;
	
	
	@Autowired
	private RiskCategoryImpactService  riskCategoryImpactService;
	
	@Autowired
	private CustomRiskCategoryImpactRepository customRiskCatImpactRepo;
	
	@Autowired
	private User user;

	@GetMapping("/{rskid}")
	public RiskMitigation getRisk(@PathVariable Integer rskid) {
		return riskService.getRiskById(rskid);
	}
	
	@GetMapping("/prj/{prjId}")
	public Iterable<RiskMitigation> getRiskByProject(@PathVariable Integer prjId) {
		return riskService.getAllRiskByProjectId(prjId);
	}

	@PostMapping
	public Response<RiskMitigation> saveRisk(@RequestBody RiskMitigation risk) {
		return riskService.saveRisk(risk);
	}
	
	@DeleteMapping("/{id}")
	public Response<String> deleteRisk(@PathVariable Integer id) {
		return riskService.deleteRisk(id);
	}

	@PostMapping("/category")
	public Response<RiskCategoryData> saveCategory(@RequestBody RiskCategoryData data) {
		return riskCategoryService.saveProgRiskCategory(data);
	}
	
	@GetMapping("/category/impact/{progId}")
	public List<RiskCategoryData> getRiskCategoryImpactDesc(@PathVariable Integer progId) {
		return riskCategoryService.getRiskCategoryImpactDesc(progId);
	}
	
	@PostMapping("/mtgtnmail")
	public Response<String> sendEmail(@RequestBody List<MitigationEmail> mailBody) {
		return riskService.sendEmailToMitigationOwner(mailBody);
	}
	

	@GetMapping("/owner/all/{progId}")
	public  List<MitigationPlanOwner> getDistinctOwner(@PathVariable Integer progId) {
		return riskCategoryService.getDistinctOwner(progId);

	}
	
	@PostMapping("/owner/update")
	public Response<MitigationPlanOwner> updateOwners(@RequestBody MitigationPlanOwner data) {
		return riskCategoryService.updateOwners(data);
	}

	@PostMapping("/category/update")
	public Response<RiskCategoryData> updateCategory(@RequestBody List<RiskCategoryData> riskCategoryData) {
		return riskCategoryService.updateCategory(riskCategoryData);
	}


	@PostMapping(value = "/uploadImage")
	public Response<String> importFile(@RequestParam("file1") MultipartFile file1 , 
			@RequestParam("file2") MultipartFile file2,
			@RequestParam("progId") Integer progId,
			@RequestParam("riskId") Integer riskId) {
		 if(file1.getSize() != 0) riskService.uploadImages(file1,progId,riskId,1);
		 if(file2.getSize() != 0)  riskService.uploadImages(file2,progId,riskId,2);
	return new Response<>(Status.SUCCESS, Arrays.asList(new RespMessage("File Successfully imported.", Type.SUCCESS)));
	}
	
	@GetMapping(value = "/getImages")
	@CrossOrigin
	public ResponseEntity<List<String>> getImage(Integer progId, Integer riskId) {
		return new ResponseEntity<List<String>>(riskService.getImage(progId,riskId),HttpStatus.OK);
	}
	
	@GetMapping(value = "/getImages2")
	@CrossOrigin
	public Response<List<RiskImageData>> getImage2(Integer progId, Integer riskId) {
		return new Response<List<RiskImageData>>(Status.SUCCESS , riskService.getImage2(progId,riskId));
	}
	
	@GetMapping(value = "/download")
	@CrossOrigin
	public ResponseEntity<List<String>> downloadImage(Integer progId, Integer riskId ,Integer imageId) {
		return new ResponseEntity<List<String>>(riskService.getImage(progId,riskId),HttpStatus.OK);
	}
	
	@DeleteMapping(value = "/image/{imgId}")
	@CrossOrigin
	public Response<String> deleteImage(Integer progId, Integer riskId, @PathVariable Integer imgId) {
		return riskService.deleteImage(progId,riskId,imgId);
	}

	@PostMapping("/category/clone")
	public Response<RiskCategoryData> cloneRiskCategory(@RequestBody List<RiskCategoryData> riskCategoryData) {
		riskCategoryService.cloneRiskCategory(riskCategoryData);
		return new Response<RiskCategoryData>(Status.SUCCESS,
				Arrays.asList(new RespMessage("Successfully cloned  Category(s).", Type.SUCCESS)));
	}
	
	@GetMapping("/prjRskCat/{prjId}")
	public PrgRiskDetails getPrgRiskCategory(@PathVariable Integer prjId) {
		return riskService.getAllPrgRiskCategory(prjId);
	}
	
	@PostMapping("/downloadImage")
	public ResponseEntity<byte[]> downloadImage(@RequestBody ImageData imageData) {
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.parseMediaType(MediaType.IMAGE_JPEG_VALUE));
		return new ResponseEntity<>(riskService.downloadImage(imageData), headers, HttpStatus.OK);
	}
}
