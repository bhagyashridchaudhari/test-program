package com.deere.epdp.pra.domain.prm;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "score_level")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RiskScoreLevel {
	private static final long serialVersionUID = 1L;
	
	@EmbeddedId
	private RiskScoreLevelId id;
	
	@Column(name = "score",  nullable = false)
	private Integer score;
	
	@Column(name = "level",  nullable = false)
	private Integer level;

	public RiskScoreLevelId getId() {
		return id;
	}

	public void setId(RiskScoreLevelId id) {
		this.id = id;
	}

	public Integer getScore() {
		return score;
	}

	public void setScore(Integer score) {
		this.score = score;
	}

	public Integer getLevel() {
		return level;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}

	
	
	@Embeddable
	public static class RiskScoreLevelId implements Serializable {
		private static final long serialVersionUID = 1L;
		
		@Column(name = "probability_id")
		private Integer prbltyId;
		
		@Column(name = "impact_id")
		private Integer impactId;

		public Integer getPrbltyId() {
			return prbltyId;
		}

		public void setPrbltyId(Integer prbltyId) {
			this.prbltyId = prbltyId;
		}

		public Integer getImpactId() {
			return impactId;
		}

		public void setImpactId(Integer impactId) {
			this.impactId = impactId;
		}
		
		
		
	}
	
}
