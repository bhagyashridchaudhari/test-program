package com.deere.epdp.pra.service.prm;

import java.util.List;

import com.deere.epdp.pra.domain.epdp.ProjectStatus;

public interface ProjectStatusService {
	
	void init();

	List<ProjectStatus> getAllProjectStatus();

	String getProjectStatusNameById(Integer id);

}
