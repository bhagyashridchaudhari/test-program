package com.deere.epdp.pra.repo.solr;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.solr.repository.Query;
import org.springframework.data.solr.repository.SolrCrudRepository;

import com.deere.epdp.pra.domain.user.UserSolr;

public interface SolrUserRepository extends SolrCrudRepository<UserSolr, String> {
	
	Long countByUserIdAndUserTypeCdIn(String id, Iterable<Integer> types);
	
	UserSolr findTopByUserIdAndUserTypeCdIn(String id, Iterable<Integer> types);

	List<UserSolr> findByUserIdInAndUserTypeCdIn(Iterable<String> ids, Iterable<Integer> types);

	@Query(value = "*:*", filters = "USER_ID:?0* AND USER_TYP_CD:(1 OR 2 OR 4 OR 9)")
	Page<UserSolr> searchByUserId(String value, Pageable pageable);

	@Query(value = "*:*", filters = "(FIRST_NAME:?0* OR LAST_NAME_STR:?0*) AND USER_TYP_CD:(1 OR 2 OR 4 OR 9)")
	Page<UserSolr> searchByFirstNameLastName(String nm, Pageable pageable);
	
	@Query(value = "*:*", filters = "(USER_ID:?0* OR FIRST_NAME:?0* OR LAST_NAME_STR:?0*) AND USER_TYP_CD:(1 OR 2 OR 4 OR 9)")
	Page<UserSolr> searchByUserIdFirstNameLastName(String value, Pageable pageable);

	@Query(value = "*:*", filters = "(LAST_NAME_STR:(?0*) OR (FIRST_NAME:(?1*) AND LAST_NAME_STR:(?2*)) OR (FIRST_NAME:(?2*) AND LAST_NAME_STR:(?1*))) AND USER_TYP_CD:(1 OR 2 OR 4 OR 9)")
	Page<UserSolr> searchByFirstNameLastName(String nm, String fn, String ln, Pageable pageable);
}
