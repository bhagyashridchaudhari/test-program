package com.deere.epdp.pra.service;

import java.util.List;

import com.deere.epdp.pra.domain.epdp.Phase;

public interface PhaseService {
	
	void init();

	List<Phase> getAllPhase();

	Phase getPhaseById(Integer id);

}
