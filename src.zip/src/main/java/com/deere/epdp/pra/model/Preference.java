package com.deere.epdp.pra.model;

import java.util.Date;

public class Preference {

	private Integer id;
	
	private String userId ;
	
	private Integer progId;
	
	private char defaultPref ;

	private String selectedColumns;
	
	private String lastUpdatedBy;
	
	private Date lastUpdatedTimestamp;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public Integer getProgId() {
		return progId;
	}

	public void setProgId(Integer progId) {
		this.progId = progId;
	}

	public char getDefaultPref() {
		return defaultPref;
	}

	public void setDefaultPref(char defaultPref) {
		this.defaultPref = defaultPref;
	}

	public String getSelectedColumns() {
		return selectedColumns;
	}

	public void setSelectedColumns(String selectedColumns) {
		this.selectedColumns = selectedColumns;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getLastUpdatedTimestamp() {
		return lastUpdatedTimestamp;
	}

	public void setLastUpdatedTimestamp(Date lastUpdatedTimestamp) {
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}

	public Preference() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Preference(Integer id, String userId, Integer progId, char defaultPref, String selectedColumns,
			String lastUpdatedBy, Date lastUpdatedTimestamp) {
		super();
		this.id = id;
		this.userId = userId;
		this.progId = progId;
		this.defaultPref = defaultPref;
		this.selectedColumns = selectedColumns;
		this.lastUpdatedBy = lastUpdatedBy;
		this.lastUpdatedTimestamp = lastUpdatedTimestamp;
	}
	
	
	
	
}
