package com.deere.epdp.pra.service;

import java.util.List;

import com.deere.epdp.pra.domain.epdp.Unit;

public interface UnitService {
	
	void init();
	
	List<Unit> getAllUnits();

	String getUnitNameNCode(Integer id);

	String getUnitNameNCodeTC(Integer id);

}
