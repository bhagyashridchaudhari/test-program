package com.deere.epdp.pra.service.prm;

import com.deere.epdp.pra.domain.prm.Preferences;
import com.deere.epdp.pra.model.Preference;
import com.deere.epdp.pra.model.Response;

public interface PreferencesService {

	Response<Preference> getPrgmPreference(Integer prjId);

	Response<Preferences> savePreference(Preference pref);

	Response<Preference> getUserPreference();

}
