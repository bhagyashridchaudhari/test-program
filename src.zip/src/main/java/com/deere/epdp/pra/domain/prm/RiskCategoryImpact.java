package com.deere.epdp.pra.domain.prm;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "risk_ctgry_impact")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RiskCategoryImpact implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private RiskCategoryImpactId id;
	
	@Column(name = "impact_dsc")
	private String impactDsc;
	
	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdtBy;
	
	@JsonIgnore
	@Column(name = "last_updt_ts")
	private Timestamp lastUpdtTs;
	
	
	public RiskCategoryImpact() {}
	
	
	public RiskCategoryImpact(RiskCategoryImpactId id, String impactDsc, String lastUpdtBy, Timestamp lastUpdtTs) {
		super();
		this.id = id;
		this.impactDsc = impactDsc;
		this.lastUpdtBy = lastUpdtBy;
		this.lastUpdtTs = lastUpdtTs;
	}

	public RiskCategoryImpactId getId() {
		return id;
	}

	public void setId(RiskCategoryImpactId id) {
		this.id = id;
	}

	public String getImpactDsc() {
		return impactDsc;
	}

	public void setImpactDsc(String impactDsc) {
		this.impactDsc = impactDsc;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public void setLastUpdtBy(String lastUpdtBy) {
		this.lastUpdtBy = lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}

	public void setLastUpdtTs(Timestamp lastUpdtTs) {
		this.lastUpdtTs = lastUpdtTs;
	}


	@Embeddable
	public static class RiskCategoryImpactId implements Serializable {
		
		private static final long serialVersionUID = 1L;

		// Fk pra_risk_categoty		
		@Column(name = "risk_cat_id")
		private Integer ctgryId;

		@Column(name="impact_id")
		private Integer impactId;
		
		
		public RiskCategoryImpactId() {}

		public RiskCategoryImpactId(Integer ctgryId, Integer impactId) {
			super();
			this.ctgryId = ctgryId;
			this.impactId = impactId;
		}

		public Integer getCtgryId() {
			return ctgryId;
		}

		public void setCtgryId(Integer ctgryId) {
			this.ctgryId = ctgryId;
		}

		public Integer getImpactId() {
			return impactId;
		}

		public void setImpactId(Integer impactId) {
			this.impactId = impactId;
		}
	}
}
