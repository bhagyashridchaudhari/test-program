package com.deere.epdp.pra.serviceImpl;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deere.epdp.pra.domain.epdp.Milestone;
import com.deere.epdp.pra.repo.epdp.MilestoneRepository;
import com.deere.epdp.pra.service.MilestoneService;

@Service
public class MilestoneServiceImpl implements MilestoneService {

	@Autowired
	private MilestoneRepository milestoneRepository;

	private Map<Integer, Milestone> milestoneMap;

	@PostConstruct
	public void init() {
		milestoneMap = StreamSupport.stream(milestoneRepository.findAll().spliterator(), false)
				.collect(Collectors.toMap(Milestone::getMlstnId, Function.identity()));
	}

	@Override
	public List<Milestone> getAllMilestone() {
		return milestoneMap.values().stream().filter(m -> m.getMlstnNo() != 0).collect(Collectors.toList());
	}

	@Override
	public Milestone getMilestoneById(Integer id) {
		return milestoneMap.get(id);
	}

}