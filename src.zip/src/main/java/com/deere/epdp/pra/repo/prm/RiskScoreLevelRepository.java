package com.deere.epdp.pra.repo.prm;

import org.springframework.data.repository.CrudRepository;

import com.deere.epdp.pra.domain.prm.RiskScoreLevel;
import com.deere.epdp.pra.domain.prm.RiskScoreLevel.RiskScoreLevelId;

public interface RiskScoreLevelRepository extends CrudRepository<RiskScoreLevel, RiskScoreLevelId>{

}
