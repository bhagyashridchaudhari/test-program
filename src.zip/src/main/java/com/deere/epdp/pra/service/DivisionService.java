package com.deere.epdp.pra.service;

import java.util.List;

import com.deere.epdp.pra.domain.epdp.Division;

public interface DivisionService {
	
	void init();

	List<Division> getAllDivision();

	String getDivisionNameById(Integer id);

}
