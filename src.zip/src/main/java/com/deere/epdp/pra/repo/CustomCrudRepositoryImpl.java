package com.deere.epdp.pra.repo;

import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.FlushModeType;

import org.springframework.data.jpa.repository.support.JpaEntityInformation;
import org.springframework.data.jpa.repository.support.JpaEntityInformationSupport;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.orm.jpa.EntityManagerFactoryInfo;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;


@Transactional(readOnly = true)
public class CustomCrudRepositoryImpl<T, ID extends Serializable> extends SimpleJpaRepository<T, ID>
		implements CustomCrudRepository<T, ID> {

	private static final String ID_MUST_NOT_BE_NULL = "The given id must not be null!";

	private final EntityManager em;

	private final NamedParameterJdbcTemplate jt;

	public CustomCrudRepositoryImpl(JpaEntityInformation<T, ?> entityInformation, EntityManager entityManager) {
		super(entityInformation, entityManager);
		this.em = entityManager;
		this.jt = new NamedParameterJdbcTemplate(((EntityManagerFactoryInfo)entityManager.getEntityManagerFactory()).getDataSource());
	}

	public CustomCrudRepositoryImpl(Class<T> domainClass, EntityManager em) {
		this(JpaEntityInformationSupport.getEntityInformation(domainClass, em), em);
	}
	
	@Override
	@Transactional(readOnly = true)
	public List<T> findAll(String sql, MapSqlParameterSource args, RowMapper<T> rowMapper) {
		Assert.notNull(sql, ID_MUST_NOT_BE_NULL);
		return jt.query(sql, args, rowMapper);
	}

	@Override
	@Transactional
	public int[] saveAndFlush(String sql, MapSqlParameterSource[] batchArgs) {
		Assert.notNull(sql, ID_MUST_NOT_BE_NULL);
		return jt.batchUpdate(sql, batchArgs);
	}
	
	@Override
	@Transactional
	public int saveAndFlush(String sql, MapSqlParameterSource paramSource){
		Assert.notNull(sql, ID_MUST_NOT_BE_NULL);
		return jt.update(sql, paramSource);
	}

	@Override
	@Transactional
	public void deleteById(ID id) {
		Assert.notNull(id, ID_MUST_NOT_BE_NULL);
		T entity = em.find(getDomainClass(), id);
		if (entity != null)
			em.remove(entity);
	}

	@Override
	@Transactional
	public void deleteAndFlush(Iterable<ID> ids) {
		if (ids != null) {
			em.setFlushMode(FlushModeType.COMMIT);
			int batchCount = 0 ;

			for (ID id : ids) {
				T entity = em.find(getDomainClass(), id);
				if (entity != null) {
					em.remove(entity);
					batchCount++;
					if (batchCount == 200) {
						batchCount = 0;
						em.flush();
						em.clear();
					}
				}
			}
			if(batchCount != 0) {
				em.flush();
				em.clear();
			}
		}
	}
}
