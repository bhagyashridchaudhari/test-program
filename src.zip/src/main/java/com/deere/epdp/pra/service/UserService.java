package com.deere.epdp.pra.service;

import java.util.List;
import java.util.Map;

import com.deere.epdp.pra.domain.prm.ProjectTeam;
import com.deere.epdp.pra.domain.user.User;
import com.deere.epdp.pra.domain.user.UserSolr;

public interface UserService {

	UserSolr getUserSolr(String id);

	List<UserSolr> searchUser(String value);

	List<UserSolr> allUser(List<String> ids);

	User getUserDetails(String id);

	Map<Integer, Integer> getProjAccessMap(User user);

	boolean isValidUser(String id);


	String findUserName(String id);
	
	void addUserAndRole(ProjectTeam projectTeam);

	void updateUserAndRole(ProjectTeam projectTeam);

	void removeUserAndRole(ProjectTeam projectTeam);

}