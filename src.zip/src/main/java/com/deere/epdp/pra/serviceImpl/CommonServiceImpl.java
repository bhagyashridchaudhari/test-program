package com.deere.epdp.pra.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.deere.epdp.pra.domain.prm.CustomRiskCategoryImpact;
import com.deere.epdp.pra.domain.prm.ProgRiskCategoryImpact;
import com.deere.epdp.pra.domain.prm.ProgramRiskCateory;
import com.deere.epdp.pra.domain.prm.Project;
import com.deere.epdp.pra.domain.prm.ProjectTeam;
import com.deere.epdp.pra.domain.prm.ProjectTeam.ProjectTeamId;
import com.deere.epdp.pra.domain.user.User;
import com.deere.epdp.pra.exception.DuplicateEntityException;
import com.deere.epdp.pra.literals.PRALiterals;
import com.deere.epdp.pra.model.CommonData;
import com.deere.epdp.pra.model.Response;
import com.deere.epdp.pra.model.Response.RespMessage;
import com.deere.epdp.pra.model.Response.Status;
import com.deere.epdp.pra.repo.prm.CustomRiskCategoryImpactRepository;
import com.deere.epdp.pra.repo.prm.ProgRiskCategoryImpactRepository;
import com.deere.epdp.pra.repo.prm.ProgramCategoryRepository;
import com.deere.epdp.pra.service.CommonService;
import com.deere.epdp.pra.service.DivisionService;
import com.deere.epdp.pra.service.MilestoneService;
import com.deere.epdp.pra.service.prm.DesignSubTeamService;
import com.deere.epdp.pra.service.prm.MitigationStatusService;
import com.deere.epdp.pra.service.prm.ProjectRiskService;
import com.deere.epdp.pra.service.PhaseService;
import com.deere.epdp.pra.service.PlatformService;
import com.deere.epdp.pra.service.ProcessService;
import com.deere.epdp.pra.service.ProductFamilyService;
import com.deere.epdp.pra.service.ProductLineService;
import com.deere.epdp.pra.service.prm.ProjectService;
import com.deere.epdp.pra.service.ProjectStatusService;
import com.deere.epdp.pra.service.prm.ProjectTeamService;
import com.deere.epdp.pra.service.ProjectTypeService;
import com.deere.epdp.pra.service.prm.ResponseStratergyService;
import com.deere.epdp.pra.service.prm.RiskCategoryImpactService;
import com.deere.epdp.pra.service.prm.RiskCategoryService;
import com.deere.epdp.pra.service.prm.RiskImpactService;
import com.deere.epdp.pra.service.prm.RiskProbabilityService;
import com.deere.epdp.pra.service.prm.RiskScoreLevelService;
import com.deere.epdp.pra.service.prm.RoleService;
import com.deere.epdp.pra.service.SubProcessService;
import com.deere.epdp.pra.service.SegementHierarchyService;
import com.deere.epdp.pra.service.UnitService;


@Service
public class CommonServiceImpl implements CommonService {
	
	@Autowired
	private ProjectService projectService;
	
	@Autowired
	private DivisionService divisionService;
	
	@Autowired
	private ProjectTeamService projectTeamService;
	
	@Autowired
	private ProjectTypeService projectTypeService;
	
	@Autowired
	private ProjectStatusService projectStatusService;
	
	@Autowired
	private PlatformService platformService;

	@Autowired
	private ProcessService processService;
	
	@Autowired
	private ProductFamilyService productfamilyService;

	@Autowired
	private ProductLineService productLineService;
	
	@Autowired
	private UnitService unitService;

	@Autowired
	private RoleService roleService;
	
	@Autowired
	private PhaseService phaseService;
	
	@Autowired
	private MilestoneService milestoneService;
	
	@Autowired
	private SegementHierarchyService segementHierarchyService;
	
	@Autowired
	private RiskCategoryService categoryService;
	
	@Autowired
	private RiskImpactService impactService;
	
	@Autowired
	private ResponseStratergyService respStratergyService;
	
	@Autowired
	private RiskProbabilityService prbltyService;
	
	@Autowired
	private RiskCategoryImpactService rskCtrgyImpactService;
	
	@Autowired
	private RiskScoreLevelService scoreLevelService;
	 
	@Autowired
	private MitigationStatusService mtgntStatusService;

	@Autowired
	private SubProcessService subProcessServiceCS;
	 
	@Autowired
	private User user;
	
	@Autowired
	private ProjectRiskService projectRiskService;
	
	@Autowired
	private DesignSubTeamService designSubTeamService;
	
	@Autowired
	private ProgramCategoryRepository progCatagoryRepo;

	@Autowired
	private ProgRiskCategoryImpactRepository progCategoryImpactRepo;
	
	@Autowired
	private CustomRiskCategoryImpactRepository customRiskCatImpactRepo;
		
	@Value("${spring.profiles.active}")
	private String env;
	
	private static final CommonData COMMON_DATA = new CommonData();

	private static final Logger LOGGER = LoggerFactory.getLogger(CommonServiceImpl.class);

	@PostConstruct
	public void cacheCommonData() {
		COMMON_DATA.setPsh(segementHierarchyService.getAllSegementHierarchy());
		COMMON_DATA.setPtp(projectTypeService.getAllProjectType());
		COMMON_DATA.setPst(projectStatusService.getAllProjectStatus());
		COMMON_DATA.setPdv(divisionService.getAllDivision());
		COMMON_DATA.setPlf(platformService.getAllPlatform());
		COMMON_DATA.setPln(productLineService.getAllProductLine());
		COMMON_DATA.setPfm(productfamilyService.getAllProductFamily());
		COMMON_DATA.setPrs(processService.getAllProcess());
		COMMON_DATA.setPut(unitService.getAllUnits());
		COMMON_DATA.setPrl(roleService.getAllRole());
		COMMON_DATA.setPps(phaseService.getAllPhase());
		COMMON_DATA.setPms(milestoneService.getAllMilestone());
		COMMON_DATA.setPcu(PRALiterals.ALL_COUNTRY_CURRENCY);
		COMMON_DATA.setEnv(env);
		COMMON_DATA.setrCtgry(categoryService.getAllRiskCategory());
		COMMON_DATA.setrImp(impactService.getAllRiskImpact());
		COMMON_DATA.setRspStrgy(respStratergyService.getAllResponseStratergy());
		COMMON_DATA.setrPblty(prbltyService.getAllRiskProbability());
		COMMON_DATA.setrCI(rskCtrgyImpactService.getAllRiskCategoryImpact());
		COMMON_DATA.setRsl(scoreLevelService.getAllScoreLevel());
		COMMON_DATA.setmSts(mtgntStatusService.getAllMitigationStatus());
		COMMON_DATA.setSubp(subProcessServiceCS.getAllSubProcess());
	}

	@Override
	public CommonData getCommonData() {		
		return COMMON_DATA.copy();
	}

	@Override
	public CommonData reloadCommonData() {
		synchronized (COMMON_DATA) {
			projectTypeService.init();
			projectStatusService.init();
			divisionService.init();
			platformService.init();
			productLineService.init();
			productfamilyService.init();
			unitService.init();
			roleService.init();
			processService.init();
			phaseService.init();
			milestoneService.init();
			categoryService.init();
			impactService.init();
			respStratergyService.init();
			prbltyService.init();
			rskCtrgyImpactService.init();
			scoreLevelService.init();
			mtgntStatusService.init();
			subProcessServiceCS.init();
			cacheCommonData();
		}
		return getCommonData();
	}

	@Override
	public Response<Project> saveProject(Project project) {
		if (projectService.isValid(project)) {
			List<RespMessage> errors = new ArrayList<>(3);
			List<ProjectTeamId> removed = new ArrayList<>();
			List<ProjectTeam> added = new ArrayList<>();

			projectService.saveProject(project, added, removed);

			return new Response<>(Status.SUCCESS, project, errors.isEmpty() ? null : errors);
		}
		throw new DuplicateEntityException("A Project Risk Management Program exists with the same details, please change at least the name or segmentation to create a new Program.");
	}

	@Override
	@Transactional(value="prmTransactionManager",readOnly=false,propagation=Propagation.REQUIRED) 
	public Response<Project> deleteProject(Integer id) {
		List<RespMessage> errors = new ArrayList<>();
		List<ProgramRiskCateory> prgRiskList = (List<ProgramRiskCateory>) progCatagoryRepo.findProrgamRiskCateoryByProgId(id);
		List<ProgRiskCategoryImpact> prgRiskcCtList = (List<ProgRiskCategoryImpact>) progCategoryImpactRepo.findProgRiskCategoryImpactByProgId(id);
		if(prgRiskcCtList != null && ! prgRiskcCtList.isEmpty()) {
			progCategoryImpactRepo.delete(prgRiskcCtList);
		}
		if(prgRiskList != null && !prgRiskList.isEmpty()) {
			progCatagoryRepo.delete(prgRiskList);
		}
		List<CustomRiskCategoryImpact> customImpact=customRiskCatImpactRepo.findCustomRiskCategoryImpact(id);
		if(customImpact!=null && !customImpact.isEmpty() ) {
			customRiskCatImpactRepo.delete(customImpact);
		}
		designSubTeamService.deleteDesignSubTeamByProgram(id);
		projectRiskService.deleteMgtnPlanByPrjId(id);
		projectRiskService.deleteRiskByPrjId(id);

		projectTeamService.deleteProjectTeam(id);
		projectService.deleteProject(id);

		return new Response<>(Status.SUCCESS, errors.isEmpty() ? null : errors);
	}
}
