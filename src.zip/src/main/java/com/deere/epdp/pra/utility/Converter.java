package com.deere.epdp.pra.utility;

import java.sql.Timestamp;

import com.deere.epdp.pra.domain.prm.DesignSubTeam;
import com.deere.epdp.pra.domain.prm.MitigationPlan;
import com.deere.epdp.pra.domain.prm.Preferences;
import com.deere.epdp.pra.domain.prm.ProjectRisk;
import com.deere.epdp.pra.model.Mitigation;
import com.deere.epdp.pra.model.Preference;
import com.deere.epdp.pra.model.RiskMitigation;
import com.deere.epdp.pra.model.SubDesignTeam;

public class Converter {
	
	public static  RiskMitigation convertToRiskMitigation(ProjectRisk r) {
		return r == null ? null
				: new RiskMitigation(r.getRiskId(), r.getTitle(), r.getDscCause(), r.getDscEffect(), r.getPrgmId(),r.getRskCtgryId(),
						r.getPrbltyId(), r.getImpactId(), r.getRsStrtrgyId(), r.getLastUpdtBy(), r.getLastUpdtTs(),
						r.getCreatedBy(), r.getCreatedTs(), r.getRskLevel(), r.getRskScore(), r.getComment(),
						convertToMitigation(r.getMitigationPlan()),r.getCategorySource()
						
				);
	}

	public static final Mitigation convertToMitigation(MitigationPlan m) {
		return m == null ? null
				: new Mitigation(m.getMtgtnId(), m.getMtgtnTitle(), m.getTrgtClosure(),m.getNxtReview(), m.getMtgtnOwner(),
						m.getMtgtnSubFunction(), m.getMtgtnSubTeamId(),m.getMtgtnDesignTeamId(), m.getMtgtnStatusId(),
						m.getMtgtnPrbltyId(), m.getMtgtnImpactId(),	m.getMtgtnLastUpdtBy(), m.getMtgtnLastUpdtTs(),
						m.getMtgtnLevel(),m.getMtgtnScore()
						
				);
	}

	public static final ProjectRisk convertToProjectRisk(RiskMitigation rskMtgtn, String userId, Timestamp currntTime) {
		return rskMtgtn == null ? null
				: new ProjectRisk(rskMtgtn.getRiskId(), rskMtgtn.getTitle(), rskMtgtn.getDscCause(), rskMtgtn.getDscEffect(),
					rskMtgtn.getPrgmId(), rskMtgtn.getRskCtgryId(),
					rskMtgtn.getPrbltyId(), rskMtgtn.getImpactId(),rskMtgtn.getRsStrtrgyId(),userId,currntTime,
					rskMtgtn.getRskLevel(), rskMtgtn.getRskScore(), rskMtgtn.getComment(),rskMtgtn.getCategorySource()
						
				);
	}

	public static final MitigationPlan convertToMitigationPlan(Mitigation m,ProjectRisk prRisk,String userId, Timestamp currntTime) {
		return m == null ? null
				: new MitigationPlan(m.getMtgtnId(),m.getMtgtnTitle(), m.getTrgtClosure() ,m.getNxtReview(), m.getMtgtnOwner(),
					m.getMtgtnSubFunction(),m.getMtgtnSubTeamId(),m.getMtgtnDesignTeamId(),
					m.getMtgtnStatusId()!= null ? m.getMtgtnStatusId() : 1 ,
					m.getMtgtnPrbltyId(),m.getMtgtnImpactId(),prRisk,userId,currntTime,m.getMtgtnLevel(), m.getMtgtnScore() 
				);
	}
	
	public static final Preferences convertToPreferences(Preference p, String userId, Timestamp currntTime) {
		return p == null ? null
				: new Preferences(p.getId(), userId, p.getProgId(), p.getDefaultPref(), p.getSelectedColumns(), userId,
						currntTime);
	}
	
	public static final Preference convertToPreference(Preferences p) {
		return p == null ? null
				: new Preference(p.getId(), p.getUserId(), p.getProgId(), p.getDefaultPref(),
						p.getSelectedColumns(),	p.getLastUpdatedBy(),p.getLastUpdatedTimestamp());
	}
	

	public static final SubDesignTeam convertToTeam(DesignSubTeam t) {
		return t == null ? null
				: new SubDesignTeam(t.getId(), t.getName(),t.getPrgmId(), t.getType(),t.getLastUpdtBy(), t.getLastUpdtTs());
	}
	
	
}




