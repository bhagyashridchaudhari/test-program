package com.deere.epdp.pra.domain.epdp;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

@Entity
@Table(name = "project_associations")
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProjectAssociations implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "app_id")
	private Integer appId;

	@Column(name = "app_full_nm", nullable = false)
	private String appFullNm;

	@Column(name = "acronym", nullable = false)
	private String acronym;

	@Column(name = "app_url", nullable = false)
	private String appUrl;

	@Column(name = "get_api")
	private String getApi;

	@Column(name = "post_api")
	private String postApi;

	@Column(name = "is_active", length = 1)
	@ColumnDefault("'Y'")
	private String isActive;

	@Column(name = "is_create", length = 1)
	@ColumnDefault("'N'")
	private String isCreate;

	@JsonIgnore
	@Column(name = "last_updt_by", nullable = false)
	private String lastUpdtBy;

	@JsonIgnore
	@Column(name = "last_updt_ts")
	private Timestamp lastUpdtTs;

	public Integer getAppId() {
		return appId;
	}

	public String getAppFullNm() {
		return appFullNm;
	}

	public String getAcronym() {
		return acronym;
	}

	public String getAppUrl() {
		return appUrl;
	}

	public String getGetApi() {
		return getApi;
	}

	public String getPostApi() {
		return postApi;
	}

	public String getIsActive() {
		return isActive;
	}

	public String getIsCreate() {
		return isCreate;
	}

	public String getLastUpdtBy() {
		return lastUpdtBy;
	}

	public Timestamp getLastUpdtTs() {
		return lastUpdtTs;
	}
}
