package com.deere.epdp.pra.config;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;

import javax.servlet.Filter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.boot.autoconfigure.security.oauth2.resource.ResourceServerProperties;
import org.springframework.boot.autoconfigure.security.oauth2.resource.UserInfoTokenServices;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpRequest;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.oauth2.client.OAuth2ClientContext;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.filter.OAuth2ClientAuthenticationProcessingFilter;
import org.springframework.security.oauth2.client.token.grant.code.AuthorizationCodeResourceDetails;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableOAuth2Client;
import org.springframework.security.oauth2.provider.error.OAuth2AuthenticationEntryPoint;
import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.security.web.util.matcher.MediaTypeRequestMatcher;
import org.springframework.web.accept.ContentNegotiationStrategy;
import org.springframework.web.accept.HeaderContentNegotiationStrategy;
import org.springframework.web.client.RestTemplate;
import com.deere.epdp.pra.utility.CommonUtility;

@Configuration
@EnableOAuth2Client
@Order(SecurityProperties.ACCESS_OVERRIDE_ORDER)
public class SecurityConfig extends WebSecurityConfigurerAdapter {	

	@Value("${epdp.service.auth.user}")
	private String authUser;

	@Value("${epdp.service.auth.password}")
	private String authPass;
	
	@Value("${security.oauth2.okta.enable:false}")
	private boolean okatEnable;

	@Autowired
	private OAuth2ClientContext context;
	
	@Autowired
	private  ResourceServerProperties resourceServerProperties;
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		if(okatEnable)
			http.authorizeRequests().antMatchers("/login").permitAll().anyRequest().authenticated()
			.and().exceptionHandling().defaultAuthenticationEntryPointFor(new LoginUrlAuthenticationEntryPoint("/login"), getMediaTypeRequestMatcher(http))
			.and().httpBasic().authenticationEntryPoint(new OAuth2AuthenticationEntryPoint()).and().addFilterBefore(ssoFilter(), BasicAuthenticationFilter.class).csrf().disable().headers().disable();
		else
			http.authorizeRequests().antMatchers("/**").permitAll().and().csrf().disable().headers().disable();
	}

	private MediaTypeRequestMatcher getMediaTypeRequestMatcher(HttpSecurity http) {
		ContentNegotiationStrategy contentNegotiationStrategy = http.getSharedObject(ContentNegotiationStrategy.class);
		if (contentNegotiationStrategy == null) 
			contentNegotiationStrategy = new HeaderContentNegotiationStrategy();
		MediaTypeRequestMatcher preferredMatcher = new MediaTypeRequestMatcher(contentNegotiationStrategy, MediaType.APPLICATION_XHTML_XML,
				new MediaType("image", "*"), MediaType.TEXT_HTML, MediaType.TEXT_PLAIN);
		preferredMatcher.setIgnoredMediaTypes(Collections.singleton(MediaType.ALL));
		return preferredMatcher;
	}

	@Bean
	@ConfigurationProperties("security.oauth2.client")
	public AuthorizationCodeResourceDetails okta() {
		return new AuthorizationCodeResourceDetails();
	}

	@Bean
	public RestTemplate restTemplate(AuthorizationCodeResourceDetails okta, OAuth2ClientContext clientContext) {
		if (okatEnable)
			return new OAuth2RestTemplate(okta, clientContext);

		RestTemplate restTemplate = new RestTemplate();
		restTemplate.setInterceptors(Arrays.asList(new ClientHttpRequestInterceptor() {
			@Override
			public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {
				request.getHeaders().add("Authorization", CommonUtility.getAuthorisation(authUser, authPass));
				return execution.execute(request, body);
			}
		}));
		return restTemplate;
	}

	private Filter ssoFilter() {
		OAuth2ClientAuthenticationProcessingFilter oAuth2ClientAuthenticationFilter = new OAuth2ClientAuthenticationProcessingFilter("/login");
		OAuth2RestTemplate oAuth2RestTemplate = new OAuth2RestTemplate(okta(), context);
		oAuth2ClientAuthenticationFilter.setRestTemplate(oAuth2RestTemplate);
		UserInfoTokenServices tokenServices = new UserInfoTokenServices(resourceServerProperties.getUserInfoUri(), okta().getClientId());
		tokenServices.setPrincipalExtractor(map -> {
			String userId = (String) map.get("userID");
			if (userId != null)
				return userId;
			String username = (String) map.get("preferred_username");
			return username != null && username.contains("@") ? username.split("@")[0] : username;
		});
		tokenServices.setRestTemplate(oAuth2RestTemplate);
		oAuth2ClientAuthenticationFilter.setTokenServices(tokenServices);
		return oAuth2ClientAuthenticationFilter;
	}
}