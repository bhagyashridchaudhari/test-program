package com.deere.epdp.pra.repo.prm;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.deere.epdp.pra.domain.prm.ProjectRisk;

public interface  ProjectRiskRepository extends CrudRepository<ProjectRisk, Integer>{
	

       @Modifying
       @Query("delete from ProjectRisk pr where pr.prgmId=?1")
       public void deleteRiskByPrjId(Integer prjId);


}
