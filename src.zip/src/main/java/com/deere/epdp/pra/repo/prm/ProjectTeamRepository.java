package com.deere.epdp.pra.repo.prm;
import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.Query;

import com.deere.epdp.pra.domain.prm.ProjectTeam;
import com.deere.epdp.pra.domain.prm.ProjectTeam.ProjectTeamId;
import com.deere.epdp.pra.repo.CustomCrudRepository;
public interface ProjectTeamRepository extends CustomCrudRepository<ProjectTeam, ProjectTeamId> {
	
	List<ProjectTeam> findByIdProjId(Integer projId);
	
	List<ProjectTeam> findByMemberType(ProjectTeam.MemberType memberType);
	
	@Query("select p.id.projId , p.roleId from ProjectTeam p where p.id.memberId=?1" )
	List<Object[]> findByIdMemberId(String memberId);
	
	@Query("select distinct(p.id.memberId) from ProjectTeam p where p.memberType='I'")
	Set<String> getAllTeamUserId();

}