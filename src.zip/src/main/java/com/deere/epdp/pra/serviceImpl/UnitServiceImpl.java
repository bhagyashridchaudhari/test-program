package com.deere.epdp.pra.serviceImpl;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deere.epdp.pra.domain.epdp.Unit;
import com.deere.epdp.pra.repo.epdp.UnitRepository;
import com.deere.epdp.pra.service.UnitService;

@Service
public class UnitServiceImpl implements UnitService {

	@Autowired
	private UnitRepository unitRepository;

	private Map<Integer, Unit> unitMap;

	@PostConstruct
	public void init() {
		unitMap = StreamSupport.stream(unitRepository.findAll().spliterator(), false)
				.collect(Collectors.toMap(Unit::getUnitId, Function.identity()));
	}

	@Override
	public List<Unit> getAllUnits() {
		return unitMap.values().stream().sorted(Comparator.comparing(Unit::getUnitNm)).collect(Collectors.toList());
	}
	
	@Override
	public String getUnitNameNCode(Integer id) {
		Unit unit = unitMap.get(id);
		return unit != null ? unit.getUnitNm()+" ("+unit.getUnitCd()+")" : null;
	}
	
	@Override
	public String getUnitNameNCodeTC(Integer id) {
		Unit unit = unitMap.get(id);
		return unit != null ? unit.getUnitNm()+"( "+unit.getUnitCd()+" )" : null;
	}
}
