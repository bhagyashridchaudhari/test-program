package com.deere.epdp.pra.exception;

import java.util.List;

/**
 * @author RM43492
 * @version 1.0
 * @since 2017-11-01
 */
public class ImportProjectException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	private final List<String> errors;

	public ImportProjectException(String message, Throwable cause, List<String> errors) {
		super(message, cause);
		this.errors = errors;
	}

	public ImportProjectException(String message, List<String> errors) {
		super(message);
		this.errors = errors;
	}

	public List<String> getErrors() {
		return errors;
	}
}
