package com.deere.epdp.pra.serviceImpl.prm;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deere.epdp.pra.domain.prm.RiskImpact;
import com.deere.epdp.pra.repo.prm.RiskImpactRepository;
import com.deere.epdp.pra.service.prm.RiskImpactService;

@Service
public class RiskImpactServiceImpl implements RiskImpactService{
	
	@Autowired
	private RiskImpactRepository impactRepository;
	
	private Map<Integer, RiskImpact> impactMap;

	@PostConstruct
	public void init() {
		impactMap = StreamSupport.stream(impactRepository.findAll().spliterator(), false)
				.collect(Collectors.toMap(RiskImpact::getImpactId, Function.identity()));
	}

	@Override
	public List<RiskImpact> getAllRiskImpact() {
		return impactMap.values().stream().sorted(Comparator.comparing(RiskImpact::getImpactId)).collect(Collectors.toList());
		}

	@Override
	public Integer getRiskImpactById(Integer id) {
		RiskImpact impact = impactMap.get(id);
		return impact != null ? impact.getImpactId() : 0;
	}

}
